export const environment = {
  production: false,
  name: 'uat',
  serviceBaseUrls: {
    DOMAIN01: 'https://apis.uat.bfsgodirect.com/app01'
  },
  endPoints: {},
  hmr: true,
  PaymentKey: 'rzp_test_nUL72drVqZ6bYc',
  AnalyticsLink: '//assets.adobedtm.com/launch-EN3143bbfe394c4f37ab160d318f49797a-development.min.js',
  PaymentMode: "Bagic" ,//"Razor"
  paymentGatewayUrl: "http://webservicesint.bajajallianz.com/Insurance/WS/new_cc_payment.jsp?requestId={0}&Username=bfsdonline@general.bajajallianz.co.in&sourceName=HEALTH_WS"   
};
