export const environment = {
  production: true,
  name: 'prod',
  serviceBaseUrls: {
    DOMAIN01: 'https://apis.bajajfinservmarkets.in/app01'
  },
  endPoints: {},
  hmr: true,
  PaymentKey: 'rzp_live_kf4Gt8LevRe3QM',
  AnalyticsLink: '//assets.adobedtm.com/launch-ENb27da0f9795446f381a50091c0a0ff02.min.js',
  PaymentMode: "Bagic", //"Razor"
  paymentGatewayUrl: "https://general.bajajallianz.com/Insurance/WS/new_cc_payment.jsp?requestId={0}&Username=bfsdonline@general.bajajallianz.co.in&sourceName=HEALTH_WS"
};

