// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  name: 'qa',
  serviceBaseUrls: {
    DOMAIN01: 'https://apis.qa.bfsgodirect.com'
  },
  endPoints: {},
  hmr: true,
  PaymentKey: 'rzp_test_nUL72drVqZ6bYc',
  AnalyticsLink: '//assets.adobedtm.com/launch-EN3143bbfe394c4f37ab160d318f49797a-development.min.js',
  PaymentMode: "Bagic" ,//"Razor"
  paymentGatewayUrl: "http://webservicesint.bajajallianz.com/Insurance/WS/new_cc_payment.jsp?requestId={0}&Username=bfsdonline@general.bajajallianz.co.in&sourceName=HEALTH_WS"   
};


/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
