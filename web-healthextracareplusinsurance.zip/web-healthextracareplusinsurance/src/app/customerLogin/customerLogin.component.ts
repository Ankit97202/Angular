import { Component, OnInit, Output } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ActivitiHandlerService } from './../common/services/activitiHandler.service';
import { CommonConstants } from './../common/utilities/commonConstants';
import { RouteContextProvider } from './../common/services/routeContextProvider.service';
import { RouteHandlerService } from './../common/services/routeHandler.service';
import { Formatter } from './../common/services/formatter';
import { ConfigService } from './../common/services/config.service';
import { CookieHandlerService } from './../common/services/cookieHandler.service';
import { HomeService } from './../home/home.service';
import { Response } from '@angular/http';
import { SharedService } from './../common/services/sharedService';
import { AnalyticsService } from './../common/services/device.analytics.service';
import { HttpInterceptor } from './../common/services/httpInterceptor.service';
import { EmitterService } from './../common/services/emitter.service';
const generateOtpObj = {
    mobile: 0,
    policyName: 'PL',
    mfa: true
};
@Component({
    selector: 'app-customer-login',
    templateUrl: './customerLogin.template.html',
    styleUrls: ['./customerLogin.style.css']
})
export class CustomerLoginComponent implements OnInit {
    @Output() public ResumeApplObj;
    private readonly CUSTOMER: string = 'customer';
    private _viewType: string;
    private _appID: string;
    private partnerKey: string;
    constructor(
        private _routeContextProvider: RouteContextProvider,
        private _routerService: RouteHandlerService,
        private _activitiHandler: ActivitiHandlerService,
        private _homeService: HomeService,
        private _sharedService: SharedService,
        private _cookieHandler: CookieHandlerService,
        private _analyticsService: AnalyticsService,
        private _formatter: Formatter,
        private _httpInterceptor: HttpInterceptor,
        private _emitterService: EmitterService) {
        // constructor
    }
    public ngOnInit() {
        this._cookieHandler.DeleteCookies(['SS_1_APP_PRO_ID']);
        this._viewType = this._routeContextProvider.GetRouteParams('CustomerType');
        this.partnerKey = this._routeContextProvider.GetQueryParams('partnerKey');
        this._sharedService.setData(CommonConstants.QueryParamsKeys.Productcode,
            CommonConstants.LOAN_PRODUCT_CODES.Health_ExtraInsurance);
            this.opreationsOnInit();
        this.setUtmParams();
        this.fetchQueryParams();
    }
    private GenerateOtp(data): Observable<ActivitiModel.MTResponse<any>> {
        return this._httpInterceptor.Post(ConfigService.getInstance()
            .getConfigObject().APIURL.generateOtp, data, true);
    }
    private fetchQueryParams() {
        const _mobileNumber = this._routeContextProvider.GetQueryParams('m');
        if (this.partnerKey) {
            generateOtpObj.mobile = parseInt(_mobileNumber, 10);
        }
        const DOB = this._routeContextProvider.GetQueryParams('d');
        const OTP = this._routeContextProvider.GetQueryParams('o');
        const UTM = this._routeContextProvider.GetQueryParams('u');
        if (_mobileNumber && DOB) {
            const _tempObj = {};
            _tempObj['mobileNumber'] = _mobileNumber;
            _tempObj['DOB'] = DOB;
            _tempObj['OTP'] = (OTP) ? OTP : null;
            this.ResumeApplObj = _tempObj;
            this._cookieHandler.SetCookie(CommonConstants.CookieKeys.EmployeeResume,
                CommonConstants.DEFAULT_EMPTY_STRING);
        }
    }
    private IsResumedFromCustomerPortal() {
        const utmSource = this._routeContextProvider.GetQueryParams
            (CommonConstants.QueryParamsKeys.appUtmSource);
        return utmSource && utmSource.startsWith(this.CUSTOMER);
    }
    private opreationsOnInit() {
        this._cookieHandler.DeleteCookies([CommonConstants.SharedServiceDataKeys.JourneySource]);
        this.authenticateSystem();
    }
    private authenticateSystem(): void {
        const userClientId = this._homeService.GetClientIdForUser();
        this.setSecretKeyForClientId(userClientId);
    }
    private setSecretKeyForClientId(clientId: string): void {
        this._homeService.GetSecretKeyForBasedOnClientId(clientId).subscribe((responseData: ActivitiModel.MTResponse<any>) => {
            if (!responseData.errorBean) {
                this._cookieHandler
                    .SetCookie(CommonConstants.CookieKeys.ClientId, clientId);
                this._cookieHandler
                    .SetCookie(CommonConstants.CookieKeys.SecretKey,
                        responseData.payload.secretKey);
                this.setSystemAuthToken(responseData.payload.secretKey, clientId);
            }
        });
    }
    private setSystemAuthToken(secretKey: string, clientId: string): void {
        this._homeService.GetSystemAuthToken({
            secretKey,
            clientId
        }).subscribe((responseData: ActivitiModel.MTResponse<any>) => {
            if (!responseData.errorBean) {
                const tokenObj = responseData.payload.tokens[0];
                console.log('tokens::', tokenObj);
                this._cookieHandler.SetCookie(CommonConstants.CookieKeys.JWToken, tokenObj.token);
                this._cookieHandler.SetCookie(CommonConstants.CookieKeys.GuardKey, tokenObj.guardKey);
                this._cookieHandler.SetCookie(CommonConstants.CookieKeys.GuardToken, this._formatter
                    .ConvertGuradKeyToGuardToken(tokenObj.guardKey));
                this.initProcess((mtResponse) => {
                    if (!mtResponse.errorBean) {
                        this._routerService.RouteToNextTask(mtResponse.nextTaskKey);
                    } else {
                        console.log('Error Occured on ', mtResponse.errorBean);
                    }
                });
            }
        });
    }
    private initProcess(callback: Function) {
        this.startActivitiWithApplicationCreate(
            CommonConstants.LOAN_PRODUCT_CODES.Health_ExtraInsurance,
            CommonConstants.LOAN_PRODUCT_CATEGORY_CODES.Health_ExtraInsurance,
            (mtResponse: ActivitiModel.MTResponse<any>) => {
                callback(mtResponse);
            });
    }
    private startActivitiWithApplicationCreate(
        loanProduct: string,
        productCategoryCode: string,
        onSuccessCallback: Function,
        calculatorProductType?: number,
        isLocationProvided?: boolean) {
        const startActivitiRequest: any = {
            activitiName: 'startFlow',
            payload: this.getApplicationCreateRequest(
                loanProduct, productCategoryCode, calculatorProductType, isLocationProvided)
        };
        this.startActiviti(startActivitiRequest, onSuccessCallback);
    }
    private startActiviti(request: any, onSuccessCallback: Function) {
        this._activitiHandler.StartActiviti(request, true)
            .subscribe((response: ActivitiModel.MTResponse<any>) => {
                console.log('Raw Activiti working now');
                const data = response;
                if (!data.errorBean) {
                    this._cookieHandler.SetCookie(CommonConstants.CookieKeys.LoanApplicationId,
                        data.payload.applicationKey);
                    this._cookieHandler.SetCookie(CommonConstants.CookieKeys.ProcessInstanceDetails,
                        data.payload.processInstanceDetails);
                    this._cookieHandler.SetCookie(CommonConstants.CookieKeys.LoanApplicationKey,
                        data.payload.loanApplicationKey);
                    onSuccessCallback(data);
                }
            },
                (Error) => {
                    console.log(Error);
                });
    }
    private getApplicationCreateRequest(
        LoanProduct: string,
        ProductCategoryCode: string,
        CalculatorProductType?: number,
        IsLocationProvided?: boolean) {
        let mediumFromWeb = this._sharedService.getData(
            CommonConstants.QueryParamsKeys.appUtmMedium);
        const medium = 'Webengage_repeat_visitor_finance_homepage_PL_apply_online_link';
        if (mediumFromWeb !== '' && typeof (mediumFromWeb) !== 'object') {
            mediumFromWeb = this.CheckUtmMediumForDevice(
                this._sharedService.getData(
                    CommonConstants.QueryParamsKeys.appUtmMedium).toString());
        } else if (mediumFromWeb !== '') {
            mediumFromWeb = this.CheckUtmMediumForDevice(medium);
        } else {
            mediumFromWeb = this.CheckUtmMediumForDevice(mediumFromWeb);
        }
        return {
            appJourneyStamp: 'journeyStamp',
            appSource: 'Browser',
            appStatus: 0,
            bflBranch: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.BFLBranch)) || '320',
            productCategoryCode: ProductCategoryCode,
            insuranceApplications: {
                insProduct: CommonConstants.LOAN_PRODUCT_CODES.Health_ExtraInsurance
            },
            appUtmRefCode: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.appUtmRefCode)) || '',
            appUtmSource: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.appUtmSource)) || 'Organic',
            appUtmMedium: mediumFromWeb || medium,
            appUtmCampaign: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.appUtmCampaign)) || '',
            appUtmTerm: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.appUtmTerm)) || '',
            appUtmContent: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.appUtmContent)) || '',
            gclId: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.GCLID))
                || 'EAIaIQobChMIsZGIyZn01AIV1IdoCh19HAKqEAAYASAAEgKWjfD_BwE',
            applicantId: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.ApplicantId)) || '',
            applicationId: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.ApplicationId)) || '',
            appApplicantId: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.ApplicationApplicantId)) || '',
            insuranceProductType: this.checkUtmSources(this._sharedService.getData(
                    CommonConstants.QueryParamsKeys.InsuranceProductType)) || '',
            resumeJourney: true
        };
    }
    private checkUtmSources(utmObj) {
        if (Object.keys(utmObj).length !== 0) {
            return utmObj;
        } else {
            return false;
        }
    }
    private CheckUtmMediumForDevice(value: string) {
        const deviceDetails: DeviceDetails = this._analyticsService.GetDeviceDetails();
        if (deviceDetails.mobile) {
            value = value.concat('_mobile');
        }
        return value;
    }
    private setUtmParams() {
        this._sharedService.setData(CommonConstants.QueryParamsKeys.appUtmRefCode,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.appUtmRefCode));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.appUtmSource,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.appUtmSource));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.appUtmMedium,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.appUtmMedium));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.appUtmCampaign,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.appUtmCampaign));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.appUtmTerm,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.appUtmTerm));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.appUtmContent,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.appUtmContent));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.BFLBranch,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.BFLBranch));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.GCLID,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.GCLID));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.ApplicationId,
                    this._routeContextProvider.GetQueryParams
                        ('application_id'));
    }
}
