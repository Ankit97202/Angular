import { BaseRequestOptions, ConnectionBackend, Http, Response, ResponseOptions, XHRBackend, } from '@angular/http';
import { RouterTestingModule } from '@angular/router/testing';
import { Observable } from 'rxjs/Rx';
import { TestBed, inject } from '@angular/core/testing';
import { CustomerLoginComponent } from '../customerLogin.component';
import { RouteContextProvider } from '../../common/services/routeContextProvider.service';
import { ActivitiHandlerService } from '../../common/services/activitiHandler.service';
import { SharedService } from '../../common/services/sharedService';
import { CookieHandlerService } from '../../common/services/cookieHandler.service';
import { Formatter } from '../../common/services/formatter';
import { AnalyticsService } from '../../common/services/device.analytics.service';
// Load the implementations that should be tested
let mockLoginDataResponse: Response = new Response(
    new ResponseOptions(
        {
            body:
            {
                payload: {},
                status: 'success',
                errorBean: null,
                nextTaskKey: 'UpdateDetails1',
                code: '200',
                message: null
            }
        })
);
class MockLoginService {
    public GetClientIdForUser() {
        return 'IAMTest';
    }
    public GetSecretKeyForBasedOnClientId() {
        return Observable.of(mockLoginDataResponse);
    }
    public GetSystemAuthToken() {
        return Observable.of(mockLoginDataResponse);
    }
}
// tslint:disable-next-line:max-classes-per-file
class MockActivitiHandlerService {
    public MarkTaskAsCompleted() {
        return Observable.of(mockLoginDataResponse);
    }
    public GetTaskDetails() {
        return Observable.of(mockLoginDataResponse);
    }
}
xdescribe('CustomerLoginComponent Component', () => {
    // provide our implementations or mocks to the dependency injector
    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [RouterTestingModule],
            providers: [
                CustomerLoginComponent,
                RouteContextProvider,
                SharedService,
                CookieHandlerService,
                Formatter,
                AnalyticsService,
                { provide: ActivitiHandlerService, useClass: MockActivitiHandlerService },

            ]
        });
    });
    xit('Should check ngOnInit', inject([CustomerLoginComponent],
        (TestComponent: CustomerLoginComponent) => {
            TestComponent.ngOnInit();
        }));

});
