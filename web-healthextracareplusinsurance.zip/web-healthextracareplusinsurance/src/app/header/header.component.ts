import { Component, OnInit } from '@angular/core';
import { EmitterService } from '../common/services/emitter.service';
import { CommonConstants } from '../common/utilities/commonConstants';
@Component({
    // tslint:disable-next-line:component-selector
    selector: 'customHeader',
    templateUrl: './header.template.html',
    styleUrls: ['./header.style.css']
})
export class HeaderComponent implements OnInit {
  public ishealthExtraCarePlusMobileApp = false;
  public ShowProgressInfo = false;
  public ProgressStateInfo: Model.ProgressStateInfo[];
    constructor(
        private _emitterService: EmitterService
    ) {}
    ngOnInit() {
        this._emitterService.Get(CommonConstants.EmitterEventTypes.ProgressStateEvent).subscribe(
            (progressStateInfo: Model.ProgressStateInfo[]) => {
              this.ProgressStateInfo = progressStateInfo;
              console.log('app.component: ' + progressStateInfo);
              this.ShowProgressInfo = true;
        });
        // Mobile header hide
        this._emitterService.Get(CommonConstants.EmitterEventTypes.MobileAppCheck).subscribe(
        (Key: string) => {
            if (Key === '1') {
                this.ishealthExtraCarePlusMobileApp = true;
            }
        });
    }
}
