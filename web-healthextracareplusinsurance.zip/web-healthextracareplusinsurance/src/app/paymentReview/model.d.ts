declare module Model{
  export interface PaymentInputPaylaod{
  premiumRevised: string;
  requestId: number;
  insuranceDetails : Model.InsuranceDetails
}
 export interface InsuranceDetails {
    cityCode: number,
    insuringFor: number,
    planCode: string,
    variantCode: string,
    sumAssured: number,
    zoneCode: string,
    policyTerm: number,
    oldGrossPremium: number,
    netPremium: number,
    gst: number,
    grossPremium: number
  }
}