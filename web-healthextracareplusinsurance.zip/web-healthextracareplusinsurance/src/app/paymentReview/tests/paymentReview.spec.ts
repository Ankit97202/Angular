import { ConfigResolve } from './../../common/services/config.resolve.service';
import { ConfigService } from './../../common/services/config.service';
import { PaymentStatusService } from './../paymentStatus.service';
import { CookieService } from 'ngx-cookie-service';
import { ActivitiHandlerService } from './../../common/services/activitiHandler.service';
import { RouteHandlerService } from './../../common/services/routeHandler.service';
import { FormValidator } from './../../common/services/formValidator.service';
import { HttpInterceptor } from './../../common/services/httpInterceptor.service';
import { PaymentReviewComponent } from './../paymentReview.component';
import { TestBed, inject } from '@angular/core/testing';
import { BaseRequestOptions, ConnectionBackend, Http, Response, ResponseOptions, XHRBackend } from '@angular/http';
import { RouterTestingModule } from '@angular/router/testing';
import { CookieHandlerService } from 'src/app/common/services/cookieHandler.service';
import { RouteContextProvider } from 'src/app/common/services/routeContextProvider.service';
import { AnalyticsService } from 'src/app/common/services/device.analytics.service';
import { SharedService } from 'src/app/common/services/sharedService';
import { Formatter } from 'src/app/common/services/formatter';
import { Observable } from 'rxjs/Observable';
import { FormBuilder } from '@angular/forms';
import { of } from 'rxjs';
import { MockBackend } from '@angular/http/testing';
import { HttpResponse, HttpClient, HttpHandler } from '@angular/common/http';
const mockMarkTaskdata: HttpResponse<any> = new HttpResponse({
  body: {
    payload: null,
    userInput: null,
    status: 'SUCCESS',
    errorBean: null,
    nextTaskKey: 'healthExtraCarePaymentPreview',
    progressInfo: null,
    routesInfo: null
  }
});
const ConfigObj = {
  APIURL: {
    getHealthRequestId: 'https://apis.qa.bfsgodirect.com/v1/insurances/booking/initiation',
  }
};
const mockData: HttpResponse<any> = new HttpResponse({
  body: {
    payload: {
      applicationId: '187491',
      premiumRevised: 'N',
      errorDetails: [],
      recommendedPlans: {
        planCode: 'IHECP',
        sumAssuredList: [
          {
            selected: 'N',
            sumAssured: 300000.0,
            agreegatedDed: 200000.0,
            policyTerm: 1,
            netPremium: 2397.0,
            gst: 431.46,
            grossPremium: 2828.0,
            totalNetPremium: 2474.0,
            totalGrossPremium: 2919.0,
            totalGST: 445.32,
            riders: [
              {
                sumAssured: 200000.0,
                selected: 'Y',
                netPremium: 77.0,
                gst: 13.86,
                grossPremium: 91.0,
                code: 'IAMB'
              }
            ]
          },
          {
            selected: 'N',
            sumAssured: 500000.0,
            agreegatedDed: 300000.0,
            policyTerm: 1,
            netPremium: 1590.0,
            gst: 286.2,
            grossPremium: 1876.0,
            totalNetPremium: 1782.0,
            totalGrossPremium: 2103.0,
            totalGST: 320.76,
            riders: [
              {
                sumAssured: 500000.0,
                selected: 'Y',
                netPremium: 192.0,
                gst: 34.56,
                grossPremium: 227.0,
                code: 'IAMB'
              }
            ]
          },
          {
            selected: 'N',
            sumAssured: 1000000.0,
            agreegatedDed: 500000.0,
            policyTerm: 1,
            netPremium: 1828.0,
            gst: 329.04,
            grossPremium: 2157.0,
            totalNetPremium: 2020.0,
            totalGrossPremium: 2384.0,
            totalGST: 363.6,
            riders: [
              {
                sumAssured: 500000.0,
                selected: 'Y',
                netPremium: 192.0,
                gst: 34.56,
                grossPremium: 227.0,
                code: 'IAMB'
              }
            ]
          },
          {
            selected: 'Y',
            sumAssured: 1500000.0,
            agreegatedDed: 500000.0,
            policyTerm: 1,
            netPremium: 2571.0,
            gst: 462.78,
            grossPremium: 3034.0,
            totalNetPremium: 2956.0,
            totalGrossPremium: 3488.0,
            totalGST: 532.08,
            riders: [
              {
                sumAssured: 1000000.0,
                selected: 'Y',
                netPremium: 385.0,
                gst: 69.3,
                grossPremium: 454.0,
                code: 'IAMB'
              }
            ]
          },
          {
            selected: 'N',
            sumAssured: 2000000.0,
            agreegatedDed: 500000.0,
            policyTerm: 1,
            netPremium: 3193.0,
            gst: 574.74,
            grossPremium: 3768.0,
            totalNetPremium: 3578.0,
            totalGrossPremium: 4222.0,
            totalGST: 644.04,
            riders: [
              {
                sumAssured: 1000000.0,
                selected: 'Y',
                netPremium: 385.0,
                gst: 69.3,
                grossPremium: 454.0,
                code: 'IAMB'
              }
            ]
          },
          {
            selected: 'N',
            sumAssured: 2500000.0,
            agreegatedDed: 1000000.0,
            policyTerm: 1,
            netPremium: 2563.0,
            gst: 461.34,
            grossPremium: 3024.0,
            totalNetPremium: 2948.0,
            totalGrossPremium: 3479.0,
            totalGST: 530.64,
            riders: [
              {
                sumAssured: 1000000.0,
                selected: 'Y',
                netPremium: 385.0,
                gst: 69.3,
                grossPremium: 454.0,
                code: 'IAMB'
              }
            ]
          },
          {
            selected: 'N',
            sumAssured: 5000000.0,
            agreegatedDed: 1000000.0,
            policyTerm: 1,
            netPremium: 4757.0,
            gst: 856.26,
            grossPremium: 5613.0,
            totalNetPremium: 5142.0,
            totalGrossPremium: 6068.0,
            totalGST: 925.56,
            riders: [
              {
                sumAssured: 1000000.0,
                selected: 'Y',
                netPremium: 385.0,
                gst: 69.3,
                grossPremium: 454.0,
                code: 'IAMB'
              }
            ]
          }
        ]
      },
      oldGrossPremium: 3488.0
    },
    userInput: null,
    status: 'SUCCESS',
    errorBean: null,
    nextTaskKey: 'healthExtraCarePaymentPreview',
    progressInfo: {
      payload: [
        {
          name: 'Get Started',
          value: 100,
          active: false
        },
        {
          name: 'Verify Me',
          value: 75,
          active: true
        },
        {
          name: 'Close The Deal',
          value: 0,
          active: false
        }
      ],
      status: 'SUCCESS',
      errorBean: null
    },
    routesInfo: {
      mainRoute: 'final',
      subRoute: 'paymentReview'
    }
  }
});
class MockActivitiHandlerService {
  public MarkTaskAsCompleted() {
    return of(mockMarkTaskdata.body);
  }
  public GetTaskDetails() {
    return of(mockData.body);
  }
}
const APIURL = {};
APIURL['getHealthRequestId'] = 'https://apis.qa.bfsgodirect.com/v1/insurances/booking/initiation';
describe('Payment Review Component', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [
        PaymentReviewComponent,
        PaymentStatusService,
        HttpInterceptor,
        HttpClient,
        HttpHandler,
        Formatter,
        FormValidator,
        FormBuilder,
        RouteHandlerService,
        FormValidator,
        SharedService,
        AnalyticsService,
        RouteContextProvider,
        MockBackend,
        {
          provide: ConfigService, useValue: {
              getInstance: () => {
                  const getConfigObject = () => {
                      return { config: { APIURL: {  getHealthRequestId:
                        'https://apis.qa.bfsgodirect.com/v1/insurances/booking/initiation' } } };
                  };
                  return getConfigObject;
              }
          }
      },
        { provide: XHRBackend, useClass: MockBackend },
        CookieHandlerService,
        CookieService,
        {
          provide: ActivitiHandlerService,
          useClass: MockActivitiHandlerService
        },
        {
          provide: Http,
          useFactory: (
            backend: ConnectionBackend,
            defaultOptions: BaseRequestOptions
          ) => {
            return new Http(backend, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        }
      ]
    });
  });
  it('Testing ngOnInit', inject(
    [PaymentReviewComponent],
    (testComponent: PaymentReviewComponent) => {
      testComponent.ngOnInit();
    }
  ));
  xit('Testing Next', inject(
    [PaymentReviewComponent],
    (testComponent: PaymentReviewComponent) => {
      testComponent.ngOnInit();
      testComponent.Next();
    }
  ));
  it('Testing Back', inject(
    [PaymentReviewComponent],
    (testComponent: PaymentReviewComponent) => {
      testComponent.ngOnInit();
      testComponent.Back();
    }
  ));
});