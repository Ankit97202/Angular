import { Component, OnInit, Input, OnChanges, Output, EventEmitter } from '@angular/core';
import { ActivitiHandlerService } from '../common/services/activitiHandler.service';
import { RouteHandlerService } from '../common/services/routeHandler.service';
import { addSpaceToDigit } from '../common/utilities/pipes/SpacePipe.pipe';
import { Formatter } from '../common/services/formatter';
@Component({
    selector: 'app-plan-summary',
    templateUrl: './planSummary.template.html',
    styleUrls: ['./planSummary.style.css']
})
export class PlanSummaryComponent implements OnChanges {
    @Input() public PlanSummaryObj: Model.SelectedPlanDetails;
    @Input() public IsEditable = false;
    @Input() public InsuredCount;
    @Output() public OnActivitiError: EventEmitter<any> = new EventEmitter();
    constructor(
        public formatter: Formatter,
        private _activitiHandler: ActivitiHandlerService,
        private _routerService: RouteHandlerService
    ) {}
    // On Component Init
    public ngOnChanges() {
        console.log('in plan summary', this.PlanSummaryObj);
    }
    public ModifyDetails() {
        this._activitiHandler.MarkTaskAsCompleted(null, 'Modify').subscribe((mtResponse: ActivitiModel.MTResponse<any>) => {
            if (!mtResponse.errorBean) {
                this._routerService.RouteToNextTask(mtResponse.nextTaskKey);
            } else {
                this.OnActivitiError.emit(mtResponse.errorBean);
            }
        });
    }
    public space(input)
    {
        if(input !==null)
        addSpaceToDigit(input);
    }
}