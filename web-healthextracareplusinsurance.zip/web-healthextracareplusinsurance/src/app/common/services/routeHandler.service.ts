import { CommonConstants } from './../utilities/commonConstants';
import { Injectable } from '@angular/core';
import { RouteContextProvider } from '../services/routeContextProvider.service';
import { Formatter } from './../services/formatter';
const proposerRoute = CommonConstants.Routes.Application.Home.concat('/',
CommonConstants.Routes.Application.ProposerPersonalDetails);
const TaskKeyArray = {
    healthextracareproposerdetails: proposerRoute,
    healthextracarefatherdetails: proposerRoute,
    healthextracaremotherdetails: proposerRoute,
    healthextracarespousedetails: proposerRoute,
    healthextracarechild1: proposerRoute,
    healthextracarechild2: proposerRoute,
    healthextracarechild3: proposerRoute,
    healthextracarechild4: proposerRoute,
    healthextracaremobileverification:
        CommonConstants.Routes.Verification.Home.concat('/',
            CommonConstants.Routes.Verification.VerifyMobile),
    healthextracarenominee:
        CommonConstants.Routes.Application.Home.concat('/',
            CommonConstants.Routes.Application.AddressDetails),
    healthextracareproductsummary:
        CommonConstants.Routes.Application.Home.concat('/',
            CommonConstants.Routes.Application.ReviewApplication),
    healthextracareaddress:
        CommonConstants.Routes.Application.Home.concat('/',
            CommonConstants.Routes.Application.AddressDetails),
    healthextracaremedicaldetails:
        CommonConstants.Routes.Application.Home.concat('/',
            CommonConstants.Routes.Application.MedicalDeclaration),
    healthextracarebuynow: CommonConstants.Routes.Application.GetQuoteForm,
    healthextracaremodifyplan: CommonConstants.Routes.Application.GetQuoteForm,
    healthextracarereject:  CommonConstants.Routes.FinalModule.Home.concat('/',
       CommonConstants.Routes.FinalModule.RejectApplication),
    healthextracareapplicationlist: CommonConstants.Routes.ApplicationList,
  healthextracarepaymentpreview:  CommonConstants.Routes.FinalModule.Home.concat('/',
    CommonConstants.Routes.FinalModule.PaymentReview),
  healthextracarepolicypage:  CommonConstants.Routes.FinalModule.Home.concat('/',
    CommonConstants.Routes.FinalModule.Congratulations),
};
@Injectable({
    providedIn: 'root'
})
export class RouteHandlerService {
    public Route: string = null;
    public NextTaskKey: string = null;
    public ExceptionKeyArr: any[];
    private taskKeyArray = TaskKeyArray;
    constructor(
        private _routeContextProvider: RouteContextProvider,
        private _formatter: Formatter
    ) { }
    public RouteToNextTask(nextTaskKey: string, exceptionKeysArr?: any, callback?: any, toReload?: boolean) {
        this.Route = this.fetchRouteFromNextakKey(nextTaskKey);
        if (exceptionKeysArr && exceptionKeysArr.length > 0 && callback) {
            this.checkExceptionKeys(exceptionKeysArr, callback);
        } else if (callback) {
            callback(this.Route);
        } else if (this.Route) {
            this._routeContextProvider.NavigateToView([this.Route]);
            if (toReload) {
                const pathname = window.location.pathname;
                const newLocation = window.location.origin + pathname + '#/' + this.Route;
                location.replace(newLocation);
                location.reload();
            }
        } else {
            console.error('ERROR:: Route not available.');
        }
    }
    private fetchRouteFromNextakKey(nextTaskKey: string): string {
        this.NextTaskKey = this._formatter.toSmallCase(nextTaskKey);
        return this.taskKeyArray[this.NextTaskKey] || '';
    }
    private checkExceptionKeys(exceptionKeysArr, callback: any) {
        let toRoute = false;
        this.ExceptionKeyArr = exceptionKeysArr;
        for (let key of this.ExceptionKeyArr) {
            key = this._formatter.toSmallCase(key);
            if (this.NextTaskKey === key) {
                toRoute = false;
                callback(this.Route);
                break;
            } else {
                toRoute = true;
            }
        }
        if (toRoute) {
            this._routeContextProvider.NavigateToView([this.Route]);
        }
    }
}
