import { ActivatedRoute, Params, Router } from '@angular/router';
import { CommonConstants } from './../utilities/commonConstants';
import { Injectable } from '@angular/core';
import { Location } from '@angular/common';
import { Observable } from 'rxjs/Observable';
@Injectable({
    providedIn: 'root'
})
// The Caller has to call this in its context
export class RouteContextProvider  {
    constructor(public _router: Router,
                private _activatedRoute: ActivatedRoute,
                private _location: Location) {
    }
    // Invoke via call method
    public GetRouteParams(key: string): string {
        let result;
        this._activatedRoute.params.forEach((params) => {
            result = params[key] || CommonConstants.DEFAULT_EMPTY_STRING;
        });
        return result;
    }
    // Invoke via call method
    public GetQueryParams(key: string): string {
        let result;
        this._activatedRoute.queryParams.forEach((params) => {
            result = params[key] || CommonConstants.DEFAULT_EMPTY_STRING;
        });
        return result;
    }
    public GetAllQueryParams(): Observable<Params> {
        return this._activatedRoute.queryParams;
    }
    public NavigateToView(viewKey: any, target?: string): void {
        target ? window.open(viewKey, target) : this._router.navigate(viewKey);
    }
    public NavigateToViewWithQueryParams(viewKey: any, params: any) {
        this._router.navigate(viewKey, { queryParams : params});
    }
    public GoBack(): void {
        this._location.back();
    }
}
