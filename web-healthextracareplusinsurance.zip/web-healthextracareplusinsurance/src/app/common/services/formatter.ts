import { CommonConstants } from './../utilities/commonConstants';
import { Injectable } from '@angular/core';
const CurrencyCoversionUnits = {
    Lacs: 100000,
    Crore: 10000000
};
// Import RxJs required methods
@Injectable({
    providedIn: 'root'
})
export class Formatter {
    public monthNames: any = ['Jan', 'Feb', 'Mar', 'Apr', 'May',
        'June', 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    public day: any = ['Sunday', 'Monday', 'Tuesday',
        'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    public ToCurrency(value: string): string {
        return this.inrFormat(value.replace(/\,/g, ''));
    }
    public FormatToCurrency($event): any {
        // expecting $event as parameter and returning same
        const keyPosition = $event.target.selectionEnd;
        const value = $event.target.value;
        if (($event.keyCode >= 48 && $event.keyCode <= 57) ||
            ($event.keyCode >= 96 && $event.keyCode <= 105) ||
            ($event.keyCode === 8 || $event.keyCode === 46) || $event.type === 'blur') {
            const beforeLength = $event.target.value.length;
            $event.target.value = this.ToCurrency(value);
            const afterLength = $event.target.value.length;
            $event.target.selectionEnd = keyPosition - (beforeLength - afterLength);
        } else {
            $event.target.selectionEnd = keyPosition;
        }
        return $event;
    }
    /* Date Formatter input date in format mm-dd-yyyy
    ** Output mmm-yy date format
    **/
    public toUIDateFormat(value: string): string {
        const inputDate = new Date(value);
        const outputDate = this.monthNames[inputDate.getMonth()] + '-' +
            inputDate.getFullYear().toString().substr(2, 2);
        return outputDate;
    }
    /* Date Formatter input date in format mm-dd-yyyy
    ** Output mmm-yy date format
    **/
    public toUIDateFormatWithDate(value: string): string {
        const inputDate = new Date(value);
        const outputDate = inputDate.getDate() + '-' + this.monthNames[inputDate.getMonth()];
        return outputDate;
    }
    /* Date Formatter input date in format mm-dd-yyyy
    ** Output dd-mmm yyyy date format
    **/
    public toUIDateFormatWithYear(value: string): string {
        const inputDate = new Date(value);
        const outputDate = inputDate.getDate() + '-' + this.monthNames[inputDate.getMonth()]
            + ' ' + inputDate.getFullYear();
        return outputDate;
    }
    public toSmallCase(str: string): string {
        return str.toLowerCase();
    }
    public toUpperCase(str: string): string {
        return str.toUpperCase();
    }
    /*
    **Input: date
    **Output ordinal suffix(st,nd,rd,th)
    */
    public ordinal_suffix_of(i) {
        const j = i % 10;
        const k = i % 100;
        if (j === 1 && k !== 11) {
            return 'st';
        }
        if (j === 2 && k !== 12) {
            return 'nd';
        }
        if (j === 3 && k !== 13) {
            return 'rd';
        }
        return 'th';
    }
    /*returns day */
    public toUIgetDay(val): string {
        const inputDate = new Date(val);
        const outputDate = inputDate.getDay();
        return this.day[outputDate];
    }
    public CapitalizeText(inputText: string) {
        inputText = inputText.toLowerCase();
        return inputText[0].toUpperCase().concat(inputText.substr(1));
    }
    public ConvertCurrenyToUnit(value: string | number, conversionUnit: number) {
        value = value && value.toString() || CommonConstants.DEFAULT_EMPTY_STRING;
        const amount = parseInt(value.toString().replace(/,/g, ''), 10);
        return amount > 0 ? (amount / conversionUnit) : 0;
    }
    public ConvertNumberToAmount(value: number) {
        let amount: string;
        if (value < 9999999) {
            amount = this.ConvertCurrenyToUnit(value,
                CurrencyCoversionUnits.Lacs).toString();
            amount = ((amount.indexOf('.') > -1) ?
                amount.slice(0, (amount.indexOf('.')) + 3) : amount) + ' Lakhs';
        } else if (value > 9999999) {
            amount = this.ConvertCurrenyToUnit(value,
                CurrencyCoversionUnits.Crore).toString();
            amount = ((amount.indexOf('.') > -1) ?
                amount.slice(0, (amount.indexOf('.')) + 3) : amount) + ' Crore';
        }
        return amount;
    }
    public ConvertGuradKeyToGuardToken(guardKey: string): string {
        const salt = 'B!&1j';
        const timeStamp = new Date().getTime();
        const token = salt.concat(CommonConstants.PIPE_SEPARATOR,
            timeStamp.toString(),
            CommonConstants.PIPE_SEPARATOR,
            guardKey);
        return btoa(token);
    }
    public autoDateformat($event, fullDateFormat) {
        const key: number = $event.keyCode;
        const value: string = $event.target.value;
        if ((65 <= key) && (key <= 90) || (key > 185 && key <= 192) ||
            (key > 218 && key < 223) && $event.shiftKey === true) {
            $event.target.value = (value.substr(0, value.length - 1));
            return $event;
        }
        if (fullDateFormat === true && (value.length === 2 || value.length === 5) && key !== 8) {
            $event.target.value = value + '/';
            return $event;
        } else if (value.length === 2 && key !== 8) {
            $event.target.value = value + '/';
            return $event;
        }
        return $event;
    }
    public AddRemoveHyphen(value: string, addRemoveState: boolean) {
        if (!value) {
            return CommonConstants.DEFAULT_EMPTY_STRING;
        }
        return addRemoveState ? value.match(
            new RegExp('.{1,4}', 'g')).join('-') : value.split('-').join('');
    }
    // Getting first/middle/last Name from one Name field
    public GetName(type: string, nameString: string): string {
        const nameValue = nameString.trim();
        const splitNameArr = nameValue.split(' ');
        const len = splitNameArr.length;
        const firstNameLen = (len > 2) ? (len - 2) : ((len < 2) ? len : len - 1);
        if (type === 'first') {
            let name = '';
            for (let i = 0; i < firstNameLen; i++) {
                name = name + ' ' + splitNameArr[i];
            }
            return name.trim();
        } else if (type === 'middle') {
            if (len - firstNameLen === 2) {
                return (splitNameArr[len - 2]).trim();
            } else {
                return '';
            }
        } else if (type === 'last') {
            if (len - firstNameLen >= 1) {
                return (splitNameArr[len - 1]).trim();
            } else {
                return '';
            }
        }
    }
    private inrFormat(nStr): string { // nStr is the input string
        nStr += '';
        const x = nStr.split('.');
        let x1 = x[0];
        const x2 = x.length > 1 ? '.' + x[1] : '';
        let rgx = /(\d+)(\d{3})/;
        let z = 0;
        const len = String(x1).length;
        let num = parseInt(((len / 2) - 1).toString(), 10);
        while (rgx.test(x1)) {
            if (z > 0) {
                x1 = x1.replace(rgx, '$1' + ',' + '$2');
            } else {
                x1 = x1.replace(rgx, '$1' + ',' + '$2');
                rgx = /(\d+)(\d{2})/;
            }
            z++;
            num--;
            if (num === 0) {
                break;
            }
        }
        return x1 + x2;
    }
    public ConvertNumberToAmountExtraPlusL(value: number) {
        let amount: string;
        if (value < 9999999) {
            amount = this.ConvertCurrenyToUnit(value,
                CurrencyCoversionUnits.Lacs).toString();
            amount = ((amount.indexOf('.') > -1) ?
                amount.slice(0, (amount.indexOf('.')) + 3) : amount) + 'L';
        } else if (value > 9999999) {
            amount = this.ConvertCurrenyToUnit(value,
                CurrencyCoversionUnits.Crore).toString();
            amount = ((amount.indexOf('.') > -1) ?
                amount.slice(0, (amount.indexOf('.')) + 3) : amount) + 'Cr';
        }
        return amount;
    }
    public ConvertNumberToAmountExtraPlus(value: number) {
        let amount: string;
        if (value < 9999999) {
            amount = this.ConvertCurrenyToUnit(value,
                CurrencyCoversionUnits.Lacs).toString();
            amount = ((amount.indexOf('.') > -1) ?
                amount.slice(0, (amount.indexOf('.')) + 3) : amount);
        } else if (value > 9999999) {
            amount = this.ConvertCurrenyToUnit(value,
                CurrencyCoversionUnits.Crore).toString();
            amount = ((amount.indexOf('.') > -1) ?
                amount.slice(0, (amount.indexOf('.')) + 3) : amount);
        }
        return parseInt(amount);
    }
}
