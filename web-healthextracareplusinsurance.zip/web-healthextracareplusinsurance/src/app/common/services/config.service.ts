import { Http, Response } from '@angular/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { CommonConstants } from './../utilities/commonConstants';
import { Title } from '@angular/platform-browser';
import { NavigationEnd, Router } from '@angular/router';
import { tap, catchError } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { environment } from './../../../environments/environment';
export interface RedirectUrlResponse {
    RedirectUrl: string;
    AuthId: string;
}
@Injectable({
    providedIn: 'root'
})
export class ConfigService {
    public static instance: ConfigService;
    public static isCreating: Boolean = false;
    private config: any;
    public static getInstance() {
        if (ConfigService.instance == null) {
            ConfigService.isCreating = true;
            ConfigService.instance = new ConfigService();
            ConfigService.isCreating = false;
        }
        return ConfigService.instance;
    }
    constructor(
    ) {
        if (!ConfigService.isCreating) {
            throw new Error('You can\'t call new in Singleton instances!' +
                'Call SingletonService.getInstance() instead.');
        }
    }
    /* config service to get the initial data - Service API Path, date objetc,
    default imagepath etc. */
    public getConfigData() {
        const baseUrlList = environment.serviceBaseUrls;
        const allApiUrl = CommonConstants.APIURL;
        for (const urlKey in baseUrlList) {
            if (baseUrlList[urlKey]) {
                for (const key in allApiUrl) {
                    if (allApiUrl[key]) {
                        allApiUrl[key] = allApiUrl[key].replace('{' + urlKey + '}', baseUrlList[urlKey]);
                    }
                }
            }
        }
        const config = {APIURL: allApiUrl};
        ConfigService.getInstance().setConfigObject(config);
        console.log('changed:', ConfigService.getInstance().getConfigObject());
    }
    public setConfigObject(cfg: any) {
        this.config = cfg;
    }
    public getConfigObject() {
        return this.config;
    }
}
