import { FormGroup } from '@angular/forms';
import { CommonConstants } from './../utilities/commonConstants';
import { Injectable, Inject } from '@angular/core';
import { AnalyticsService } from './device.analytics.service';
const AgeValidationMessages = {
    MinAgeError: 'Age cannot be less than {0} years.',
    MinAgeMonthError: 'Age cannot be less than {0} months.',
    MaxAgeError: 'Age cannot be more than {0} years.',
    Invalid: 'Please provide your correct date value.',
    AgeMatch: 'Age should be matched {0}.',
    futureDateError: 'Date of birth can\'nt be more than current date.'
};
const AllowedFileTypesForUpload: string[] = ['image/jpeg', 'application/pdf', 'image/png'];
const DOB_DATE_RANGES = {
    MaxAge: 80,
    MinAge: 18
  };
  // below 1 year
  const DOB_DATE_RANGES_CHILD = {
    MaxAge_Years: 25,
    MinAge_Months: 3
  };
@Injectable({
    providedIn: 'root'
})
export class FormValidator {
    private analyticsService: AnalyticsService;
    private OsType: string;
    private IsCorrectDateFormat = false;
    constructor(@Inject(AnalyticsService) analyticsService: AnalyticsService) {
        this.analyticsService = analyticsService;
        this.OsType = this.analyticsService.GetDeviceDetails()['os'];
    }
    public HasError(
        formGroup: FormGroup,
        field: string,
        errorProperty: string,
        isTouchedRequired: boolean = true): boolean {
        return formGroup && formGroup.controls &&
            formGroup.controls[field] &&
            (isTouchedRequired ? formGroup.controls[field].touched : true) &&
            formGroup.controls[field].errors &&
            formGroup.controls[field].errors[errorProperty];
    }
    public FieldHasErrors(
        formGroup: FormGroup,
        field: string,
        isTouchedRequired: boolean = true): boolean {
        return formGroup && formGroup.controls &&
            formGroup.controls[field] &&
            (isTouchedRequired ? formGroup.controls[field].touched : true)
            && formGroup.controls[field].errors != null;
    }
    public FieldHasSpecificError(
        formGroup: FormGroup,
        formControl: string,
        errorType: string
    ): boolean {
        return formGroup && formGroup.controls && formGroup.controls[formControl] &&
            formGroup.controls[formControl].hasError &&
            formGroup.controls[formControl].hasError(errorType);
    }
    public IsDateOfBirthValid(
        updatedValue: any,
        serverDateString: string,
        minAge: number, maxAge: number) {
        let errorMessage: string = null;
        const month = updatedValue.Month ? parseInt(updatedValue.Month, 10) : '';
        const dateOfBirth = month.toString().concat('/', updatedValue.Day, '/', updatedValue.Year);
        let ageTillDateInYears = 0;
        let ageTillDateInMonths = 0;
        let ageTillDateInDays = 0;
        if (this.IsLeapYear(dateOfBirth)) {
            const birthDay = new Date(dateOfBirth);
            const todayDate = new Date();
            const calculatedAgeDifference: number[] = this.CalculateAge(birthDay);
            ageTillDateInYears = calculatedAgeDifference[0];
            ageTillDateInMonths = calculatedAgeDifference[1];
            ageTillDateInDays = calculatedAgeDifference[2];
            if (ageTillDateInYears > minAge && ageTillDateInYears <= maxAge) {
                errorMessage = null;
            } else if (ageTillDateInYears === minAge) {
                if (ageTillDateInMonths > 0) {
                    errorMessage = null;
                } else if (ageTillDateInDays <= 0) {
                    errorMessage = AgeValidationMessages.MinAgeError.replace('{0}', minAge.toString());
                }
            } else {
                errorMessage = (ageTillDateInYears < minAge) ?
                    AgeValidationMessages.MinAgeError.replace('{0}', minAge.toString()) :
                    (ageTillDateInYears > maxAge - 1) ?
                        AgeValidationMessages.MaxAgeError.replace('{0}', maxAge.toString()) : null;
            }
        } else {
            errorMessage = AgeValidationMessages.Invalid;
        }
        return errorMessage;
    }
    public IsLeapYear(input) {
        const date = new Date(input);
        input = input.split('/');
        return date.getMonth() + 1 === +input[0] &&
            date.getDate() === +input[1] && date.getFullYear() === +input[2];
    }
    public IsAlphabet($event: any) {
        if (this.OsType.toLowerCase() !== 'android') {
            const charCode = ($event.which) ? $event.which : $event.keyCode;
            return !(charCode > 32 && (charCode < 65 || charCode > 90)
                && (charCode < 97 || charCode > 122) || charCode ==  8377);
        } else {
            let charStatus;
            charStatus = $event.key.toString()
                .match(/[0-9~`!#$%\^&*+=\-\[\]\\';,/()_{}|\\":<>\?₹]/g);
            if (charStatus) {
                return false;
            } else {
                return true;
            }
        }
    }
    public IsSpace($event: any) {
        const charCode = ($event.which) ? $event.which : $event.keyCode;
        return !(charCode !== 32);
    }
    public IsNumeric($event: any, rejectStartingWithZero?: boolean, rejectStartWithOne?: boolean) {
        if (this.OsType.toLowerCase() !== 'android') {
            const charCode = ($event.which) ? $event.which : $event.keyCode;
            const objValue = $event.target.value ? $event.target.value : '';
            if (rejectStartingWithZero && charCode === 48 && objValue.length < 1) {
                return false;
            } else if (rejectStartWithOne && charCode === 49 && objValue.length < 1) {
                return false;
            } else if (($event.target.selectionEnd - $event.target.selectionStart > 0)
                && charCode === 48) {
                return !(rejectStartingWithZero && charCode === 48);
            } else {
                return !(charCode > 31 && (charCode < 48 || charCode > 57));
            }
        } else {
            let charStatus;
            charStatus = $event.key.toString()
                .match(/[A-Za-z~`!#$%\^&*+=\-\[\]\\';,/()_{}|\\":<>\?\s]/g);
            if (charStatus) {
                return false;
            } else {
                return true;
            }
        }
    }
    public IsWholeNumber($event: any) {
        const charCode = ($event.which) ? $event.which : $event.keyCode;
        return !(charCode < 48 || charCode > 57);
    }
    public IsCharacterWithInMaxLength(value: string, maxLength: number): boolean {
        value = value ? value.trim() : CommonConstants.DEFAULT_EMPTY_STRING;
        return (value.length > maxLength - 1) ? false : true;
    }
    public addingZero($event) {
        const DD = $event.target.value;
        if (DD >= 1 && DD < 10 && DD.length < 2) {
            $event.target.value = '0' + DD;
        } else {
            $event.target.value = DD;
        }
    }
    public IsFileTypeSupported(fileType: string): boolean {
        return AllowedFileTypesForUpload.indexOf(fileType) !== -1;
    }
    public IsFileSizeValid(size: number, maxSizeInMBs: number): boolean {
        return size <= maxSizeInMBs * 1048576; // 1MB == 1048576
    }
    public IsFutureDate(dateString: string): string {
        // Assuming MM/DD/YYYY or MM/YYYY date Format as parameter.
        let isFutureDateMsg: string = null;
        const currentDate = new Date();
        const dateSplit = dateString.toString().split('/');
        const len = dateSplit.length;
        const year = parseInt(dateSplit[len - 1], 10);
        const month = parseInt(dateSplit[0], 10);
        const day = (len > 2) ? parseInt(dateSplit[len - 2], 10) : null;
        if (dateString && month && year) {
            if (year && currentDate.getFullYear() > year) {
                isFutureDateMsg = null;
            } else if (year && currentDate.getFullYear() === year && month
                && (currentDate.getMonth() + 1) >= month) {
                if (day && currentDate.getDate() < day && (currentDate.getMonth() + 1 === month)) {
                    isFutureDateMsg = 'Future date is not a valid date';
                } else if (!day) {
                    isFutureDateMsg = null;
                } else {
                    isFutureDateMsg = null;
                }
            } else {
                isFutureDateMsg = 'Future date is not a valid date';
            }
        }
        return isFutureDateMsg;
    }
    public IsValidDate(dateString: string) {
        // Assuming DD/MM/YYYY date Format as parameter.
        let isValidDate = false;
        const dateSplit = dateString.split('/');
        const createdDate = dateSplit[1] + '/' + dateSplit[0] + '/' + dateSplit[2];
        const selectedDate = new Date(createdDate);
        if (selectedDate && selectedDate.getTime() &&
            (parseInt(dateSplit[1], 10) === selectedDate.getMonth() + 1)) {
            isValidDate = true;
        }
        return isValidDate;
    }

    public IsSpaceInput(formGroup, field) {
        const value = formGroup.controls[field].value;
        if (!value || value.trim() === '') {
            formGroup.controls[field].setValue('');
        }
    }
    public CheckAmountAvailibility(event, formGroup, controlName) {
        const value: number = parseInt(event.target.value.replace(/\,/g, ''), 10);
        if (!value || value <= 0) {
            formGroup.controls[controlName].setValue('');
        }
    }
    public CalculateAge(startDate: Date) {
        const today = new Date();
        const nowMon = today.getMonth();
        let monNum = nowMon + 1;
        if (monNum === 12) {
            monNum = 0;
        }
        const nowDay = today.getDate();
        const nowYear = today.getFullYear();
        const nowTime = today.getTime();

        const sDate = startDate;
        const eDate = today;

        const sTime = sDate.getTime();
        const eTime = eDate.getTime();

        const timeDiff = eTime - sTime;
        const vNumDays = Math.round(timeDiff / 86400000);
        const mdy = this.getTimeBetween(sDate, eDate);
        let dayStr = 'days';
        if (mdy[2] === 1) {
            dayStr = 'day';
        }
        let monStr = 'months';
        if (mdy[1] === 1) {
            monStr = 'month';
        }
        let yrStr = 'years';
        if (mdy[0] === 1) {
            yrStr = 'year';
        }
        console.log('' + mdy[0] + ' ' + yrStr + ', ' + mdy[1] +
            ' ' + monStr + ', and ' + mdy[2] + ' ' + dayStr + '');
        return mdy;
    }
    private getTimeBetween(from: Date, until: Date) {
        let past = from;
        let future = until;

        if (past >= future) {
            const tmp = past;
            past = future;
            future = tmp;
        }
        const between = [
            future.getFullYear() - past.getFullYear(),
            future.getMonth() - past.getMonth(),
            future.getDate() - past.getDate()
        ];
        if (between[2] < 0) {
            between[1]--;
            const ynum = future.getFullYear();
            const mlengths = [
                31,
                (ynum % 4 === 0 && ynum % 100 !== 0 || ynum % 400 === 0) ? 29 : 28,
                31, 30, 31, 30, 31, 31, 30, 31, 30, 31
            ];
            let mnum = future.getMonth() - 1;
            if (mnum < 0) {
                mnum += 12;
            }
            between[2] += mlengths[mnum];
        }
        if (between[1] < 0) {
            between[0]--;
            between[1] += 12;
        }
        return between;
    }
    public ValidateDOBYearAndMonth(updatedValue, PersonalDetailsFormGroup, Relation, Age) {
        if (!PersonalDetailsFormGroup) {
          return null;
        }
        const formData = {
          ...PersonalDetailsFormGroup.value,
          ...updatedValue
        };
        if (formData.day && formData.month && formData.year) {
          let validationErr = null;
          const DOBObj = {
            Day: formData.day,
            Month: formData.month,
            Year: formData.year
          };
          let error = null;
          const age = this.showAge(formData.year, formData.month, formData.day);
          if (!this.IsCorrectDateFormat) {
          if (Relation !== 'SON' && Relation !== 'DAUGHTER') {
            error = this.IsDateOfBirthValid(
              DOBObj,
              null,
              DOB_DATE_RANGES.MinAge,
              DOB_DATE_RANGES.MaxAge
            );
          } else {
            if (age.AgeYears > DOB_DATE_RANGES_CHILD.MaxAge_Years) {
              error = AgeValidationMessages.MinAgeError.replace('{0}', DOB_DATE_RANGES_CHILD.MaxAge_Years.toString());
            } else if (age.AgeYears === 0 && age.AgeMonths < DOB_DATE_RANGES_CHILD.MinAge_Months) {
              error = AgeValidationMessages.MinAgeMonthError.replace('{0}', DOB_DATE_RANGES_CHILD.MinAge_Months.toString());
            }
          }
          if (Age != null) {
            if (age.AgeYears !== Age) {
              error = AgeValidationMessages.AgeMatch.replace('{0}', Age.toString());
            }
          }
          if (error) {
            validationErr = { rangeError: error };
          } else {
            const currDate = new Date();
            const dobDate = new Date(DOBObj.Year, DOBObj.Month, DOBObj.Day);
            if (currDate < dobDate) {
              validationErr = {
                futureDateError: AgeValidationMessages.futureDateError
              };
            }
          }
        } else {
           validationErr = { rangeError: 'Please enter correct date' };
          }
          const cl = Object.keys(updatedValue)[0];
          ['year', 'month', 'day']
            .filter(c => c !== cl)
            .forEach(c =>
              PersonalDetailsFormGroup.controls[c].setErrors(validationErr)
            );
          return validationErr;
        }
      }
      // mobile specific changes
      public IsAlphaMobile($event: any, formGroup, field) {
        if (this.OsType.toLowerCase() === 'android') {
            // Field Validation
            $event.target.value = $event.target.value.toString().replace(/[^A-Za-z\s]/g, '');
            let value = formGroup.controls[field].value;
            if (value) {
                formGroup.controls[field]
                    .setValue(value.toString().replace(/[^A-Za-z\s]/g, ''));
            }
            return false;
        }
     }
      private showAge(dobYear, dobMonth, dobDay) {
        const DOBObj = {
          Day: dobDay,
          Month: dobMonth,
          Year: dobYear
        };
        const dateOfBirth = dobMonth.toString().concat('/', dobDay, '/', dobYear);
        if (this.IsLeapYear(dateOfBirth)) {
        let bthDate, curDate, days;
        let ageYears, ageMonths;
        bthDate = new Date(dobYear, dobMonth - 1, dobDay);
        curDate = new Date();
        if (bthDate > curDate) { return; }
        const timeDiff = Math.abs(Date.now() - bthDate.getTime());
        days = Math.floor((curDate - bthDate) / (1000 * 60 * 60 * 24));
        ageYears = Math.floor((timeDiff / (1000 * 3600 * 24)) / 365.25);
        ageMonths = Math.floor((days % 365) / 31);
        const age = {
          AgeMonths: ageMonths,
          AgeYears: ageYears
        };
        this.IsCorrectDateFormat = false;
        return age;
      } else {
        this.IsCorrectDateFormat = true;
    }
 }
}
