import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { ConfigService } from './config.service';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Title } from '@angular/platform-browser';
import { NavigationEnd, Router } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class ConfigResolve implements Resolve<ConfigService> {
  constructor(
    private _router: Router,
    private _titleService: Title
  ) { }
  public resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot):
    Observable<any> | Promise<any> | any {
    return this.setRouteTitle();
  }
  private setRouteTitle() {
    this._router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        const title = this.getTitle(this._router.routerState,
          this._router.routerState.root).join('-');
        let newTitle = this._titleService.getTitle();
        newTitle = newTitle.split(':')[0];
        this._titleService.setTitle(newTitle + ' : ' + title);
      }
    });
    return ConfigService.getInstance().getConfigData();
  }
  private getTitle(state, parent) {
    const data = [];
    if (parent && parent.snapshot.data && parent.snapshot.data.title) {
      data.push(parent.snapshot.data.title);
    }
    if (state && parent) {
      data.push(... this.getTitle(state, state.firstChild(parent)));
    }
    return data;
  }
}
