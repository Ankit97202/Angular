import { CookieService } from 'ngx-cookie-service';
import { Injectable } from '@angular/core';
@Injectable({
    providedIn: 'root'
})
export class CookieHandlerService {
    constructor(
        private cookieService: CookieService
    ) {}
    public SetCookie(key: string, value: any): void {
        this.cookieService.set(key, value, null, '/', null, true);
    }
    public GetCookie(key: string, applicationId?: string): string {
        if (!applicationId) {
            return this.cookieService.get(key);
        } else {
            return this.cookieService.get(applicationId + '_' + key);
        }
    }
    public DeleteCookies(keys: string[]): void {
        keys.forEach((key: string, index: number) => {
            this.cookieService.delete(key, '/');
        });
    }
    public FlushAll(): void {
        this.cookieService.deleteAll();
    }
}
