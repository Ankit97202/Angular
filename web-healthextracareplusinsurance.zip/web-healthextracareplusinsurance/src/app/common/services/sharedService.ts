import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class SharedService {
  public _sharingData = {};
  public setData(prop: string, value: any) {
    // internally mutate our state
    this._sharingData[prop] = value;
  }
  public getData(prop?: any) {
    // use our state getter for the clone
    const data = this._sharingData;
    return data.hasOwnProperty(prop) ? data[prop] : ''; // data;
  }
}
