import { Messages } from './../utilities/messages';
import { CommonConstants } from './../utilities/commonConstants';
import { Injectable } from '@angular/core';
import { ConfigService } from './../services/config.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CookieHandlerService } from './../services/cookieHandler.service';
@Injectable({
    providedIn: 'root'
})
export class PincodeHandlerService {
    public LocationErrorMessage: string;
    public IsUnSupportedCityOrState: boolean;
    public IsUnSupportedCountry: boolean;
    public IsDeclarationGiven: boolean;
    public DeviceLatitude;
    public DeviceLongitude;
    public GeoLocationDetails;
    constructor(
        private _http: HttpClient,
        private _cookieHandler: CookieHandlerService
    ) { }
    public OnPinCodeChanged($event, callback) {
        const pinCodeValue = $event.target.value || '';
        this.LocationErrorMessage = null;
        this.IsUnSupportedCityOrState = false;
        if (pinCodeValue && pinCodeValue.length === 6) {
            this.getLocationBasedOnPinCode(pinCodeValue)
                .subscribe((response) => {
                    this.handleGeoLocationReponse(response);
                    callback();
                });
        }
    }
    private handleGeoLocationReponse(mtResponse) {
        console.log('mtResponse.errorBean:', mtResponse.errorBean);
        if (mtResponse.errorBean && mtResponse.errorBean.length > 0) {
            this.DeviceLatitude = mtResponse.payload && mtResponse.payload.latitude;
            this.DeviceLongitude = mtResponse.payload && mtResponse.payload.longitude;
            mtResponse.errorBean.forEach((item: { errorCode: string, errorMessage: string },
                index: number) => {
                if (item.errorCode === Messages
                    .GeoLocationErrorMessages.UnSupportedCountry) {
                    this.handleUnSupportedCountry();
                } else if (item.errorCode === Messages
                    .GeoLocationErrorMessages.UnSupportedCity) {
                    this.handleUnSupportedCityOrState(mtResponse.payload);
                } else if (item.errorCode === Messages
                    .GeoLocationErrorMessages.UnSupportedState) {
                    this.handleUnSupportedCityOrState(mtResponse.payload);
                } else {
                    this.handleInvalidPinCode();
                }
            });
        } else {
            this.updateLocationValues(mtResponse.payload);
        }
    }
    private handleUnSupportedCityOrState(response: GeoLocationDetails) {
        this.IsUnSupportedCityOrState = true;
        this.IsUnSupportedCountry = true;
        this.updateLocationValues(response);
        this.IsDeclarationGiven = false;
        this.LocationErrorMessage = Messages.LocationErrorMessages.UnSupportedCity;
    }
    private handleUnSupportedCountry() {
        this.IsUnSupportedCountry = true;
        this.IsDeclarationGiven = false;
        this.LocationErrorMessage = Messages.LocationErrorMessages.UnSupportedCountry;
    }
    private handleInvalidPinCode() {
        this.LocationErrorMessage = Messages.LocationErrorMessages.InvalidPin;
        this.GeoLocationDetails = null;
    }
    private updateLocationValues(response: GeoLocationDetails) {
        console.log('response:', response);
        this.GeoLocationDetails = response;
    }
    private getLocationBasedOnPinCode(pinCode: number) {
        const url = ConfigService.getInstance().getConfigObject()
            .APIURL.getGeoLocationBasedOnPin.replace('{0}', pinCode.toString());
        const options = { headers: this.getHeaders() };
        return this._http.get(url, options);
    }
    private getHeaders = (): HttpHeaders => {
        const headerObj: HttpHeaders = new HttpHeaders({
            'Content-Type': 'application/json',
            'cmptcorrid': '',
            'authtoken': this._cookieHandler.GetCookie(CommonConstants.CookieKeys.JWToken),
            'guardtoken': this._cookieHandler.GetCookie(CommonConstants.CookieKeys.GuardToken),
        });
        return headerObj;
    }
}
