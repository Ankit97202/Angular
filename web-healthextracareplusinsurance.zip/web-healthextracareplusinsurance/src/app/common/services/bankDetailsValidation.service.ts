import { Headers, Http, RequestOptions } from '@angular/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { CommonConstants } from '../../common/utilities/commonConstants';
import { HttpInterceptor } from '../../common/services/httpInterceptor.service';
import { ConfigService } from '../../common/services/config.service';
@Injectable()
export class BankDetailsValidationService {
    constructor(private _httpInterceptor: HttpInterceptor) { }
    public FetchBankDetails(data, paramValue): Observable<ActivitiModel.MTResponse<any>> {
        let url = ConfigService.getInstance().getConfigObject()
            .APIURL.getBanks.concat(data, CommonConstants.URL_SEPARATOR, paramValue);
        return this._httpInterceptor.Get(url, true);
    }
}
