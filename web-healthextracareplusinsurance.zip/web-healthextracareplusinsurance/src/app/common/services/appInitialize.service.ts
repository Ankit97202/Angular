import { Injectable } from '@angular/core';
import { HttpInterceptor } from './httpInterceptor.service';
import { environment } from '../../../environments/environment';
@Injectable({
    providedIn: 'root'
})
export class AppInitializeService {
    constructor(private httpInterceptor: HttpInterceptor) { }
    public initializeApp(): Promise<any> {
        console.log('Environment is:' + environment['serviceBaseUrl']);
        return new Promise(() => {
            this.httpInterceptor.Get(environment['serviceBaseUrl'] + '/v1/logins/ui/keys/bflclient').subscribe((response) => {
            });
        });
    }
    private setupEnvironmentEndpoints() {
        switch (environment['name']) {
            case 'uat':
                break;

            default:
                break;
        }
    }
}
