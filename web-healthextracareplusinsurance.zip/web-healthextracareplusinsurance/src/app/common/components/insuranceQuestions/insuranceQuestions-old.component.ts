import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { FormValidator } from './../../services/formValidator.service';
import { Formatter } from './../../services/formatter';
import { CommonConstants } from './../../utilities/commonConstants';
import { ConfigService } from './../../services/config.service';
import { ActivitiHandlerService } from './../../services/activitiHandler.service';
import { RouteContextProvider } from './../../services/routeContextProvider.service';
import { RouteHandlerService } from './../../services/routeHandler.service';
const FormControlNames = {
    BOOLEAN: 'optionalInput',
    SELECTION: 'selectorInput',
    CHECKBOX: 'checkbox',
    BUTTON: 'selectionInput',
    NOTEXT: 'dependentInput'
};
const Input_Types = {
    ReadOnly: 'ReadOnly',
    Selection: 'Selection',
    Dynamic: 'Dynamic',
    Button: 'Button',
    Date: 'Date',
    Boolean: 'Boolean',
    InputBox: 'InputBox',
    CheckBox: 'CheckBox',
};
const ValidationTypes = {
    Numeric: 'numeric',
    Text: 'text'
};
@Component({
    selector: 'app-questions',
    styleUrls: ['./insuranceQuestions.style.css'],
    templateUrl: './insuranceQuestions.template.html'
})
export class InsuranceQuestionsOldComponent implements OnInit {
    public QuestionsList: Model.Questions[];
    public SectionList;
    public InsuranceQuestionsList: Models.InsuranceQuestionsList = <Models.InsuranceQuestionsList>{};
    public InputTypes = Input_Types;
    public FormGroupArr: FormGroup[] = [];
    public FormControlNames = FormControlNames;
    public AllUserAnswers: Models.InsuranceQuestionnaireResponse[] = [];
    public TotalNumOfQuestions: any = 0;
    public DateOfBirthErrorString: string = null;
    public ShowAllAnswers = false;
    public pageTitle = 'Insurance questions';
    public IsAnswersMapped = false;
    public RoI = 8.8; // hardcoded to be changed
    public IsPreFilledForm = false;
    public ShowLoader = false;
    public ShowBackLoader = false;
    public Validations = ValidationTypes;
    public IsReadOnlySummary = true;
    public SummaryConfigObject: Models.SummaryConfigObject;
    public Formatter;
    private dependentQuestionKeyArr: string[] = [];
    private _selectedCheckboxValues: Models.ResponseOption[] = [];
    // Constructor
    constructor(
        public Formatters: Formatter,
        public FormValidators: FormValidator,
        private _formBuilder: FormBuilder,
        private _activityService: ActivitiHandlerService,
        private _routeContextProvider: RouteContextProvider,
        private _routerService: RouteHandlerService
    ) {
        this.Formatter = Formatters;
    }
    // Init
    public ngOnInit(): void {
        this.getTaskDetails();
    }
    // Selection Of Checkbox Which has Same dependent Questions
    public SelectCheckboxOption(question: Models.Question, userAnswer: Models.ResponseOption) {
        let toSelect = true;
        let toRemoveIndex: number;
        for (const index in this._selectedCheckboxValues) {
            if (this._selectedCheckboxValues[index]) {
                const option = this._selectedCheckboxValues[index];
                if (userAnswer.QuestionResponseKey === option.QuestionResponseKey) {
                    toSelect = false;
                    toRemoveIndex = parseInt(index, 10);
                    break;
                } else {
                    toSelect = true;
                }
            }
        }
        if (toSelect) {
            this._selectedCheckboxValues.push(userAnswer);
        } else {
            this._selectedCheckboxValues.splice(toRemoveIndex, 1);
        }
        this.checkDependentQuestionVisibility(question, userAnswer, toSelect);
    }
    // Checking Next Question As per User Answer
    public CheckNextQuesExist(question: Models.Question, userAnswer: Models.ResponseOption, toToggle: boolean) {
        // toToggle flag true is only for the checkbox elements where each checkbox has different dependent question
        let nextQuesKey: number;
        let toDisplay = false;
        for (const index in question.ResponseOptions) {
            if (question.ResponseOptions[index]) {
                const responseOption = question.ResponseOptions[index];
                if (responseOption.NextQuestionKey) {
                    nextQuesKey = responseOption.NextQuestionKey;
                }
                if (userAnswer && userAnswer.ResponseText === responseOption.ResponseText
                    && responseOption.NextQuestionKey) {
                    toDisplay = true;
                    break;
                } else if (userAnswer) {
                    if (toToggle) {
                        nextQuesKey = null;
                    }
                    toDisplay = false;
                } else { // userAnswer null means have to remove all dependent ques of removed form
                    toDisplay = false;
                }
            }
        }
        if (nextQuesKey) {
            this.setDisplayToDependentQues(nextQuesKey, toDisplay, toToggle);
        }
        if (toToggle && userAnswer) {
            const answerValue = 'Y';
            this.setAnswerToQuestion(question.Id, question.Key, userAnswer, answerValue, toToggle);
        } else if (userAnswer) {
            this.setAnswerToQuestion(question.Id, question.Key, userAnswer);
        }
    }
    // Selecting From Selection Field
    public OnSelect(question: Models.Question, userAnswer: string) {
        let responseOption: Models.ResponseOption;
        for (const index in question.ResponseOptions) {
            if (userAnswer === question.ResponseOptions[index].ResponseText) {
                responseOption = question.ResponseOptions[index];
                break;
            }
        }
        this.setAnswerToQuestion(question.Id, question.Key, responseOption);
    }
    // On Blur of Text/Numric Input type
    public OnBlur(
        questionId: string,
        questionKey: number,
        answer: Models.ResponseOption,
        userAnswer: string) {
        this.setAnswerToQuestion(questionId, questionKey, answer, userAnswer);
    }
    public Next() {
        this.ShowLoader = true;
        const responseTemplateBean = this.getResponsePayload();
        this._markTaskAsCompleted(responseTemplateBean, '');
        console.log('insurance Ques List::', this.InsuranceQuestionsList);
    }
    // Check All Forms Are Valid or not
    public CheckAllFormsValidity() {
        let isValid = true;
        if (!this.IsPreFilledForm) {
            for (const index in this.FormGroupArr) {
                if (this.FormGroupArr[index]) {
                    const form = this.FormGroupArr[index];
                    for (const controlIndex in form.controls) {
                        if (form.controls[controlIndex] && controlIndex
                            !== FormControlNames.BUTTON && controlIndex
                            !== FormControlNames.CHECKBOX) {
                            isValid = !this.FormValidators.FieldHasErrors(form, controlIndex, false);
                            if (!isValid) {
                                break;
                            }
                        } else if (controlIndex === FormControlNames.CHECKBOX) {
                            console.log('index', index);
                            console.log('AllUserAnswers', this.AllUserAnswers);
                            for (const item of this.AllUserAnswers) {
                                const formName = item.questionId + 'FormGroup';
                                if (index !== formName) {
                                    isValid = false;
                                } else {
                                    isValid = true;
                                    break;
                                }
                                console.log('element:', item);
                            }
                        }
                    }
                    if (!isValid) {
                        break;
                    }
                }
            }
        } else {
            isValid = this.IsPreFilledForm;
        }
        return isValid;
    }
    public GoBack() {
        this.ShowBackLoader = true;
        if (!this.ShowAllAnswers) {
            this._markTaskAsCompleted(null, 'Back');
        } else {
            this.ShowBackLoader = false;
            this.ShowAllAnswers = false;
            window.scrollTo(0, 0);
        }
    }
    // Checking Display Option for Same Dependent Question In Multiple Questions
    private checkDependentQuestionVisibility(question: Models.Question, userAnswer: Models.ResponseOption, isSelected: boolean) {
        const selectedOptNextQuesKey = userAnswer.NextQuestionKey;
        let toDisplay: boolean;
        const answerValue = 'Y';
        for (const respOpt of this._selectedCheckboxValues) {
            const nextQuesKey = respOpt.NextQuestionKey;
            if (!isSelected) {
                if (selectedOptNextQuesKey === nextQuesKey) {
                    toDisplay = true;
                    break;
                } else {
                    toDisplay = false;
                }
            }
        }
        this.setAnswerToQuestion(question.Id, question.Key, userAnswer, answerValue, true);
        if (!isSelected) {
            this.setDisplayToDependentQues(selectedOptNextQuesKey, toDisplay, false);
        } else {
            this.setDisplayToDependentQues(selectedOptNextQuesKey, true, false);
        }
    }
    // Setting Dymanic Form Controls of Dependent Questions
    private setDisplayToDependentQues(nextQuesKey: number, toDisplay: boolean, toToggle: boolean) {
        for (const sectionIndex in this.InsuranceQuestionsList.Sections) {
            if (this.InsuranceQuestionsList.Sections[sectionIndex]) {
                const section = this.InsuranceQuestionsList.Sections[sectionIndex];
                for (const queIndex in section.Questions) {
                    if (section.Questions[queIndex]) {
                        const ques = section.Questions[queIndex];
                        if (nextQuesKey === ques.Key) {
                            ques.ToDisplay = toToggle ? !ques.ToDisplay : toDisplay;
                            if (ques.ToDisplay) {
                                this.createForms(ques);
                            } else {
                                this.removeFroms(ques);
                                this.removeAllDefaultSelections(ques);
                                this.CheckNextQuesExist(ques, null, toToggle);
                                this.setAnswerToQuestion(ques.Id, ques.Key, null);
                            }
                        }
                    }
                }
            }
        }
    }
    // Activity Call of MArk Task As Completed
    private _markTaskAsCompleted(data: Models.InsuranceResponse, action: string, callback?) {
        this._activityService.MarkTaskAsCompleted(data, action, true).subscribe((mtResponse: ActivitiModel.MTResponse<any>) => {
            this.ShowBackLoader = false;
            this.ShowBackLoader = false;
            if (!mtResponse.errorBean) {
                this._routerService.RouteToNextTask(mtResponse.nextTaskKey);
            } else {
                console.error('Error::', mtResponse.errorBean);
            }
        });
    }
    // Getting Data On Initialization
    private getTaskDetails(): void {
        this._activityService.GetTaskDetails().subscribe((mtResponse: ActivitiModel.MTResponse<any>) => {
            if (!mtResponse.errorBean) {
                this.SummaryConfigObject = mtResponse.payload.healthPlanDetails;
                this.mapResponseData(mtResponse);
                this.setDefaultAnswers();
                if (mtResponse.userInput) {
                    this.setUserInput(mtResponse.userInput);
                }
            }
        });
    }
    // Setting User input
    private setUserInput(userInput: Models.InsuranceResponse) {
        if (this.InsuranceQuestionsList.ProductCode === userInput.insProductPlanCode) {
            this._mapInsuranceQuesAnswers(userInput);
            this.pageTitle = 'Review Answers';
        } else {
            this.ShowAllAnswers = false;
            this.pageTitle = this.InsuranceQuestionsList.ProductDescription + ' questions';
        }
    }
    // Maping Ansewrs to Question List
    private _mapInsuranceQuesAnswers(responseTemplateBean: Models.InsuranceResponse) {
        this.IsAnswersMapped = true;
        let isQuestionmatched = false;
        for (const section of this.InsuranceQuestionsList.Sections) {
            for (const question of section.Questions) {
                for (const responseValue of responseTemplateBean.responseTemplate) {
                    if (responseValue.questionKey === question.Key) {
                        isQuestionmatched = true;
                        const toAddAnswer = this.checkAvailableAnswer(question, responseValue);
                        if (toAddAnswer) {
                            const userAnswer: Models.InsuranceQuestionnaireResponse =
                                <Models.InsuranceQuestionnaireResponse>{};
                            userAnswer.questionKey = responseValue.questionKey;
                            userAnswer.questionResponseKey = responseValue.questionResponseKey;
                            userAnswer.questionResponseBean = responseValue.questionResponseBean;
                            question.Response.push(userAnswer);
                            if (question.InputType === this.Formatters
                                .toSmallCase(this.InputTypes.InputBox)) {
                                this.setResponseOfInputs(question, userAnswer,
                                    question.Key, question.ResponseOptions);
                            } else if (question.InputType === this.Formatters
                                .toSmallCase(this.InputTypes.CheckBox)) {
                                this.setDefaultValueOfCheckBox(question, userAnswer, true);
                            } else {
                                this.setDefaultValue(question, userAnswer);
                            }
                        }
                        break;
                    }
                }
                if (!isQuestionmatched) {
                    for (const responseOption of question.ResponseOptions) {
                        if (responseOption.DefaultSelection && (
                            responseOption.ResponseText === 'Yes'
                            || responseOption.ResponseText === 'No')) {
                            const userAnswer: Models.InsuranceQuestionnaireResponse =
                                <Models.InsuranceQuestionnaireResponse>{};
                            const answer: Models.InsuranceAnswer = <Models.InsuranceAnswer>{};
                            answer.questionResponse = responseOption.ResponseText;
                            answer.questionResponseValue = responseOption.ResponseText;
                            userAnswer.questionKey = question.Key;
                            userAnswer.questionResponseKey = responseOption.QuestionResponseKey;
                            userAnswer.questionResponseBean = [answer];
                            if (!question.Response || (question.Response &&
                                question.Response.length === 0)) {
                                question.Response = [];
                                question.Response.push(userAnswer);
                            }
                        }
                    }
                }
            }
        }
        console.log('List:', this.InsuranceQuestionsList);
    }
    // Check if answer is already added
    private checkAvailableAnswer(ques: Models.Question, responseValue: Models.InsuranceQuestionnaireResponse) {
        let toAdd = true;
        if (ques.InputType === this.Formatters.toSmallCase(this.InputTypes.InputBox)) {
            for (let response of ques.Response) {
                if (response.questionResponseKey === responseValue.questionResponseKey) {
                    for (const index in response.questionResponseBean) {
                        if (response.questionResponseBean[index]) {
                            let ans = response.questionResponseBean[index];
                            for (const userAns of responseValue.questionResponseBean) {
                                if (ans.questionResponse === userAns.questionResponse &&
                                    ans.questionResponseValue !== userAns.questionResponseValue) {
                                    ans = userAns;
                                    ques.Response[0].questionResponseBean[index] = userAns;
                                    break;
                                }
                            }
                        }
                    }
                    toAdd = false;
                } else {
                    toAdd = true;
                    response = null;
                }
            }
        } else if (ques.Response && ques.Response.length > 0) {
            toAdd = false;
            ques.Response = [responseValue];
            this.setDefaultValue(ques, responseValue);
        }
        return toAdd;
    }
    // Setting User's Previous Response to form controls
    private setResponseOfInputs(
        ques: Models.Question, userResponse: Models.InsuranceQuestionnaireResponse,
        key?: number, responseOptions?: Models.ResponseOption[]) {
        const id = ques.Id;
        if (id && userResponse) {
            for (const response of userResponse.questionResponseBean) {
                const formControl = (response.questionResponse && !ques.IsDependent) ?
                    response.questionResponse : this.FormControlNames.NOTEXT;
                this.FormGroupArr[id + 'FormGroup'].controls[formControl]
                    .setValue(response.questionResponseValue);
                for (const option of responseOptions) {
                    if (option.ResponseText === response.questionResponse) {
                        this.setAnswerToQuestion(id, key, option, response.questionResponseValue);
                    }
                }
            }
        }
    }
    // Setting Default Answers
    private setDefaultValue(question: Models.Question, userAnswer: Models.InsuranceQuestionnaireResponse) {
        for (const responseOption of question.ResponseOptions) {
            if (responseOption.QuestionResponseKey === userAnswer.questionResponseKey) {
                responseOption.DefaultSelection = true;
                this.CheckNextQuesExist(question, responseOption, false);
            } else {
                responseOption.DefaultSelection = false;
            }
        }
    }
    // Setting Default Answers to Checkbox input type
    private setDefaultValueOfCheckBox(
        question: Models.Question, userAnswer: Models.InsuranceQuestionnaireResponse, toToggle?: boolean) {
        // toToggle flag is used for the default selection Of Checkbox Which has Same dependent Questions
        for (const responseOption of question.ResponseOptions) {
            for (const obj of userAnswer.questionResponseBean) {
                if (responseOption.ResponseText === obj.questionResponse) {
                    responseOption.DefaultSelection = true;
                    if (toToggle) {
                        this.SelectCheckboxOption(question, responseOption);
                        break;
                    } else {
                        this.CheckNextQuesExist(question, responseOption, true);
                    }
                } else if (!responseOption.DefaultSelection) {
                    responseOption.DefaultSelection = false;
                }
            }
        }
    }
    // Mapping Data to Interface
    private mapResponseData(response: ActivitiModel.MTResponse<any>) {
        const data = response.payload;
        this.InsuranceQuestionsList.ProductCode = data['insuranceQues']['insProductPlanCode'];
        this.InsuranceQuestionsList.ProductDescription = data['insuranceQues']['insProductPlan'];
        this.InsuranceQuestionsList.Sections = [];
        for (const index in data['insuranceQues']['insPlanQueSets']) {
            if (data['insuranceQues']['insPlanQueSets'][index]) {
                const section = data['insuranceQues']['insPlanQueSets'][index];
                this.InsuranceQuestionsList.Sections.push(this.setSections(section));
            }
        }
        this.InsuranceQuestionsList.Sections.sort((a, b) => {
            return a.OrderNumber - b.OrderNumber;
        });
        this.pageTitle = this.InsuranceQuestionsList.ProductDescription + ' questions';
        this.setToDisplayOfQuestions();
        console.log('InsuranceQuestionsList', this.InsuranceQuestionsList);
    }
    // Setting Sections Of Insurance Question List
    private setSections(section): Models.Section {
        const SectionArray: Models.Section = <Models.Section>{};
        SectionArray.OrderNumber = this.orderBySection(section.headerDesc);
        SectionArray.Header = section.headerDesc;
        SectionArray.Questions = [];
        for (const index in section.insPlanQuestions) {
            if (section.insPlanQuestions[index]) {
                const question = section.insPlanQuestions[index];
                SectionArray.Questions.push(this.setQuestionsOfSection(question));
            }
        }
        SectionArray.Questions.sort((a, b) => {
            return a.OrderNumber - b.OrderNumber;
        });
        return SectionArray;
    }
    // Setting Questions of Section
    private setQuestionsOfSection(question): Models.Question {
        const QuestionArr: Models.Question = <Models.Question>{};
        this.TotalNumOfQuestions++;
        QuestionArr.Id = question.questionId;
        QuestionArr.Key = question.questionKey;
        QuestionArr.OrderNumber = question.displayOrder;
        QuestionArr.Description = question.questionDesc;
        QuestionArr.HelpText = question.helpText;
        QuestionArr.InputType = this.Formatters.toSmallCase(question.inputType);
        QuestionArr.ResponseOptions = [];
        QuestionArr.Response = [];
        for (const index in question.possibleAnswers) {
            if (question.possibleAnswers[index]) {
                const option = question.possibleAnswers[index];
                QuestionArr.ResponseOptions.push(this.setResponseOptionsToQuestion(option));
                QuestionArr.ResponseOptions.sort((a, b) => {
                    return a.OrderNumber - b.OrderNumber;
                });
            }
        }
        return QuestionArr;
    }
    // Setting Response Options/Possible Answers to the question
    private setResponseOptionsToQuestion(option): Models.ResponseOption {
        const responseOptionObj: Models.ResponseOption = <Models.ResponseOption>{};
        responseOptionObj.OrderNumber = option.responseOrder;
        responseOptionObj.ResponseText = option.questionResponse;
        responseOptionObj.NextQuestionKey = option.nextQuestion;
        responseOptionObj.QuestionResponseKey = option.questionResponseKey;
        responseOptionObj.Validation = option.validation || 'TEXT';
        responseOptionObj.DefaultSelection = option.defaultSelection === 'Y'
            ? true : false;
        if (option.nextQuestion) {
            this.dependentQuestionKeyArr.push(option.nextQuestion);
        }
        return responseOptionObj;
    }
    // Setting ToDisplay Property Of Question
    private setToDisplayOfQuestions() {
        for (const section of this.InsuranceQuestionsList.Sections) {
            for (const ques of section.Questions) {
                ques.IsDependent = this.checkDependentQuestion(ques.Key);
                ques.ToDisplay = false;
                if (!ques.IsDependent) {
                    this.createForms(ques);
                }
            }
        }
    }
    // Adding Dependent Form Group If Displayed
    private createForms(question: Models.Question) {
        const formName = question.Id + 'FormGroup';
        this.FormGroupArr[formName] = this._formBuilder.group({});
        for (const option of question.ResponseOptions) {
            const controlName = question.IsDependent ? (this.Formatters
                .toSmallCase(question.InputType) === this.Formatters.toSmallCase(
                    this.InputTypes.CheckBox) ? FormControlNames.CHECKBOX :
                FormControlNames.NOTEXT) : (this.Formatters
                    .toSmallCase(question.InputType) === this.Formatters.toSmallCase(
                        this.InputTypes.Button) ? FormControlNames.BUTTON : option.ResponseText);
            this.createFormGroupForQuestion(this.Formatters.toSmallCase(question.InputType),
                formName, controlName);
        }
    }
    // Removing Dependent Form Group If Hidden
    private removeFroms(question: Models.Question) {
        const formName = question.Id + 'FormGroup';
        console.log('this.FormGroupArr', this.FormGroupArr);
        for (const index in this.FormGroupArr) {
            if (this.FormGroupArr[index]) {
                if (index === formName) {
                    delete this.FormGroupArr[index];
                    break;
                }
            }
        }
    }
    // Removing all Default Selections And Response if not selected
    private removeAllDefaultSelections(question: Models.Question) {
        question.Response = [];
        for (const option of question.ResponseOptions) {
            option.DefaultSelection = false;
        }
    }
    // Creating Form Group for Question As per Intput InputType
    private createFormGroupForQuestion(controlType: string, formName, controlName: string) {
        controlName = controlName || controlName !== '' ? controlName : FormControlNames.NOTEXT;
        if (controlType === this.Formatters.toSmallCase(
            this.InputTypes.Boolean) &&
            !this.FormGroupArr[formName].contains(FormControlNames.BOOLEAN)) {
            this.FormGroupArr[formName].addControl(FormControlNames.BOOLEAN,
                new FormControl('', Validators.required));
        } else if (controlType === this.Formatters.toSmallCase(
            this.InputTypes.Selection) &&
            !this.FormGroupArr[formName].contains(FormControlNames.SELECTION)) {
            this.FormGroupArr[formName].addControl(FormControlNames.SELECTION,
                new FormControl('', Validators.required));
        } else if (controlType === this.Formatters.toSmallCase(
            this.InputTypes.InputBox) &&
            !this.FormGroupArr[formName].contains(controlName)) {
            this.FormGroupArr[formName].addControl(controlName,
                new FormControl('', Validators.required));
        } else if (controlType === this.Formatters.toSmallCase(
            this.InputTypes.CheckBox) &&
            !this.FormGroupArr[formName].contains(controlName)) {
            this.FormGroupArr[formName].addControl(controlName,
                new FormControl('', Validators.required));
        } else if (controlType === this.Formatters.toSmallCase(
            this.InputTypes.Button) && !this.FormGroupArr[formName].contains(controlName)) {
            this.FormGroupArr[formName].addControl(controlName,
                new FormControl('', Validators.required));
        }
    }
    // Checking Dependent Question By Id
    private checkDependentQuestion(currentQuesKey: any): boolean {
        if (this.dependentQuestionKeyArr && this.dependentQuestionKeyArr.length > 0) {
            for (const index in this.dependentQuestionKeyArr) {
                if (currentQuesKey === this.dependentQuestionKeyArr[index]) {
                    return true;
                }
            }
        }
        return false;
    }
    // Arrange Sections in Order
    private orderBySection(header: string): number {
        let order: number;
        if (header === 'Personal Details') {
            order = 1;
        } else if (header === 'Health Declaration') {
            order = 2;
        } else {
            order = 3;
        }
        return order;
    }
    // Create Response payload
    private getResponsePayload() {
        const payload: Models.InsuranceResponse = <Models.InsuranceResponse>{};
        payload.insProductPlan = this.InsuranceQuestionsList.ProductDescription;
        payload.insProductPlanCode = this.InsuranceQuestionsList.ProductCode;
        if (this.AllUserAnswers && this.AllUserAnswers.length > 0) {
            payload.responseTemplate = this.AllUserAnswers;
        }
        console.log('Payload Creater::', payload);
        return payload;
    }
    // Setting User Answer to Question
    private setAnswerToQuestion(
        questionId: string,
        questionKey: number,
        resOption: Models.ResponseOption,
        answerValue?: string,
        toToggle?: boolean
    ) {
        const answer: Models.InsuranceAnswer = <Models.InsuranceAnswer>{};
        let toAddAnswer = true;
        const answerResponse: Models.InsuranceQuestionnaireResponse = <Models.InsuranceQuestionnaireResponse>{};
        let toAddAnswerResponse = true;
        let outerIndx: number;
        let innerIndx: number;
        answer.questionResponseValue = answerValue ? answerValue :
            resOption ? resOption.ResponseText : '';
        answer.questionResponse = resOption ? resOption.ResponseText : '';
        answerResponse.questionResponseKey = resOption ? resOption.QuestionResponseKey : null;
        answerResponse.questionKey = questionKey;
        answerResponse.questionId = questionId;
        answerResponse.questionResponseBean = [];
        answerResponse.questionResponseBean.push(answer);
        for (const index in this.AllUserAnswers) {
            if (!answerValue && answerResponse.questionKey ===
                this.AllUserAnswers[index].questionKey) {
                this.AllUserAnswers[index] = answerResponse;
                toAddAnswerResponse = false;
                outerIndx = parseInt(index, 10);
                break;
            } else if (answerValue && answerResponse.questionKey ===
                this.AllUserAnswers[index].questionKey) {
                outerIndx = parseInt(index, 10);
                for (const i in this.AllUserAnswers[index].questionResponseBean) {
                    if (resOption.ResponseText === this.AllUserAnswers[index]
                        .questionResponseBean[i].questionResponse) {
                        this.AllUserAnswers[index].questionResponseBean[i] = answer;
                        toAddAnswer = false;
                        innerIndx = parseInt(i, 10);
                        break;
                    } else {
                        innerIndx = parseInt(i, 10);
                        toAddAnswer = true;
                    }
                }
                if (toAddAnswer) {
                    this.AllUserAnswers[index].questionResponseBean.push(answer);
                } else if (toToggle) {
                    this.AllUserAnswers[index].questionResponseBean.splice(innerIndx, 1);
                }
                toAddAnswerResponse = false;
                break;
            } else {
                toAddAnswerResponse = true;
            }
        }
        if (toAddAnswerResponse && resOption) {
            this.AllUserAnswers.push(answerResponse);
        } else if (outerIndx && ((toToggle && !toAddAnswer && this.AllUserAnswers[outerIndx]
            .questionResponseBean.length === 0) || !resOption)) {
            this.AllUserAnswers.splice(outerIndx, 1);
        }
    }
    // Seting Default Answers of Questions to Response
    private setDefaultAnswers() {
        for (const index in this.InsuranceQuestionsList.Sections) {
            if (this.InsuranceQuestionsList.Sections[index]) {
                const section = this.InsuranceQuestionsList.Sections[index];
                for (const quesIndex in section.Questions) {
                    if (section.Questions[quesIndex]) {
                        const question = section.Questions[quesIndex];
                        for (const optionIndex in question.ResponseOptions) {
                            if (question.ResponseOptions[optionIndex]) {
                                const option = question.ResponseOptions[optionIndex];
                                if (option.DefaultSelection) {
                                    this.setAnswerToQuestion(question.Id, question.Key, option);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
