import { Component, OnChanges, Input, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { FormValidator } from './../../services/formValidator.service';
import { Formatter } from './../../services/formatter';
const FormControlNames = {
    BOOLEAN: 'optionalInput',
    SELECTION: 'selectorInput',
    CHECKBOX: 'checkbox',
    BUTTON: 'selectionInput',
    SELECTIONLIST: 'selectionlist',
    DATE: 'date',
    TRISTATE: 'tristate',
    NOTEXT: 'dependentInput'
};
const Input_Types = {
    Selection: 'Selection',
    Button: 'Button',
    Date: 'Date',
    Boolean: 'Boolean',
    InputBox: 'InputBox',
    CheckBox: 'CheckBox',
    SelectionList: 'SelectionList',
    TriState: 'TriState'
};
const ValidationTypes = {
    Numeric: 'numeric',
    Text: 'text'
};
const DOB_DATE_RANGES = {
    MaxAge: 120,
    MinAge: 18
};
@Component({
    selector: 'app-insurance-questions',
    templateUrl: './insuranceQuestions.template.html',
    styleUrls: ['./insuranceQuestions.style.css']
})
export class InsuranceQuestionsComponent implements OnChanges {
    // Public Variables
    @Input() public QuestionnaireObj: Model.InsuranceQuesttanaire[];
    @Input() public UserInputObj: Model.InsuranceAnswers[];
    @Output() public AnswerChanged: EventEmitter<Model.InsuranceQuestionnaireOutputPayload> = new EventEmitter();
    public InputTypes = Input_Types;
    public SectionList = <Model.InsuranceQuesttanaire[]>[];
    public FormGroupArr: FormGroup[] = [];
    public FormControlNames = FormControlNames;
    public AllUserAnswers: Model.InsuranceAnswers[] = [];
    public SubQuestionnaireAns = <Model.InsuranceAnswers[]>[];
    public Validations = ValidationTypes;
    public IsSubFormsValid = true;
    public DependentQuestionnaireUserObj: Model.InsuranceAnswers[] = [];
    private _selectedCheckboxValues: Model.ResponseOptions[] = [];
    private _depenedntQuestionOfSunQuestionnaire = <number[]>[];
    // Constructor
    constructor(
        public Formatters: Formatter,
        public FormValidators: FormValidator,
        private _formBuilder: FormBuilder
    ) { }
    // On change of Input Value
    public ngOnChanges() {
        if (this.QuestionnaireObj) {
            this.FormGroupArr = [];
            this.createQuestionList();
            console.log('Sections::', this.SectionList);
            if (this.UserInputObj) {
                this._mapInsuranceQuesAnswers(this.UserInputObj);
            }
        }
    }
    // Selection Of Checkbox Which has Same dependent Questions
    public SelectCheckboxOption(question: Model.Questions, userAnswer: Model.ResponseOptions) {
        let toSelect = true;
        let toRemoveIndex: number;
        for (const index in this._selectedCheckboxValues) {
            if (this._selectedCheckboxValues[index]) {
                const option = this._selectedCheckboxValues[index];
                if (userAnswer.questionResponseKey === option.questionResponseKey) {
                    toSelect = false;
                    toRemoveIndex = parseInt(index, 10);
                    break;
                } else {
                    toSelect = true;
                }
            }
        }
        if (toSelect) {
            this._selectedCheckboxValues.push(userAnswer);
        } else {
            this._selectedCheckboxValues.splice(toRemoveIndex, 1);
        }
        this.checkDependentQuestionVisibility(question, userAnswer, toSelect);
    }
    // Checking Next Question As per User Answer
    public CheckNextQuesExist(question: Model.Questions, userAnswer: Model.ResponseOptions, toToggle: boolean) {
        // toToggle flag true is only for the checkbox elements where each checkbox has different dependent question
        let nextQuesKey: number;
        let nextQuesKeys: number[];
        let toDisplay = false;
        this.IsSubFormsValid = true;
        for (const index in question.possibleAnswers) {
            if (question.possibleAnswers[index]) {
                const responseOption = question.possibleAnswers[index];
                if (responseOption.nextQuestion) {
                    nextQuesKey = responseOption.nextQuestion;
                } else if (responseOption.nextQuestions && responseOption.nextQuestions.length > 0) {
                    nextQuesKeys = responseOption.nextQuestions;
                }
                if (userAnswer && userAnswer.questionResponse === responseOption.questionResponse
                    && (responseOption.nextQuestion || (responseOption.nextQuestions && responseOption.nextQuestions.length > 0))) {
                    toDisplay = true;
                    break;
                } else if (userAnswer) {
                    if (toToggle) {
                        nextQuesKey = null;
                    }
                    toDisplay = false;
                } else { // userAnswer null means have to remove all dependent ques of removed form
                    toDisplay = false;
                }
            }
        }
        if (this.Formatters.toSmallCase(question.inputType) !== this.Formatters.toSmallCase(this.InputTypes.InputBox)) {
            const ansToAdd = userAnswer && (userAnswer.questionResponse);
            this.setAnswerToFormControl(question, ansToAdd);
        }
        if (nextQuesKey) {
            this.setDisplayToDependentQues(nextQuesKey, toDisplay, toToggle);
        } else if (nextQuesKeys) {
            if (toDisplay && this.Formatters.toSmallCase(question.inputType) === this.Formatters
                .toSmallCase(this.InputTypes.SelectionList)) {
                this.createQuestionnaireObject(question, nextQuesKeys);
            } else {
                nextQuesKeys.forEach((key) => {
                    this.setDisplayToDependentQues(key, toDisplay, toToggle);
                });
            }
        }
        if (toToggle && userAnswer) {
            const answerValue = 'Y';
            this.setAnswerToQuestion(question.questionId, question.questionKey, userAnswer, answerValue, toToggle);
        } else if (userAnswer) {
            this.setAnswerToQuestion(question.questionId, question.questionKey, userAnswer);
        }
        this.OnAnswerChange();
    }
    // Selecting From Selection Field
    public OnSelect(question: Model.Questions, userAnswer: string) {
        let responseOption: Model.ResponseOptions;
        for (const index in question.possibleAnswers) {
            if (userAnswer === question.possibleAnswers[index].questionResponse) {
                responseOption = question.possibleAnswers[index];
                break;
            }
        }
        this.setAnswerToQuestion(question.questionId, question.questionKey, responseOption);
    }
    // On Blur of Text/Numric Input type
    public OnBlur(
        questionId: string,
        questionKey: number,
        answer: Model.ResponseOptions,
        userAnswer: string) {
        this.setAnswerToQuestion(questionId, questionKey, answer, userAnswer);
    }
    // OnSelection Of Selection List Row
    public OnSelectionOfSelectionList(event: Model.ResponseOptions[], que: Model.Questions) {
        const currentRespOpt = event[0];
        const allOptions = que.possibleAnswers;
        console.log('selected::', currentRespOpt, allOptions);
        if (currentRespOpt.isSelected) {
            return;
        }
        for (const item of allOptions) {
            if (item.questionResponseKey === currentRespOpt.questionResponseKey) {
                item.isSelected = true;
            } else {
                item.isSelected = false;
                this.clearDependentAnsFormList(que.questionnaireObj);
            }
        }
        this.FormGroupArr[que.questionId + 'FormGroup'].controls[FormControlNames.BOOLEAN]
            .setValue(currentRespOpt.questionResponse);
        this.setAnswerToQuestion(que.questionId, que.questionKey, currentRespOpt);
        this.CheckNextQuesExist(que, currentRespOpt, false);
        console.log('Ques:::: ', this.SectionList);
    }
    // On Next
    public OnAnswerChange() {
        const responseTemplateBean = this.getResponsePayload();
        this.AnswerChanged.emit(responseTemplateBean);
    }
    public OnDateValueChange(que: Model.Questions, formValue: FormData) {
        que.customeErrorMsg = null;
        const dateValue = formValue['year'] + '-' + formValue['month'] + '-' + formValue['day'];
        const toValidateDate = formValue['month'] + '/' + formValue['day'] + '/' + formValue['year'];
        const formGroup = que.questionId + 'FormGroup';
        let isErrorMsg: string;
        const dateObj = {
            Day: formValue['day'],
            Month: formValue['month'],
            Year: formValue['year']
        };
        if (this.FormValidators.IsDateOfBirthValid(dateObj, null, 0, 3000)) {
            isErrorMsg = this.FormValidators.IsDateOfBirthValid(dateObj, null, 0, 3000);
        } else {
            isErrorMsg = this.FormValidators.IsFutureDate(toValidateDate);
        }
        if (!isErrorMsg && formValue['year'] && formValue['month'] && formValue['day']) {
            this.setAnswerToQuestion(que.questionId, que.questionKey, que.possibleAnswers[0], dateValue);
            this.FormGroupArr[formGroup].controls['day'].setErrors(null);
            this.FormGroupArr[formGroup].controls['month'].setErrors(null);
            this.FormGroupArr[formGroup].controls['year'].setErrors(null);
        } else if (isErrorMsg && formValue['year'] && formValue['month'] && formValue['day']) {
            que.customeErrorMsg = isErrorMsg;
            this.FormGroupArr[formGroup].controls['day'].setErrors({ 'dateError': true });
            this.FormGroupArr[formGroup].controls['month'].setErrors({ 'dateError': true });
            this.FormGroupArr[formGroup].controls['year'].setErrors({ 'dateError': true });
        }
        this.OnAnswerChange();
    }
    // Questionnaire Handler for Sub Questionnaire Component for Selection list
    public QuestionnaireHandler(emitterObject: Model.QuestionnaireEmitterObj) {
        if (emitterObject) {
            this.IsSubFormsValid = emitterObject.isAllFormsValid;
            this.SubQuestionnaireAns = emitterObject.responseTemplate;
            this.OnAnswerChange();
        }
    }
    // Creating Questions List from Multiple Sections
    private createQuestionList() {
        this.SectionList = [];
        this.QuestionnaireObj.forEach((section) => {
            this.SectionList.push(section);
            section.insPlanQuestions.forEach((ques) => {
                this.setQuestions(section.insPlanQuestions);
            });
        });
    }
    // Check All Forms Are Valid or not
    private checkAllFormsValidity() {
        let isValid = true;
        for (const index in this.FormGroupArr) {
            if (this.FormGroupArr[index]) {
                const form = this.FormGroupArr[index];
                for (const controlIndex in form.controls) {
                    if (form.controls[controlIndex] && controlIndex !== FormControlNames.CHECKBOX) {
                        if (controlIndex !== 'day' && controlIndex !== 'month' && controlIndex !== 'year') {
                            isValid = !this.FormValidators.FieldHasErrors(form, controlIndex, false);
                        } else {
                            isValid = !this.FormValidators.HasError(form, controlIndex, 'dateError');
                        }
                        if (!isValid) {
                            break;
                        }
                    } else if (controlIndex === FormControlNames.CHECKBOX) {
                        console.log('index', index);
                        console.log('AllUserAnswers', this.AllUserAnswers);
                        for (const item of this.AllUserAnswers) {
                            const formName = item.questionId + 'FormGroup';
                            if (index !== formName) {
                                isValid = false;
                            } else {
                                isValid = true;
                                break;
                            }
                            console.log('element:', item);
                        }
                    }
                }
                if (!isValid) {
                    break;
                }
            }
        }
        return isValid;
    }
    // Setting Questions
    private setQuestions(quesList) {
        this.sortInOrder(quesList, 'que');
        for (const ques of quesList) {
            this.sortInOrder(ques.possibleAnswers, 'response');
            if (ques.isMain === 'Y' || ques.toDisplay) {
                this.createForms(ques);
            }
        }
    }
    // Sorting Questions/possible answers as per their display order
    private sortInOrder(list: any[], type: string) {
        list.sort((a, b) => {
            if (type === 'que') {
                return a.displayOrder - b.displayOrder;
            } else {
                return a.responseOrder - b.responseOrder;
            }
        });
    }
    // Adding Dependent Form Group If Displayed
    private createForms(question: Model.Questions) {
        const formName = question.questionId + 'FormGroup';
        this.FormGroupArr[formName] = this._formBuilder.group({});
        for (const option of question.possibleAnswers) {
            const controlName = question.isMain === 'N' ? (this.Formatters
                .toSmallCase(question.inputType) === this.Formatters.toSmallCase(
                    this.InputTypes.CheckBox) ? FormControlNames.CHECKBOX :
                FormControlNames.NOTEXT) : (this.Formatters
                    .toSmallCase(question.inputType) === this.Formatters.toSmallCase(
                        this.InputTypes.Button) ? FormControlNames.BUTTON : option.questionResponse);
            this.createFormGroupForQuestion(this.Formatters.toSmallCase(question.inputType),
                formName, controlName, question);
        }
    }
    // Creating Form Group for Question As per Intput InputType
    private createFormGroupForQuestion(controlType: string, formName, controlName: string, ques: Model.Questions) {
        // Fix control name
        controlName = controlName || controlName !== '' ? controlName : FormControlNames.NOTEXT;
        let validatorRequired: boolean;
        let currentControlName: string[] = [];
        switch (controlType) {
            case this.Formatters.toSmallCase(this.InputTypes.Boolean):
                currentControlName.push(FormControlNames.BOOLEAN);
                break;
            case this.Formatters.toSmallCase(this.InputTypes.SelectionList):
                currentControlName.push(FormControlNames.BOOLEAN);
                this.addSelectionListObjectToQuestion(ques);
                break;
            case this.Formatters.toSmallCase(this.InputTypes.Selection):
                currentControlName.push(FormControlNames.SELECTION);
                break;
            case this.Formatters.toSmallCase(this.InputTypes.InputBox):
            case this.Formatters.toSmallCase(this.InputTypes.CheckBox):
                currentControlName.push(controlName);
                break;
            case this.Formatters.toSmallCase(this.InputTypes.Button):
                currentControlName.push(FormControlNames.BUTTON);
                break;
            case this.Formatters.toSmallCase(this.InputTypes.Date):
                currentControlName = ['day', 'month', 'year'];
                break;
            case this.Formatters.toSmallCase(this.InputTypes.TriState):
                currentControlName = [FormControlNames.TRISTATE];
                break;
            default: break;
        }
        if (ques.ansRequired && ques.ansRequired === 1 && (ques.isMain === 'Y' || ques.toDisplay)) {
            validatorRequired = true;
        }
        this.addFormControls(formName, currentControlName, validatorRequired);
    }
    // Adding Form Controls as per the dependency conditions
    private addFormControls(formName: string, controlNames: string[], validatorRequired: boolean) {
        controlNames.forEach((controlName) => {
            if (!this.FormGroupArr[formName].contains(controlName)) {
                this.FormGroupArr[formName].addControl(controlName,
                    new FormControl(''));
                if (validatorRequired) {
                    this.FormGroupArr[formName].controls[controlName].setValidators(Validators.required);
                    this.FormGroupArr[formName].controls[controlName].setErrors({});
                } else {
                    this.FormGroupArr[formName].controls[controlName].clearValidators();
                    this.FormGroupArr[formName].controls[controlName].setErrors(null);
                }
            }
        });
    }
    private addSelectionListObjectToQuestion(ques: Model.Questions) {
        if (!ques.selectionListOptions) {
            ques.selectionListOptions = {
                itemSelector: '.item-row' + ques.questionId,
                itemHighlightSelector: '.item-row' + ques.questionId,
                DataProvider: ques.possibleAnswers,
                isMultiSelect: false,
                isSelectionToggleAllowed: false
            };
        }
    }
    // Checking Display Option for Same Dependent Question In Multiple Questions
    private checkDependentQuestionVisibility(question: Model.Questions, userAnswer: Model.ResponseOptions, isSelected: boolean) {
        const selectedOptNextQuesKey = userAnswer.nextQuestion;
        let toDisplay: boolean;
        const answerValue = 'Y';
        for (const respOpt of this._selectedCheckboxValues) {
            const nextQuesKey = respOpt.nextQuestion;
            if (!isSelected) {
                if (selectedOptNextQuesKey === nextQuesKey) {
                    toDisplay = true;
                    break;
                } else {
                    toDisplay = false;
                }
            }
        }
        this.setAnswerToQuestion(question.questionId, question.questionKey, userAnswer, answerValue, true);
        if (!isSelected) {
            this.setDisplayToDependentQues(selectedOptNextQuesKey, toDisplay, false);
        } else {
            this.setDisplayToDependentQues(selectedOptNextQuesKey, true, false);
        }
    }
    // Setting Dymanic Form Controls of Dependent Questions
    private setDisplayToDependentQues(nextQuesKey: number, toDisplay: boolean, toToggle: boolean) {
        for (const section of this.SectionList) {
            for (const ques of section.insPlanQuestions) {
                if (nextQuesKey === ques.questionKey) {
                    ques.toDisplay = toToggle ? !ques.toDisplay : toDisplay;
                    if (ques.toDisplay) {
                        this.createForms(ques);
                    } else {
                        this.removeFroms(ques);
                        this.removeAllDefaultSelections(ques);
                        this.CheckNextQuesExist(ques, null, toToggle);
                        this.setAnswerToQuestion(ques.questionId, ques.questionKey, null);
                        if (this.Formatters.toSmallCase(ques.inputType) === this.Formatters.toSmallCase(this.InputTypes.SelectionList)) {
                            ques.possibleAnswers.forEach((option) => {
                                option.isSelected = false;
                            });
                        }
                    }
                }
            }
        }
        this.OnAnswerChange();
    }
    // Setting User Answer to Question
    private setAnswerToQuestion(
        questionId: string,
        questionKey: number,
        resOption: Model.ResponseOptions,
        answerValue?: string,
        toToggle?: boolean
    ) {
        const answer: Model.InsuranceQuestionnaireResponse = <Model.InsuranceQuestionnaireResponse>{};
        let toAddAnswer = true;
        const answerResponse: Model.InsuranceAnswers = <Model.InsuranceAnswers>{};
        let toAddAnswerResponse = true;
        let outerIndx: number;
        let innerIndx: number;
        let toAddValueToControl: boolean;
        answer.questionResponseValue = answerValue ? answerValue :
            resOption ? resOption.questionResponse : '';
        answer.questionResponse = resOption ? resOption.questionResponse : '';
        answer.choiceCode = resOption ? resOption.choiceCode : '';
        answer.insQueResChoiceKey = resOption ? resOption.questionResponseKey : 0;
        answerResponse.questionResponseKey = resOption ? resOption.questionResponseKey : null;
        answerResponse.questionKey = questionKey;
        answerResponse.questionId = questionId;
        answerResponse.questionResponseBean = [];
        answerResponse.questionResponseBean.push(answer);
        for (const index in this.AllUserAnswers) {
            if (!answerValue && answerResponse.questionKey ===
                this.AllUserAnswers[index].questionKey) {
                this.AllUserAnswers[index] = answerResponse;
                toAddAnswerResponse = false;
                outerIndx = parseInt(index, 10);
                break;
            } else if (answerValue && answerResponse.questionKey ===
                this.AllUserAnswers[index].questionKey) {
                outerIndx = parseInt(index, 10);
                for (const i in this.AllUserAnswers[index].questionResponseBean) {
                    if (resOption.questionResponse === this.AllUserAnswers[index]
                        .questionResponseBean[i].questionResponse) {
                        this.AllUserAnswers[index].questionResponseBean[i] = answer;
                        toAddAnswer = false;
                        innerIndx = parseInt(i, 10);
                        break;
                    } else {
                        innerIndx = parseInt(i, 10);
                        toAddAnswer = true;
                    }
                }
                if (toAddAnswer) {
                    toAddValueToControl = true;
                    this.AllUserAnswers[index].questionResponseBean.push(answer);
                } else if (toToggle) {
                    toAddValueToControl = false;
                    this.AllUserAnswers[index].questionResponseBean.splice(innerIndx, 1);
                }
                toAddAnswerResponse = false;
                toAddValueToControl = false;
                break;
            } else {
                toAddAnswerResponse = true;
                toAddValueToControl = true;
            }
        }
        if (toAddAnswerResponse && resOption) {
            this.AllUserAnswers.push(answerResponse);
        } else if (outerIndx && ((toToggle && !toAddAnswer && this.AllUserAnswers[outerIndx]
            .questionResponseBean.length === 0) || !resOption)) {
            this.AllUserAnswers.splice(outerIndx, 1);
        }
        this.OnAnswerChange();
    }
    // Removing Dependent Form Group If Hidden
    private removeFroms(question: Model.Questions) {
        const formName = question.questionId + 'FormGroup';
        console.log('this.FormGroupArr', this.FormGroupArr);
        for (const index in this.FormGroupArr) {
            if (this.FormGroupArr[index]) {
                if (index === formName) {
                    delete this.FormGroupArr[index];
                    break;
                }
            }
        }
    }
    // Removing all Default Selections And Response if not selected
    private removeAllDefaultSelections(question: Model.Questions) {
        question.responseTemplateBean = [];
        for (const option of question.possibleAnswers) {
            option.defaultSelection = 'N';
        }
    }
    // Create Response payload
    private getResponsePayload() {
        const payload = <Model.InsuranceQuestionnaireOutputPayload>{};
        payload.isAllFormsValid = this.IsSubFormsValid && this.checkAllFormsValidity();
        payload.responseTemplate = [];
        if (this.AllUserAnswers && this.AllUserAnswers.length > 0) {
            payload.responseTemplate = this.AllUserAnswers;
        }
        if (this.SubQuestionnaireAns && this.SubQuestionnaireAns.length > 0) {
            this.SubQuestionnaireAns.forEach((ansObj) => {
                payload.responseTemplate = this.updateAnsToPayload(payload.responseTemplate, ansObj);
            });
        }
        console.log('Payload Creater::', payload);
        return payload;
    }
    private updateAnsToPayload(responseTemplate: Model.InsuranceAnswers[], ansObj: Model.InsuranceAnswers) {
        let mainInd: number;
        for (const itemInd in responseTemplate) {
            if (responseTemplate[itemInd]) {
                const item = responseTemplate[itemInd];
                if (item.questionKey === ansObj.questionKey) {
                    mainInd = parseInt(itemInd, 10);
                    break;
                }
            }
        }
        if (mainInd) {
            responseTemplate[mainInd] = ansObj;
        } else {
            responseTemplate.push(ansObj);
        }
        return responseTemplate;
    }
    // Creating Questionnnaire Object For Selectin List Dependent Questions
    private createQuestionnaireObject(que: Model.Questions, nextQuesKeys: number[]) {
        this.clearDependentAnsFormList(que.questionnaireObj);
        que.questionnaireObj = [];
        const questionaireObj = {
            insPlanQuestions: []
        };
        nextQuesKeys.forEach((key) => {
            for (const section of this.SectionList) {
                for (const ques of section.insPlanQuestions) {
                    if (ques.questionKey === key) {
                        const currentQues = Object.assign({}, ques);
                        currentQues.toDisplay = true;
                        questionaireObj.insPlanQuestions.push(currentQues);
                        break;
                    }
                }
            }
        });
        que.questionnaireObj.push(questionaireObj);
    }
    private clearDependentAnsFormList(dependentQues: Model.DependentQuesttanaireObj[]) {
        this.SubQuestionnaireAns = [];
        if (dependentQues && dependentQues.length > 0) {
            let mainInd: number;
            const allQues = Object.assign([], this.AllUserAnswers);
            dependentQues.forEach((currentQueSet) => {
                currentQueSet.insPlanQuestions.forEach((currentQue) => {
                    for (const andInd in this.AllUserAnswers) {
                        if (this.AllUserAnswers[andInd]) {
                            const ans = this.AllUserAnswers[andInd];
                            if (ans.questionKey === currentQue.questionKey) {
                                mainInd = parseInt(andInd, 10);
                                this.clearAnsFromControl(ans);
                                break;
                            }
                        }
                    }
                    if (mainInd) {
                        allQues.splice(mainInd, 1);
                    }
                });
            });
            this.AllUserAnswers = allQues;
            this.OnAnswerChange();
        }
    }
    private clearAnsFromControl(ans: Model.InsuranceAnswers) {
        const currentFormName = ans.questionId + 'FormGroup';
        const que = this.getQuestionFromId(ans.questionId);
        const currentControlName = this.getFormControlName(que, ans.questionResponseBean[0].questionResponse);
        if (this.FormGroupArr[currentFormName]) {
            this.FormGroupArr[currentFormName].controls[currentControlName].setValue('');
        }
    }
    private getQuestionFromId(id: string): Model.Questions {
        for (const section of this.SectionList) {
            for (const que of section.insPlanQuestions) {
                if (que.questionId === id) {
                    return que;
                }
            }
        }
    }
    // Maping Ansewrs to Question List
    private _mapInsuranceQuesAnswers(responseTemplate: Model.InsuranceAnswers[]) {
        for (const section of this.SectionList) {
            for (const question of section.insPlanQuestions) {
                for (const responseValue of responseTemplate) {
                    if (responseValue.questionKey === question.questionKey) {
                        for (const userAnswer of responseValue.questionResponseBean) {
                            if (!question.responseTemplateBean) {
                                question.responseTemplateBean = [];
                            }
                            question.responseTemplateBean.push(userAnswer);
                            if (this.Formatters.toSmallCase(question.inputType) === this.Formatters
                                .toSmallCase(this.InputTypes.CheckBox)) {
                                this.setDefaultValueOfCheckBox(question, userAnswer, true);
                            } else if (this.Formatters.toSmallCase(question.inputType) === this.Formatters
                                .toSmallCase(this.InputTypes.Date)) {
                                this.setDateValue(question, userAnswer);
                            } else if (this.Formatters.toSmallCase(question.inputType) === this.Formatters
                                .toSmallCase(this.InputTypes.SelectionList)) {
                                this.setAllDependentQuestionnaire(question);
                                this.setDefaultValue(question, userAnswer);
                            } else if (this.Formatters.toSmallCase(question.inputType) === this.Formatters
                                .toSmallCase(this.InputTypes.InputBox)) {
                                this.setResponseOfInputs(question, userAnswer,
                                    question.questionKey, question.possibleAnswers);
                            } else {
                                this.setDefaultValue(question, userAnswer);
                            }
                        }
                        break;
                    }
                }
            }
        }
        console.log('List:', this.SectionList);
        this.OnAnswerChange();
    }
    // Setting User's Previous Response to form controls
    private setResponseOfInputs(
        ques: Model.Questions, userResponse: Model.InsuranceQuestionnaireResponse,
        key?: number, responseOptions?: Model.ResponseOptions[]) {
        const id = ques.questionId;
        if (id && userResponse) {
            const formControl = (userResponse.questionResponse && ques.isMain === 'Y') ?
                userResponse.questionResponse : this.FormControlNames.NOTEXT;
            if (this.FormGroupArr[id + 'FormGroup'] && this.FormGroupArr[id + 'FormGroup'].controls[formControl]) {
                this.FormGroupArr[id + 'FormGroup'].controls[formControl].setValue(userResponse.questionResponseValue);
                for (const option of responseOptions) {
                    if (option.questionResponse === userResponse.questionResponse) {
                        this.setAnswerToQuestion(id, key, option, userResponse.questionResponseValue);
                    }
                }
            }

        }
    }
    // Setting Default Answers
    private setDefaultValue(question: Model.Questions, userAnswer: Model.InsuranceQuestionnaireResponse) {
        for (const responseOption of question.possibleAnswers) {
            if (responseOption.questionResponseKey === userAnswer.insQueResChoiceKey) {
                responseOption.defaultSelection = 'Y';
                const formControl = this.getFormControlName(question, userAnswer.questionResponse);
                this.FormGroupArr[question.questionId + 'FormGroup'].controls[formControl]
                    .setValue(userAnswer.questionResponseValue);
                this.CheckNextQuesExist(question, responseOption, false);
                if (this.Formatters.toSmallCase(question.inputType) === this.Formatters.toSmallCase(this.InputTypes.SelectionList)) {
                    const selectionEvent = [responseOption];
                    this.OnSelectionOfSelectionList(selectionEvent, question);
                }
            } else {
                responseOption.defaultSelection = 'N';
            }
        }
    }
    // Setting Default Answers to Checkbox input type
    private setDefaultValueOfCheckBox(
        question: Model.Questions, userAnswer: Model.InsuranceQuestionnaireResponse, toToggle?: boolean) {
        // toToggle flag is used for the default selection Of Checkbox Which has Same dependent Questions
        for (const responseOption of question.possibleAnswers) {
            if (responseOption.questionResponse === userAnswer.questionResponse) {
                responseOption.defaultSelection = 'Y';
                if (toToggle) {
                    this.SelectCheckboxOption(question, responseOption);
                    break;
                } else {
                    this.CheckNextQuesExist(question, responseOption, true);
                }
            } else if (!responseOption.defaultSelection || responseOption.defaultSelection !== 'Y') {
                responseOption.defaultSelection = 'N';
            }
        }
    }
    private setDateValue(question: Model.Questions, userAnswer: Model.InsuranceQuestionnaireResponse) {
        console.log('InDate Values::', userAnswer);
        const formGroup = question.questionId + 'FormGroup';
        const dateValue = userAnswer.questionResponseValue;
        const dateSplit = dateValue.split('-');
        this.FormGroupArr[formGroup].controls['day'].setValue(dateSplit[2]);
        this.FormGroupArr[formGroup].controls['month'].setValue(dateSplit[1]);
        this.FormGroupArr[formGroup].controls['year'].setValue(dateSplit[0]);
        this.OnDateValueChange(question, this.FormGroupArr[formGroup].value);
    }
    // Returning form control Name as per the Question input type
    private getFormControlName(ques: Model.Questions, ans: string): string {
        let controlName: string;
        const inputType = this.Formatters.toSmallCase(ques.inputType);
        switch (inputType) {
            case this.Formatters.toSmallCase(this.InputTypes.Button):
                controlName = FormControlNames.BUTTON;
                break;
            case this.Formatters.toSmallCase(this.InputTypes.Boolean):
                controlName = FormControlNames.BOOLEAN;
                break;
            case this.Formatters.toSmallCase(this.InputTypes.Selection):
                controlName = FormControlNames.SELECTION;
                break;
            case this.Formatters.toSmallCase(this.InputTypes.SelectionList):
                controlName = FormControlNames.BOOLEAN;
                break;
            case this.Formatters.toSmallCase(this.InputTypes.TriState):
                controlName = FormControlNames.TRISTATE;
                break;
            case this.Formatters.toSmallCase(this.InputTypes.CheckBox):
                controlName = FormControlNames.CHECKBOX;
                break;
            case this.Formatters.toSmallCase(this.InputTypes.InputBox):
                if (ques.isMain === 'Y') {
                    controlName = ans;
                } else {
                    controlName = FormControlNames.NOTEXT;
                }
                break;
            case this.Formatters.toSmallCase(this.InputTypes.Date):
                break;
            default: controlName = FormControlNames.NOTEXT;
                break;
        }
        return controlName;
    }
    private setAnswerToFormControl(ques: Model.Questions, answer: string) {
        const controlName = this.getFormControlName(ques, answer);
        const formGroup = this.FormGroupArr[ques.questionId + 'FormGroup'];
        if (answer && formGroup) {
            formGroup.controls[controlName]
                .setValue(answer);
        } else if (formGroup) {
            formGroup.controls[controlName].setValue('');
        }
        this.OnAnswerChange();
    }
    private setAllDependentQuestionnaire(que: Model.Questions) {
        const depenedntQuestionOfSunQuestionnaire = [];
        que.possibleAnswers.forEach((ansObj) => {
            if (ansObj.nextQuestion) {
                depenedntQuestionOfSunQuestionnaire.push(ansObj.nextQuestion);
            } else if (ansObj.nextQuestions && ansObj.nextQuestions.length > 0) {
                ansObj.nextQuestions.forEach((key) => {
                    depenedntQuestionOfSunQuestionnaire.push(key);
                });
            }
        });

        this.setDependentQuestionnaireUserInput(depenedntQuestionOfSunQuestionnaire);
    }
    private setDependentQuestionnaireUserInput(depenedntQuestionList: number[]) {
        const indexList: number[] = [];
        for (const key of depenedntQuestionList) {
            for (const ansObjInd in this.UserInputObj) {
                if (this.UserInputObj[ansObjInd]) {
                    const ansObj = this.UserInputObj[ansObjInd];
                    if (key === ansObj.questionKey) {
                        console.log('key', key);
                        console.log('ansObj', ansObj);
                        this.addAnsToList(ansObj);
                        indexList.push(parseInt(ansObjInd, 10));
                    }
                }
            }
        }
        this.removeDependentAnsweres(indexList);
        this.OnAnswerChange();
    }
    private addAnsToList(ansObj: Model.InsuranceAnswers) {
        let toAdd = true;
        if (this.DependentQuestionnaireUserObj && this.DependentQuestionnaireUserObj.length > 0) {
            for (const ans of this.DependentQuestionnaireUserObj) {
                if (ans.questionKey === ansObj.questionKey) {
                    toAdd = false;
                    break;
                } else {
                    toAdd = true;
                }
            }
        }
        if (toAdd) {
            this.DependentQuestionnaireUserObj.push(ansObj);
        }
    }
    private removeDependentAnsweres(list: number[]) {
        list.forEach((index) => {
            this.UserInputObj.splice(index, 1);
        });
    }
}
