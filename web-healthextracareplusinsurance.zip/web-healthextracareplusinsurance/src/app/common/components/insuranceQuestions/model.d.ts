declare module Model {
    export interface InsuranceQuesttanaireInputPayload {
        insPlanQueSets: InsuranceQuesttanaire[];
    }
    export interface InsuranceQuestionnaireOutputPayload {
        insProductPlan: string;
        insProductPlanCode: string;
        responseTemplate: InsuranceAnswers[];
        isAllFormsValid?: boolean;
    }
    export interface InsuranceQuesttanaire {
        headerDescId: number;
        headerDesc: string;
        insPlanQuestions: Questions[];
    }
    export interface Questions {
        helpText: string;
        questionId: string;
        questionKey: number;
        questionDesc: string;
        action: number;
        inputType: string;
        displayOrder: number;
        datasource: string;
        placeHolder: string;
        possibleAnswers: ResponseOptions[];
        responseTemplateBean?: InsuranceQuestionnaireResponse[];
        isMain: string;
        isDependent?: boolean;
        parentQuestionId: number;
        toDisplay?: boolean;
        selectionListOptions?: SelectionListOptions;
        questionnaireObj?: DependentQuesttanaireObj[];
        customeErrorMsg?: string;
        ansRequired: number;
    }
    export interface ResponseOptions {
        questionResponseKey: number;
        questionResponse: string;
        responseOrder: number;
        defaultSelection: string;
        nextQuestion?: number;
        nextQuestions: number[];
        validation: string;
        choiceCode: string;
        isSelected?: boolean;
    }
    export interface InsuranceQuestionnaireResponse {
        insQueResChoiceKey?: number;
        choiceCode?: string;
        questionResponse: string;
        questionResponseValue: string;
    }
    export interface InsuranceAnswers {
        questionResponseKey: number;
        questionKey: number;
        questionId: string;
        questionResponseBean: InsuranceQuestionnaireResponse[];
    }
    export interface DependentQuesttanaireObj {
        insPlanQuestions: Questions[];
    }
    export interface QuestionnaireEmitterObj {
        isAllFormsValid: boolean;
        responseTemplate: InsuranceAnswers[];
    }
    export interface MTResponse<T> {
        payload: T;
        status: string;
        nextTaskKey?: string;
        routesInfo?: routesInfo;
        progressInfo: ProgressStateResponse;
        errorBean: [{ errorCode: string, errorMessage: string }];
        userInput?: any;
        errorDetails:[{ code: string; description: string }];
    }
    export interface ProgressStateResponse {
        payload: ProgressStateInfo[];
        status: string;
        nextTaskKey?: string;
        errorBean: [{ errorCode: string, errorMessage: string }];
    }
    export interface routesInfo {
        mainRoute: string;
        subRoute: string;
    }
}
