declare module Models {
    export interface InsuranceQuestionsList {
        ProductCode: string;
        ProductDescription: string;
        Sections: Section[];
        Nominee?: NomineeDetails;
    }
    export interface Section {
        OrderNumber: number;
        Header: string;
        Questions: Question[];
    }
    export interface NomineeDetails {
        firstName: string;
        middleName?: string;
        lastName: string;
        relation: string;
        dateOfBirth: DateOfBirth;
    }
    export interface SummaryConfigObject {
        applicationId?: string;
        insuringFor?: number;
        insuredDetails: InsuredDetails[];
        proposedSumAssuredList: number[];
        proposerDetails?: InsuredDetails;
        selectedPlanDetails: Model.SelectedPlanDetails;
    }
    export interface InsuredDetails {
        relationship: string;
        age: number;
        dateOfBirth?: string;
        no?: number;
        firstName?: string;
        middleName?: string;
        lastName?: string;
        genderCode?: string;
        genderDesc?: string;
        emailDetails?: any[];
        phoneNumberDetails?: any[];
        panNumber?: string;
        presentInIndiaFlag?: string;
        indianPassportFlag?: string;
        maritalStatusDesc?: string;
        maritalStatusCode?: string;
        employmentDetails?: any;
        netSalary?: string;
        mailingAddress?: AddressDetails;
        addressDetails?: AddressDetails;
        heightInFeets: number;
        heightInInch: number;
        weight: number;
    }
    export interface AddressDetails {
        addressLine1: string;
        addressLine2: string;
        areaLocalityName: string;
        city: string;
        cityCode: string;
        flatNumber: string;
        houseNumber: string;
        pinCode: string;
        state: string;
        stateCode: string;
        street: string;
        type: string;
    }
    export interface DateOfBirth {
        day: string;
        month: string;
        year: string;
    }
    export interface Question {
        Id: string;
        Key: number;
        OrderNumber: number;
        Description: string;
        InputType: string;
        ResponseOptions: ResponseOption[];
        Response: InsuranceQuestionnaireResponse[];
        IsDependent: Boolean;
        ToDisplay: Boolean;
        HelpText: string;
    }
    export interface ResponseOption {
        QuestionResponseKey: number;
        OrderNumber: number;
        ResponseText: string;
        NextQuestionKey: number;
        DefaultSelection: boolean;
        Validation: string;
    }
    export interface InsuranceQuestionnaireResponse {
        questionKey: number;
        questionId: string,
        questionResponseKey: number;
        questionResponseBean: InsuranceAnswer[];
    }
    export interface InsuranceAnswer {
        questionResponse: string;
        questionResponseValue: string;
    }
    export interface InsuranceResponse {
        insProductPlan: string;
        insProductPlanCode: string;
        responseTemplate: InsuranceQuestionnaireResponse[];
        nominee: NomineeDetails;
    }
    export interface MTResponse<T> {
        payload: T;
        status: string;
        nextTaskKey?: string;
        routesInfo?: routesInfo;
        progressInfo: ProgressStateResponse;
        errorBean: [{ errorCode: string, errorMessage: string }];
        userInput?: any;
    }
    export interface routesInfo {
        mainRoute: string;
        subRoute: string;
    }
    export interface ProgressStateResponse {
        payload: ProgressStateInfo[];
        status: string;
        nextTaskKey?: string;
        errorBean: [{ errorCode: string, errorMessage: string }];
    }
    export interface ProgressStateInfo {
        name: string;
        active: boolean;
        value: number;
    }
    export interface Section {
        OrderNumber: number;
        Header: string;
        Questions: Question[];
    }
}
