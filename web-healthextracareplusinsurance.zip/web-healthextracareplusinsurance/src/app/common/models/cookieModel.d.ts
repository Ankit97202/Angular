declare interface ICookieHandler {
    SetCookie: (key: string, value: any) => void;
    GetCookie: (key: string) => string;
    DeleteCookies: (keys: string[]) => void;
    FlushAll: () => void;
}