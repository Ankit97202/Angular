declare module Model {

    export interface ProgressStateInfo {
        name: string;
        active: boolean;
        value: number;
    }
}
