declare interface SelectionListOptions {
    itemSelector: string;
    itemHighlightSelector?: string;
    isMultiSelect?: boolean;
    isSelectionToggleAllowed?: boolean;
    template?: string;
    DataProvider: any;
    SelectedItems?: any[];
}