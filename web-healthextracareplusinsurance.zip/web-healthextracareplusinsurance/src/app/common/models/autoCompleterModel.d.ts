declare interface AutoCompleteOptions {
    SearchData: any[];
    DataService: any;
    OnSelection: Function;
    PlaceHolder: string;
    Model: any;
    MaxLength: number;
    MatchClass: string;
    TextSearching: string;
    MinSearchLength: number;
    OverrideSuggestion: boolean;
    OnBlur: Function;
}
declare interface CompleterItem {
    title: string;
    description?: string;
    image?: string;
    originalObject: any;
}
