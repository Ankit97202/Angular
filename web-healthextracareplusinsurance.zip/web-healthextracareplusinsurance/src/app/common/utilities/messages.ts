export class Messages {
    public static GeoLocationErrorMessages = {
        UnSupportedCountry: 'UnSupportedCountry', // "Country provided is not currently served",
        InvalidPin: 'InvalidCode', // "Please enter a valid pin code.",
        UnSupportedCity: 'UnSupportedCity', // City provided is not currently served",
        UnSupportedState: 'UnSupportedState'
    };
    public static LocationErrorMessages = {
        InvalidPin: 'Please enter a valid pin code.',
        UnSupportedCity: 'City provided is not currently served',
        UnSupportedCountry: 'Country provided is not currently served'
    };
}
