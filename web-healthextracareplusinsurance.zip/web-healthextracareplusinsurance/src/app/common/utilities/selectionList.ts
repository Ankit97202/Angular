import {
    AfterViewChecked, AfterViewInit, OnInit, OnDestroy, Component, Directive, ElementRef,
    EventEmitter, HostListener, Injectable, Input, Output, Renderer, forwardRef, OnChanges
} from '@angular/core';
import {
    ControlValueAccessor,
    NG_VALUE_ACCESSOR,
} from '@angular/forms';
@Component({
    selector: 'app-selection-list',
    template: `<div class="selection-list">
              <ng-content select=".selection-list-content"></ng-content>
    </div>`,
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => SelectionListComponent),
            multi: true
        }
    ]
})
export class SelectionListComponent implements OnInit, AfterViewInit, OnDestroy, OnChanges {
    @Input() public selectionListOptions: SelectionListOptions;
    @Input() public modelProperty: any;
    @Output() public selection: EventEmitter<any> = new EventEmitter<any>();
    public ItemsList: any[];
    private _previousRowIndex = -1;
    private _selectedItems: any[] = [];
    private _selectedItemIndexes: number[] = [];
    private _eventListener: Function = null;
    constructor(
        private el: ElementRef,
        private renderer: Renderer) { }
    public ngOnInit() {
        this.initiate();
    }
    public ngOnChanges(changes: any): void {
        this.initiate();
    }
    public writeValue(value: any): void {
    }
    public registerOnChange(fn: (value: any) => void) {
    }
    public registerOnTouched(fn: () => {}): void {
    }
    public initiate() {
        this.selectionListOptions.itemHighlightSelector =
            this.selectionListOptions.itemHighlightSelector || this.selectionListOptions.itemSelector;
        if (this.selectionListOptions.DataProvider &&
            this.selectionListOptions.DataProvider.subscribe) {
            this.selectionListOptions.DataProvider.subscribe((mtResponse: ActivitiModel.MTResponse<any>) => {
                this.ItemsList = mtResponse.payload;
            });
        } else {
            this.ItemsList = this.selectionListOptions.DataProvider;
        }
    }
    public ngAfterViewInit() {
        if (this.isNonEmptyArray(this.selectionListOptions.SelectedItems)) {
            // Handle default selection
        }
    }
    public ngOnDestroy() {
    }
    @HostListener('click', ['$event']) public onkeyup($event: any) {
        this.onItemClicked($event);
    }
    private onItemClicked($event: any) {
        const selectedRowElement = this.getClickedParentRowElement($event.target);
        if (selectedRowElement) {
            let isActive = selectedRowElement.classList.contains('active');
            const activeRowIndex = parseInt(selectedRowElement.id.split('-')[1], 10);
            console.log('multiselect', this.selectionListOptions.isMultiSelect);
            isActive = !this.selectionListOptions.isSelectionToggleAllowed ? true : !isActive;
            if (!this.selectionListOptions.isMultiSelect) {
                const items = this.el.nativeElement
                    .querySelectorAll(this.selectionListOptions.itemHighlightSelector);
                if (this.isNonEmptyArray(items)) {
                    for (const item of items) {
                        this.renderer.setElementClass(item, 'active', false);
                    }
                }
            }
            this.renderer.setElementClass(selectedRowElement, 'active', isActive);
            this.updateSelectedIndexes();
            this.onItemSelectedCallback();
            this._previousRowIndex = activeRowIndex;
        }
    }
    private getSelectedItems(selectedIndexes: number[]) {
        const result = [];
        if (this.isNonEmptyArray(selectedIndexes)) {
            for (const value of selectedIndexes) {
                result.push(this.ItemsList[value]);
            }
        }
        return result;
    }
    private onItemSelectedCallback() {
        this._selectedItems = [];
        this._selectedItems = this.getSelectedItems(this._selectedItemIndexes);
        this.selection.emit(this._selectedItems);
        console.log('selectedItem', this._selectedItems);
    }
    private updateSelectedIndexes() {
        this._selectedItemIndexes = [];
        const items = this.el.nativeElement
            .querySelectorAll(this.selectionListOptions.itemHighlightSelector);
        if (this.isNonEmptyArray(items)) {
            for (let index = 0; index < items.length; index++) {
                const item = items[index];
                if (item.classList.contains('active')) {
                    this._selectedItemIndexes.push(index);
                }
            }
        }
    }
    private isNonEmptyArray(arrayToTest: any[]): boolean {
        return arrayToTest && arrayToTest.length > 0;
    }
    private getClickedParentRowElement(element: Element): Element {
        if (element) {
            if (element.classList.contains(this.selectionListOptions.itemHighlightSelector
                .replace('.', '').replace('#', ''))) {
                return element;
            } else {
                return this.getClickedParentRowElement(element.parentElement);
            }
        }
    }
}
