import { Pipe, PipeTransform } from '@angular/core';
@Pipe({ name: 'doubleDigit' })
export class DoubleDigitPipe implements PipeTransform {
    transform(value: number, args: string[]): any {
        return convertToDoubleDigit(value);
    }
}
export function convertToDoubleDigit(value) {
    return ((value !== null && value !== undefined && value.toString().length === 1) ? '0' + value.toString() : value);
}
