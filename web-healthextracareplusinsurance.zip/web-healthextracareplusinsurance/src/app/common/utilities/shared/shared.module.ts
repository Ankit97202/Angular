import { NgModule, ModuleWithProviders } from '@angular/core';
import { LoanProgressComponent } from '../../../loanProgress/loan.progress.component';
import { LoanProgressService } from '../../../loanProgress/loan.progress.service';
import { CommonModule } from '@angular/common';
import { AccordionModule, CollapseModule, DatepickerModule,
    TimepickerModule, ModalModule, TabsModule, CarouselModule
} from 'ngx-bootstrap';
import { EmitterService } from '../../services/emitter.service';
import { PopupComponent } from '../popup/popup.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HorizontalScrollDirective } from '../scrollBar/scrollBar.directive';
import { SelectionListComponent } from '../selectionList';
import { PaymentComponent } from '../../../payment/payment.component';
import { PlanSummaryComponent } from '../../../planSummary/planSummary.component';
import { Ng2CompleterModule } from 'ng2-completer';
import { InsuranceQuestionsOldComponent } from '../../components/insuranceQuestions/insuranceQuestions-old.component';
import { InsuranceQuestionsComponent } from '../../components/insuranceQuestions/insuranceQuestions.component';
import { DoubleDigitPipe } from '../pipes/DoubleDigit.pipe';
import { SpacePipe } from '../pipes/SpacePipe.pipe';
import { CongratulationsBannerComponent } from 'src/app/finalModule/congratulations/congratulationsBanner/congratulationsBanner.component';
// Application wide providers
const APP_PROVIDERS = [
    EmitterService,
    LoanProgressService
];
@NgModule({
    declarations: [
        LoanProgressComponent,
        PopupComponent,
        HorizontalScrollDirective,
        SelectionListComponent,
        PaymentComponent,
        PlanSummaryComponent,
        InsuranceQuestionsComponent,
        InsuranceQuestionsOldComponent,
        DoubleDigitPipe,
        SpacePipe,
        CongratulationsBannerComponent
    ],
    imports: [
        CommonModule,
        ReactiveFormsModule,
        Ng2CompleterModule,
        ModalModule.forRoot(),
        TabsModule.forRoot(),
        AccordionModule.forRoot(),
        CarouselModule.forRoot()
    ],
    exports: [
        LoanProgressComponent,
        ModalModule,
        ReactiveFormsModule,
        TabsModule,
        PopupComponent,
        HorizontalScrollDirective,
        AccordionModule,
        SelectionListComponent,
        PaymentComponent,
        PlanSummaryComponent,
        Ng2CompleterModule,
        InsuranceQuestionsComponent,
        InsuranceQuestionsOldComponent,
        CarouselModule,
        DoubleDigitPipe,
        SpacePipe,
        CongratulationsBannerComponent
    ]
})
export class SharedModule {

    public static forRoot(): ModuleWithProviders {
        return {
            ngModule: SharedModule,
            providers: [APP_PROVIDERS]
        };
    }
}
