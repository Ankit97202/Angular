import { Response, RequestOptionsArgs } from '@angular/http';
import { Subscription } from 'rxjs/Subscription';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { CommonConstants } from './../commonConstants';
import { CookieHandlerService } from './../../services/cookieHandler.service';
import { Formatter } from './../../services/formatter';
import { CompleterBaseData } from './completer-base-data';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
@Injectable({
    providedIn: 'root'
})
export class RemoteData extends CompleterBaseData {
    public IsError: string = null;
    public AllMatchedData: any;
    private _remoteUrl: string;
    private remoteSearch: Subscription;
    private _urlFormater: (term: string) => string = null;
    private _dataField: string = null;
    private _customValueAllowed = true;
    private _constantID: string;
    private static ConvertGuradKeyToGuardToken(guardKey: string): string {
        const salt = 'B!&1j';
        const timeStamp = new Date().getTime();
        const token = salt.concat(CommonConstants.PIPE_SEPARATOR,
            timeStamp.toString(),
            CommonConstants.PIPE_SEPARATOR,
            guardKey);
        return btoa(token);
    }
    private static UUID(): string {
        if (typeof (window.crypto) !== 'undefined'
            && typeof (window.crypto.getRandomValues) !== 'undefined') {
            const buf: Uint16Array = new Uint16Array(8);
            window.crypto.getRandomValues(buf);
            return (this.pad4(buf[0]) + this.pad4(buf[1]) + ' ' + this.pad4(buf[2])
                + ' ' + this.pad4(buf[3]) + ' ' + this.pad4(buf[4]) + ' ' + this.pad4(buf[5])
                + this.pad4(buf[6]) + this.pad4(buf[7]));
        } else {
            return this.random4() + this.random4() + ' '
                + this.random4() + ' ' + this.random4() + ' ' +
                this.random4() + ' ' + this.random4() + this.random4() + this.random4();
        }
    }
    private static pad4(num: number): string {
        let ret: string = num.toString(16);
        while (ret.length < 4) {
            ret = '0' + ret;
        }
        return ret;
    }
    private static random4(): string {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }
    constructor(
        private http: HttpClient,
        private _cookieHandler: CookieHandlerService
    ) {
        super();
    }
    public remoteUrl(remoteUrl: string) {
        this._remoteUrl = remoteUrl;
        return this;
    }
    public urlFormater(urlFormater: (term: string) => string) {
        this._urlFormater = urlFormater;
    }
    public dataField(dataField: string) {
        this._dataField = dataField;
    }
    public isCustomValueAllowed(flag: boolean) {
        if (flag !== null && flag !== undefined) {
            this._customValueAllowed = flag;
        }
        return this;
    }
    public search(term: string): void {
        this.cancel();
        let url = '';
        if (this._urlFormater) {
            url = this._urlFormater(term);
        } else {
            url = this._remoteUrl + encodeURIComponent(term);
        }
        const option = '';
        this._headers = this.getHeaders(option);
        this.remoteSearch = this.http.get(url, { headers: this._headers || new HttpHeaders() })
            .map((data: any) => {
                this.disableCustomSelection(false);
                const matchaes = this.extractValue(data, this._dataField);
                const allValues = this.extractMatches(matchaes, term);
                if (allValues && allValues.length > 0) {
                    this.setAllMatchedValues(allValues);
                    return allValues;
                } else if (this._customValueAllowed) {
                    this.disableCustomSelection(false);
                } else {
                    this.disableCustomSelection(true);
                }
            })
            .map(
                (matches: any[]) => {
                    const results = this.processResults(matches, term);
                    this.next(results);
                    return results;
                })
            .catch((err) => {
                this.error(err);
                return of(false); // null;
            })
            .subscribe();
    }
    public cancel() {
        if (this.remoteSearch) {
            this.remoteSearch.unsubscribe();
        }
    }
    private disableCustomSelection(isDisabled: boolean) {
        this.IsError = isDisabled ? 'Please select from the list.' : null;
    }
    private setAllMatchedValues(matchedData) {
        this.AllMatchedData = matchedData;
    }
    private getHeaders = (customOptions: RequestOptionsArgs): HttpHeaders => {
        this._constantID = this.createID();
        if (this.createGuardTokenOnRequest()) {
            const headerObj: HttpHeaders = new HttpHeaders({
                'Content-Type': 'application/json',
                'cmptcorrid': this._constantID + '|' + this.createID(),
                'authtoken': this._cookieHandler.GetCookie(CommonConstants.CookieKeys.JWToken),
                'guardtoken': this._cookieHandler.GetCookie(CommonConstants.CookieKeys.GuardToken),
            });
            if (customOptions && customOptions.headers && customOptions.headers.keys()) {
                customOptions.headers.keys().forEach((key: string, index: number) => {
                    headerObj.set(key, customOptions.headers.get(key));
                });
            }
            return headerObj;
        }
    }
    private createGuardTokenOnRequest() {
        const newGuardToken = RemoteData.ConvertGuradKeyToGuardToken(
            this._cookieHandler.GetCookie(CommonConstants.CookieKeys.GuardKey));
        this._cookieHandler.SetCookie(CommonConstants.CookieKeys.GuardToken,
            newGuardToken);
        return true;
    }
    private createID() {
        return RemoteData.UUID();
    }
}
