import { HttpClient } from '@angular/common/http';
import { LocalData } from './local-data';
import { RemoteData } from './remote-data';
import { CookieHandlerService } from './../../services/cookieHandler.service';
export function localDataFactory () {
    return () => {
        return new LocalData();
    };
}
export function remoteDataFactory (http: HttpClient, cookieHandler: CookieHandlerService) {
    return () => {
        return new RemoteData(http, cookieHandler);
    };
}
export let LocalDataFactoryProvider = {provide: LocalData, useFactory: localDataFactory};
export let RemoteDataFactoryProvider = {provide: RemoteData, useFactory: remoteDataFactory,
    deps: [HttpClient]};
