import { Directive, ElementRef, ApplicationRef, Renderer, HostListener } from '@angular/core';
@Directive({
    selector: '[scrollHorizontalEvent]',
})
export class HorizontalScrollDirective {
    constructor(private el: ElementRef,
        private renderer: Renderer,
        private _appRef: ApplicationRef) {
    }
    @HostListener('click', ['$event'])
    onClick($event) {
        let element = document.querySelector('.scrollable');
        let elementWidth = document.querySelector('.scrollable').clientWidth;
        let leftOffsetEle = <HTMLElement> document.querySelector('.scrollable');
        let leftOffset = leftOffsetEle.offsetLeft;
        let parentEleWidth = (document.querySelector('.scrollable').parentElement.parentElement.clientWidth - 73);
        let parentLeftOffset = document.querySelector('.scrollable').parentElement.offsetLeft;
        let totalWidth = element.clientWidth;
        let val = 100;
        console.log("working..directive" + $event.target.id);
        if (elementWidth > parentEleWidth) {
            if ($event.target.id === 'right') {
                /**
                 * scroll to right
                 */
                let leftOffsetPos = Math.abs(leftOffset);
                if((totalWidth - leftOffsetPos) > parentEleWidth) {
                    this.renderer.setElementStyle(element, 'left', ((leftOffset - val) + 'px'));
                }
            } else {
                /**
                 * scroll to left
                 */
                let leftOffsetPos = Math.abs(leftOffset);
                if (leftOffset < parentLeftOffset) {
                    this.renderer.setElementStyle(element, 'left', ((leftOffset + val) + 'px'));
                }
            }
        }
    }
}
