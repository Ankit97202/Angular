import { Component, OnInit, ChangeDetectorRef, AfterViewInit, AfterViewChecked } from '@angular/core';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { CommonConstants } from './common/utilities/commonConstants';
import { EmitterService } from './common/services/emitter.service';
import { environment } from '../environments/environment';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements AfterViewChecked {
  title = 'app';
  // Bajaj Logo goes here
  public bajajclassLogo = 'assets/img/bfs-logo-mod.png';
  public angularclassLogo = 'assets/img/angularclass-avatar.png';
  public name = 'This is test page';
  public url = 'some URL';
  public HasError: boolean;
  // public ErrorMessage: string = CommonConstants.DEFAULT_EMPTY_STRING;
  public IsLoadingTask = false;
  // public MainLoadingText: string = "Stay with us. We're almost done...";
  constructor(
    private _emitterService: EmitterService,
    private cdRef: ChangeDetectorRef
  ) {}
  public ngAfterViewChecked() {
    this.cdRef.detectChanges();
  }
  public ngOnInit() {
     this.addAnalyticsScript();
  }  
  private addAnalyticsScript() {
    const path = environment['AnalyticsLink'];
    const scriptTag = document.createElement('script');
    scriptTag.setAttribute('src', path);
    scriptTag.setAttribute('async','');
    document.head.appendChild(scriptTag);
  }
}