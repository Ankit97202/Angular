import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpResponse } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { ConfigService } from './../common/services/config.service';
import { CommonConstants } from './../common/utilities/commonConstants';
import { CookieHandlerService } from './../common/services/cookieHandler.service';
import { HomeService } from './home.service';
import { RouteContextProvider } from './../common/services/routeContextProvider.service';
import { RouteHandlerService } from './../common/services/routeHandler.service';
import { SharedService } from './../common/services/sharedService';
import { ActivitiHandlerService } from './../common/services/activitiHandler.service';
import { Formatter } from './../common/services/formatter';
import { EmitterService } from './../common/services/emitter.service';
@Component({
    selector: 'app-home',
    template: '',
    styleUrls: ['./home.style.css'],
    providers: [HomeService, HttpModule]
})
export class HomeComponent implements OnInit {
    private _UTMDataObject: any;
    public RedirectionRequired: Boolean = true;
    constructor(
        private _homeService: HomeService,
        private _routeContextProvider: RouteContextProvider,
        private _cookieHandler: CookieHandlerService,
        private _sharedService: SharedService,
        private _routerService: RouteHandlerService,
        private _formatter: Formatter,
        private _activitiHandler: ActivitiHandlerService,
        private _emitterService: EmitterService
    ) { }
    public ngOnInit(): void {
        this.setMobileValues();
        this._sharedService.setData(CommonConstants.QueryParamsKeys.appUtmRefCode,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.appUtmRefCode));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.appUtmSource,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.appUtmSource));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.appUtmMedium,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.appUtmMedium));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.appUtmCampaign,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.appUtmCampaign));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.appUtmTerm,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.appUtmTerm));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.appUtmContent,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.appUtmContent));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.BFLBranch,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.BFLBranch));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.GCLID,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.GCLID));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.ApplicantId,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.ApplicantId));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.ApplicationId,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.ApplicationId));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.ApplicationApplicantId,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.ApplicationApplicantId));
        this.storeDetailsToCookies();
        this.authenticateSystem(true);
    }
    // this checks if user should be ab tested or not?
    private initProcess(callback: Function) {
        this.startActivitiWithApplicationCreate(
            CommonConstants.LOAN_PRODUCT_CODES.Health_ExtraInsurance,
            CommonConstants.LOAN_PRODUCT_CATEGORY_CODES.Health_ExtraInsurance,
            (mtResponse: ActivitiModel.MTResponse<any>) => {
                callback(mtResponse);
            });
    }
    private startActivitiWithApplicationCreate(
        loanProduct: string,
        productCategoryCode: string,
        onSuccessCallback: Function,
        calculatorProductType?: number,
        isLocationProvided?: boolean) {
        const startActivitiRequest: any = {
            activitiName: 'startFlow',
            payload: this.getApplicationCreateRequest(
                loanProduct, productCategoryCode, calculatorProductType, isLocationProvided)
        };
        console.log(startActivitiRequest);
        this.startActiviti(startActivitiRequest, onSuccessCallback);
    }
    private startActiviti(request: any, onSuccessCallback: Function) {
        this._activitiHandler.StartActiviti(request, true)
            .subscribe((response: ActivitiModel.MTResponse<any>) => {
                console.log('Raw Activiti working now');
                const data = response;
                if (!data.errorBean) {
                    this._cookieHandler.SetCookie(CommonConstants.CookieKeys.ProcessInstanceDetails,
                        data.payload.processInstanceDetails);
                    onSuccessCallback(data);
                }
            },
                (Error) => {
                    console.log(Error);
                });
    }
    // need to check the following values when we deploy this
    private getApplicationCreateRequest(
        LoanProduct: string,
        ProductCategoryCode: string,
        CalculatorProductType?: number,
        IsLocationProvided?: boolean) {
        const mediumFromWeb: string =
            this._sharedService.getData(CommonConstants.QueryParamsKeys.appUtmMedium).toString();
        const medium = 'Webengage_repeat_visitor_finance_homepage_PL_apply_online_link';
        return {
            appJourneyStamp: 'journeyStamp',
            appSource: 'Browser',
            appStatus: 0,
            bflBranch: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.BFLBranch)) || '320',
            productCategoryCode: ProductCategoryCode,
            insuranceApplications: {
                insProduct: CommonConstants.LOAN_PRODUCT_CODES.Health_ExtraInsurance
            },
            appUtmRefCode: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.appUtmRefCode)) || '',
            appUtmSource: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.appUtmSource)) || 'Organic',
            appUtmMedium: mediumFromWeb || medium,
            appUtmCampaign: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.appUtmCampaign)) || '',
            appUtmTerm: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.appUtmTerm)) || '',
            appUtmContent: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.appUtmContent)) || '',
            gclId: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.GCLID))
                || 'EAIaIQobChMIsZGIyZn01AIV1IdoCh19HAKqEAAYASAAEgKWjfD_BwE',
            applicantId: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.ApplicantId)) || '',
            applicationId: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.ApplicationId)) || '',
            appApplicantId: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.ApplicationApplicantId)) || ''
        };
    }
    private checkUtmSources(utmObj) {
        if (Object.keys(utmObj).length !== 0) {
            return utmObj;
        } else {
            return false;
        }
    }
    public authenticateSystem(redirectionRequired?:boolean): void {
        this.RedirectionRequired = redirectionRequired;
        if(! this.RedirectionRequired)
             this._cookieHandler.SetCookie(CommonConstants.CookieKeys.JourneyType,'');
        const userClientId = this._homeService.GetClientIdForUser();
        this.setSecretKeyForClientId(userClientId);
    }
    private setSecretKeyForClientId(clientId: string): void {
        this._homeService.GetSecretKeyForBasedOnClientId(clientId).subscribe((responseData: ActivitiModel.MTResponse<any>) => {
            if (!responseData.errorBean) {
                this._cookieHandler
                    .SetCookie(CommonConstants.CookieKeys.ClientId, clientId);
                this._cookieHandler
                    .SetCookie(CommonConstants.CookieKeys.SecretKey,
                        responseData.payload.secretKey);
                this.setSystemAuthToken(responseData.payload.secretKey, clientId);
            }
        });
    }
    private setSystemAuthToken(secretKey: string, clientId: string): void {
        this._homeService.GetSystemAuthToken({
            secretKey,
            clientId
        }).subscribe((responseData: ActivitiModel.MTResponse<any>) => {
            if (!responseData.errorBean) {
                const tokenObj = responseData.payload.tokens[0];
                console.log('tokens::', tokenObj);
                this._cookieHandler.SetCookie(CommonConstants.CookieKeys.JWToken, tokenObj.token);
                this._cookieHandler.SetCookie(CommonConstants.CookieKeys.GuardKey, tokenObj.guardKey);
                this._cookieHandler.SetCookie(CommonConstants.CookieKeys.GuardToken, this._formatter
                    .ConvertGuradKeyToGuardToken(tokenObj.guardKey));
                if(this.RedirectionRequired )
                this.initProcess((mtResponse) => {
                    this._activitiHandler.MarkTaskAsCompleted(null, 'Manual', true)
                        .subscribe((resp) => {
                            mtResponse = resp;
                            if (!mtResponse.errorBean) {
                                this._routerService.RouteToNextTask(mtResponse.nextTaskKey);
                            } else {
                                console.log('Error Occured on ', mtResponse.errorBean);
                            }
                        },
                            (error) => {
                                console.log(error);
                            });
                });
            }
        });
    }
    private storeDetailsToCookies() {
        this._cookieHandler.SetCookie(CommonConstants.CookieKeys.LoanApplicationId,
            this._sharedService.getData(CommonConstants.QueryParamsKeys.ApplicationId));

        this._cookieHandler.SetCookie(CommonConstants.CookieKeys.LoanApplicationKey,
            this._sharedService.getData(CommonConstants.QueryParamsKeys.ApplicationApplicantId));
    }
    private setMobileValues() {
        this._emitterService.Get(CommonConstants.EmitterEventTypes.MobileAppCheck)
            .emit(this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.IsMobile));

        // Set Mobile cookie
        this._cookieHandler.SetCookie(CommonConstants.CookieKeys.MobileState,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.IsMobile));
    }
}
