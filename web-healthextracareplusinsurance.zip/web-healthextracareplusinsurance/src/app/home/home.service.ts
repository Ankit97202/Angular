import { Headers, Http, RequestOptions, Response } from '@angular/http';
import { ConfigService } from './../common/services/config.service';
import { HttpInterceptor } from '../common/services/httpInterceptor.service';
import { Injectable } from '@angular/core';
import { CookieHandlerService } from './../common/services/cookieHandler.service';
import { CommonConstants } from './../common/utilities/commonConstants';
import { Observable } from 'rxjs';
@Injectable({
    providedIn: 'root'
})
export class HomeService {
    constructor(
        private _httpInterceptor: HttpInterceptor,
        private _cookieHandler: CookieHandlerService
    ) {
    }
    public StartActiviti(data: any): Observable<ActivitiModel.MTResponse<any>> {
        return this._httpInterceptor.Post(
            ConfigService.getInstance().getConfigObject().APIURL.startApplicationActiviti, data);
    }
    public GetClientIdForUser(): string {
        return 'bflclienthxi';
    }
    public GetSecretKeyForBasedOnClientId(clientId: string): Observable<ActivitiModel.MTResponse<any>> {
        return this._httpInterceptor.Get(this.getUrlBasedOnKey('getSecretKey').replace('{0}',
            clientId), true);
    }
    public GetSystemAuthToken(requestData: any): Observable<ActivitiModel.MTResponse<any>> {
        const customHeaders = {
            platform: this.getDevicePlatformType()
        };
        return this._httpInterceptor.Post(this.getUrlBasedOnKey('getTokenForUser'),
        requestData, true);
    }
    private getDevicePlatformType(): string {
        const cookieData = this._cookieHandler
            .GetCookie(CommonConstants.CookieKeys.DeviceDetails);
        if (cookieData && cookieData !== '') {
            const deviceDetails: DeviceDetails = JSON.parse(cookieData);
            return deviceDetails.mobile ? 'mob' : 'desk'; // desk, mob, moba
        } else {
            return 'desk';
        }
    }
    private getUrlBasedOnKey(key: string): string {
        return ConfigService.getInstance().getConfigObject().APIURL[key];
    }
}
