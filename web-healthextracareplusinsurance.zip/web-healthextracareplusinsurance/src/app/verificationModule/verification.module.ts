import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';
import * as ModuleComponent from '.';
import { ConfigResolve } from '../common/services/config.resolve.service';
import { CommonConstants } from '../common/utilities/commonConstants';
import { SharedModule } from '../common/utilities/shared/shared.module';
@NgModule({
    declarations: [
        ModuleComponent.VerifyMobileComponent
    ],
    imports: [ // import Angular's modules
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        HttpModule,
        SharedModule,
        RouterModule.forChild([
            {
                path: CommonConstants.Routes.Verification.VerifyMobile,
                component: ModuleComponent.VerifyMobileComponent,
                resolve: { config: ConfigResolve }
            }
        ])
    ],
    providers: [ // expose our Services and Providers into Angular's dependency injection
    ]
})
export class VerificationModule { }