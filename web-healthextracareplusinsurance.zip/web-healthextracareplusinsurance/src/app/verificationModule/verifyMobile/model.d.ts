declare module Model {
    export interface MobileVerificationInputPayload {
        mobilenumber: string;
        mobileFlag: boolean;
        applicantId: string;
        dateOfBirth :string;
        selectedPlanDetails: ActivitiModel.PlanDetails;
        premiumBreResponse:any;
    }
    export interface MobileVerificationOutputPayload {
        otp?: string;
        mobile: string;
        source: string;
    }  
}