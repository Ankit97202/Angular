import { PaymentStatusService } from './../../../paymentReview/paymentStatus.service';
import { PaymentReviewComponent } from './../../../paymentReview/paymentReview.component';
import { HttpResponse, HttpClient, HttpHandler } from '@angular/common/http';
import { TestBed, inject } from '@angular/core/testing';
import { VerifyMobileComponent } from './../verifyMobile.component';
import { BaseRequestOptions, ConnectionBackend, Http, Response, ResponseOptions, XHRBackend } from '@angular/http';
import { RouterTestingModule } from '@angular/router/testing';
import { ActivitiHandlerService } from './../../../common/services/activitiHandler.service';
import { CookieHandlerService } from 'src/app/common/services/cookieHandler.service';
import { RouteContextProvider } from 'src/app/common/services/routeContextProvider.service';
import { AnalyticsService } from 'src/app/common/services/device.analytics.service';
import { SharedService } from 'src/app/common/services/sharedService';
import { RouteHandlerService } from './../../../common/services/routeHandler.service';
import { FormValidator } from './../../../common/services/formValidator.service';
import { Formatter } from 'src/app/common/services/formatter';
import { Observable } from 'rxjs/Observable';
import { FormBuilder, NG_VALUE_ACCESSOR } from '@angular/forms';
import { HttpInterceptor } from '../../../common/services/httpInterceptor.service';
import { of } from 'rxjs';
import { MockBackend } from '@angular/http/testing';
import { Tree } from '@angular/router/src/utils/tree';
import { CookieService } from 'ngx-cookie-service';
const mockMarkTaskdata: HttpResponse<any> = new HttpResponse({
    body: {
      payload: null,
      userInput: null,
      status: 'SUCCESS',
      errorBean: null,
      nextTaskKey: 'healthExtraCarePaymentPreview',
      progressInfo: null,
      routesInfo: null
    }
  });
const mockData: HttpResponse<any> = new HttpResponse({
    body: {
      payload: {
        mobileFlag: true,
        mobilenumber: '8800221135',
        applicantId: '35643'
      },
      userInput: null,
      status: 'SUCCESS',
      errorBean: null,
      nextTaskKey: 'healthExtraCareMobileVerification',
      progressInfo: {
        payload: [
          {
            name: 'Explore Right Plan',
            value: 100,
            active: false
          },
          {
            name: 'Application Stage',
            value: 100,
            active: false
          },
          {
            name: 'Final Check',
            value: 15,
            active: true
          },
          {
            name: 'Close The Deal',
            value: 0,
            active: false
          }
        ],
        status: 'SUCCESS',
        errorBean: null
      },
      routesInfo: {
        mainRoute: 'verifyDetails',
        subRoute: ''
      }
    }
});
const data: any = {
  mobileFlag: true,
  mobilenumber: '8800221135',
};
class MockActivitiHandlerService {
  public MarkTaskAsCompleted() {
    return of(mockMarkTaskdata.body);
  }
  public GetTaskDetails() {
    return of(mockData.body);
  }
}
describe('Verify Mobile Component', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [
        VerifyMobileComponent,
        PaymentReviewComponent,
        PaymentStatusService,
        HttpInterceptor,
        HttpClient,
        HttpHandler,
        RouterTestingModule,
        Formatter,
        FormValidator,
        FormBuilder,
        RouteHandlerService,
        FormValidator,
        SharedService,
        AnalyticsService,
        RouteContextProvider,
        MockBackend,
        { provide: XHRBackend, useClass: MockBackend },
        CookieHandlerService,
        CookieService,
        {
          provide: ActivitiHandlerService,
          useClass: MockActivitiHandlerService
        },
        {
          provide: Http,
          useFactory: (
            backend: ConnectionBackend,
            defaultOptions: BaseRequestOptions
          ) => {
            return new Http(backend, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        }
      ]
    });
  });
  it('Testing ngOnInit', inject(
    [VerifyMobileComponent],
    (testComponent: VerifyMobileComponent) => {
      testComponent.ngOnInit();
    }
  ));
  it('Testing Next', inject(
    [VerifyMobileComponent],
    (testComponent: VerifyMobileComponent) => {
      testComponent.ngOnInit();
      testComponent.Next();
    }
  ));
  it('should check SendMobileOTP() method', inject(
    [VerifyMobileComponent],
    (testComponent: VerifyMobileComponent) => {
      testComponent.ngOnInit();
      const formValue: any = { otp: '' };
      testComponent.SendMobileOTP(formValue);
    }
  ));
  it('should check ResendOTP() method', inject(
    [VerifyMobileComponent],
    (testComponent: VerifyMobileComponent) => {
      testComponent.ngOnInit();
      testComponent.ResendOTP(data);
    }
  ));
  it('should check VerifyOTP() method', inject(
    [VerifyMobileComponent],
    (testComponent: VerifyMobileComponent) => {
      testComponent.ngOnInit();
      testComponent.VerifyOTP(data);
    }
  ));
  it('should check ResumeApplication() method', inject(
    [VerifyMobileComponent],
    (testComponent: VerifyMobileComponent) => {
      testComponent.ngOnInit();
      testComponent.ResumeApplication();
    }
  ));
  it('Testing Back', inject(
    [VerifyMobileComponent],
    (testComponent: VerifyMobileComponent) => {
      testComponent.ngOnInit();
      testComponent.Back();
    }
  ));
});