import { Component, ElementRef, OnInit } from '@angular/core';
import { FormValidator } from './../../common/services/formValidator.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivitiHandlerService } from './../../common/services/activitiHandler.service';
import { RouteHandlerService } from './../../common/services/routeHandler.service';
import { CommonConstants } from '../../common/utilities/commonConstants';
import { RouteContextProvider } from './../../common/services/routeContextProvider.service';
import { PaymentService } from '../../payment/payment.service';
import { PaymentStatusService } from '../../paymentReview/paymentStatus.service';
import { PaymentReviewComponent } from '../../paymentReview/paymentReview.component';
import { Formatter } from '../../common/services/formatter';
import { CookieHandlerService } from '../../common/services/cookieHandler.service';
const MockPayload: any = {
  payload: {
    mobileFlag: false,
    mobilenumber: '8800221135',
    applicantId: '35643'
  },
  userInput: null,
  status: 'SUCCESS',
  errorBean: null,
  nextTaskKey: 'healthExtraCareMobileVerification',
  progressInfo: {
    payload: [
      {
        name: 'Explore Right Plan',
        value: 100,
        active: false
      },
      {
        name: 'Application Stage',
        value: 100,
        active: false
      },
      {
        name: 'Final Check',
        value: 15,
        active: true
      },
      {
        name: 'Close The Deal',
        value: 0,
        active: false
      }
    ],
    status: 'SUCCESS',
    errorBean: null
  },
  routesInfo: {
    mainRoute: 'verifyDetails',
    subRoute: ''
  }
};
@Component({
  templateUrl: './verifyMobile.template.html',
  styleUrls: ['./verifyMobile.style.css'],
  providers: [PaymentReviewComponent, PaymentStatusService, PaymentService]
})
export class VerifyMobileComponent implements OnInit {
  public MobileVerificationForm: FormGroup;
  public WrongOtpMsg: string = null;
  public MobileOtpTrails = 0;
  public MobileResendCount = 0;
  public IsMobileValidated = false;
  public MobileOtpReceived = false;
  public IsOTPResend = false;
  public PaymentObj: Model.PaymentObject;
  public SelectedPlanDetails: ActivitiModel.PlanDetails;
  public MobileNumber: string;
  public OtpRetryMsg: string = null;
  public DateOfBirth: string;
  public PremiumBreResponse: any;
  private _journeyType = 'journey';
  private _exceptionKeysArr = ['cmobileverification'];
  private _dob: string;
  private _requestId: string;
  private _policyRef: string = null;
  private _paymentStatus: string = null;
  private _retryPaymentStatus: string = null;
  public ButtonName = 'PAY NOW';
  public PaymentIdReceived: boolean;
  public ErrorMessage: string = null;
  constructor(
    public formatter: Formatter,
    public FormValidators: FormValidator,
    private _formBuilder: FormBuilder,
    private _routerService: RouteHandlerService,
    private _activityService: ActivitiHandlerService,
    private _routeContextProvider: RouteContextProvider,
    private _paymentReviewComponent: PaymentReviewComponent,
    private _cookieHandler: CookieHandlerService,
    private paymentStatusService: PaymentStatusService,
  ) { }
  public ngOnInit() {
    this.buildMobileVerificationForm();
    this.getQueryParams()
  }
  // Sendint Mobile OTP
  public SendMobileOTP(formValue: FormData): void {
    const payload: Model.MobileVerificationOutputPayload = {
      mobile: this.MobileNumber,
      source: this._journeyType
    };
    this.markTaskAsComplete(payload, 'sendOtp', (mtResponse: ActivitiModel.MTResponse<any>) => {
      this.MobileOtpReceived = true;
    });
  }
  // Resending Mobile OTP
  public ResendOTP(formValue: FormData) {
    this.IsOTPResend = false;
    if (this.MobileResendCount === 4) {
      this.MobileResendCount = 5;
      this.IsOTPResend = true;
    }
    if (this.MobileResendCount !== 5) {
      const payload: Model.MobileVerificationOutputPayload = {
        mobile: this.MobileNumber,
        source: this._journeyType
      };
      this.markTaskAsComplete(
        payload,
        'sendOtp',
        (mtResponse: ActivitiModel.MTResponse<any>) => {
          this.MobileOtpReceived = true;
          this.IsOTPResend = true;
          this.MobileResendCount++;
        }
      );
    }
  }
  // Verifying Mobile OTP entered by user
  public VerifyOTP(formValue: FormData): void {
    if (this.MobileOtpTrails >= 5) {
      return;
    }
    const payload: Model.MobileVerificationOutputPayload = {
      otp: formValue['otp'],
      mobile: this.MobileNumber,
      source: this._journeyType
    };
    this.markTaskAsComplete(payload, 'validate', (responseData: ActivitiModel.MTResponse<any>) => {
      this.MobileOtpTrails++;
      this.IsMobileValidated = responseData.payload.mobileFlag;
    });
  }
  // Go Back
  public Back() {
    this.markTaskAsComplete(null, 'Back');
  }
  public Next() {
    this._cookieHandler.SetCookie(CommonConstants.CookieKeys.PaymentRedirect, false);
    this.markTaskAsComplete(null, '');
  }
  public Pay() {
    this._cookieHandler.SetCookie(CommonConstants.CookieKeys.PaymentRedirect, true);
    this._paymentReviewComponent.getHealthRequestId("N", this.PremiumBreResponse.applicationId);
  }
  // Building Mobile Verification Form Group
  private buildMobileVerificationForm() {
    this.MobileVerificationForm = this._formBuilder.group({
      otp: ['', Validators.compose([Validators.required])]
    });
    this.MobileVerificationForm.valueChanges.subscribe(updatedValue => {
      this.WrongOtpMsg = null;
    });
  }
  // Get task details
  private getTaskDetails(callback?) {
    this._activityService
      .GetTaskDetails('', true)
      .subscribe(
        (
          mtResponse: ActivitiModel.MTResponse<
            Model.MobileVerificationInputPayload
          >
        ) => {
          if (!mtResponse.errorBean) {
            this.IsMobileValidated = mtResponse.payload.mobileFlag;
            this.MobileNumber = mtResponse.payload.mobilenumber;
            this.DateOfBirth = mtResponse.payload.dateOfBirth;
            this.PremiumBreResponse = mtResponse.payload.premiumBreResponse
            this.PaymentObj = {
              mobileNumber: this.MobileNumber,
            };
            if (callback) {
              callback(mtResponse);
            }
            if (this.IsMobileValidated)//only if mobile validated
              this.fetchPaymentStatus(mtResponse.payload);
          }
        }
      );
  }
  // mark task complete
  private markTaskAsComplete(
    data: any,
    taskName: string,
    callback?
  ) {
    this.ErrorMessage = null;
    this._activityService
      .MarkTaskAsCompleted(data, taskName, true)
      .subscribe((mtResponse: ActivitiModel.MTResponse<any>) => {
        if (!mtResponse.errorBean) {
          if (callback) {
            this.getTaskDetails(
              (responseData: ActivitiModel.MTResponse<any>) => {
                callback(responseData);
              }
            );
          } else {
            this._routerService.RouteToNextTask(
              mtResponse.nextTaskKey,
              this._exceptionKeysArr,
              () => {
                console.log('ERROR');
              }
            );
          }
        } else if (CommonConstants.errorCodes.includes(mtResponse.errorBean[0].errorCode) && this.MobileResendCount === 0) {
          this.MobileOtpTrails++;
          this.WrongOtpMsg = mtResponse.errorBean[0].errorMessage;
        } else if (CommonConstants.errorCodes.includes(mtResponse.errorBean[0].errorCode) && this.MobileResendCount > 0) {
          this.IsOTPResend = false;
          this.MobileResendCount++;
          this.WrongOtpMsg = null;
          this.OtpRetryMsg = mtResponse.errorBean[0].errorMessage;
        } else {
          this.ErrorMessage = CommonConstants.DEFAULT_ERROR_MESSAGE;
        }
      });
  }
  // Getting All Query Params
  private getQueryParams() {
    this._paymentStatus = this._routeContextProvider.GetQueryParams(
      'p_pay_status'
    );
    this._policyRef = this._routeContextProvider.GetQueryParams('policyref');
    this._requestId = this._routeContextProvider.GetQueryParams('requestId');
    if (this._paymentStatus && this._policyRef) {
      const payload = {
        policyNo:
          this._policyRef !== 'null' && this._policyRef
            ? this._policyRef
            : null,
        transactionStatus: this._paymentStatus,
        transactionId: this._requestId, //Transaction Id
        applicationId: this._cookieHandler.GetCookie(
          CommonConstants.CookieKeys.LoanApplicationId
        ) //Transaction Id,
      };
      this.PaymentIdReceived = true;
      this.markTaskAsComplete(payload, null);
      if (this._paymentStatus === 'N') this.getTaskDetails();
    } else {
      this.getTaskDetails();
    }
  }
  private fetchPaymentStatus(data: any) {
    this.paymentStatusService
      .FetchPaymentStatus(data)
      .subscribe((resp: Model.MTResponse<any>) => {
        let mtPaymentStatusResponse: Model.MTResponse<any> = resp;
        if (mtPaymentStatusResponse.payload !== null) {
          if (!resp.payload) return;
          this._retryPaymentStatus =
            mtPaymentStatusResponse.payload.paymentStatus;
          if (
            this._retryPaymentStatus === 'Pending' ||
            this._retryPaymentStatus === 'Failed'
          ) {
            this.ButtonName = 'RETRY PAYMENT';
            this.PaymentIdReceived = false;
            this._routerService.RouteToNextTask('healthextracaremobileverification');
          } else if (this._retryPaymentStatus === 'Success') {
            this.markTaskAsComplete(null, 'PaymentSuccess');
          } else {
            this.ButtonName = 'PAY NOW';
          }
        }
      });
  }
}