import { Component, OnInit } from '@angular/core';
import { ActivitiHandlerService } from '../../common/services/activitiHandler.service';
import { RouteHandlerService } from '../../common/services/routeHandler.service';
@Component({
    templateUrl: './rejectApplication.template.html',
    styleUrls: ['./rejectApplication.style.css']
})
export class RejectApplicationComponent implements OnInit {

    constructor(private _activityHandler: ActivitiHandlerService,
        private _routerService: RouteHandlerService,
    ) {}
    // On component Init
    public ngOnInit() {
    }
    // On Back
    public ExploreMore() {
        this.markTaskAsComplete(null, '');
        window.open('https://www.bajajfinservmarkets.in','_self');
    }
    private markTaskAsComplete(data, action) {
        this._activityHandler.MarkTaskAsCompleted(data, action, true).subscribe((mtResponse) => {
            if (!mtResponse.errorBean) {
                this._routerService.RouteToNextTask(mtResponse.nextTaskKey);
            }
        });
    }
}
