import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';
import * as ModuleComponent from './index';
import { ConfigResolve } from './../common/services/config.resolve.service';
import { CommonConstants } from './../common/utilities/commonConstants';
import { SharedModule } from './../common/utilities/shared/shared.module';
@NgModule({
    declarations: [
        ModuleComponent.CongratulationsComponent,
        ModuleComponent.PaymentFailedComponent,
        ModuleComponent.RejectApplicationComponent,
        ModuleComponent.PaymentReviewComponent
    ],
    imports: [ // import Angular's modules
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        HttpModule,
        SharedModule,
        RouterModule.forChild([
            {
                path: CommonConstants.Routes.FinalModule.Congratulations,
                component: ModuleComponent.CongratulationsComponent,
                resolve: { config: ConfigResolve }
            }, {
                path: CommonConstants.Routes.FinalModule.PaymentFailed,
                component: ModuleComponent.PaymentFailedComponent,
                resolve: { config: ConfigResolve }
            }, {
                path: CommonConstants.Routes.FinalModule.RejectApplication,
                component: ModuleComponent.RejectApplicationComponent,
                resolve: { config: ConfigResolve }
            },
            {
                path: CommonConstants.Routes.FinalModule.PaymentReview,
                component: ModuleComponent.PaymentReviewComponent,
                resolve: { config: ConfigResolve }
            }
        ])
    ],
    providers: [ // expose our Services and Providers into Angular's dependency injection

    ]
})
export class FinalModule { }
