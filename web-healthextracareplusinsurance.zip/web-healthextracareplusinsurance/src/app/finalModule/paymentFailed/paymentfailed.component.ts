import { Component, OnInit, Output, ViewChild, Input } from '@angular/core';
import { CookieHandlerService } from '../../common/services/cookieHandler.service';
import { CommonConstants } from '../../common/utilities/commonConstants';
import { ActivitiHandlerService } from '../../common/services/activitiHandler.service';
import { RouteHandlerService } from '../../common/services/routeHandler.service';
@Component({
    templateUrl: './paymentFailed.template.html',
    styleUrls: ['./paymentFailed.style.css']
})
export class PaymentFailedComponent implements OnInit {
    public PaymentFailObject: Model.PaymentObject;
    public PaymentApplicationID: number;

    constructor(
        private _activitiHandlerService: ActivitiHandlerService,
        private _routerService: RouteHandlerService
    ) {}
    // On Component Init
    public ngOnInit() {
        this.getDetails();
    }
    public Next() {
        this.markTaskComplete(null, 'payLater');
    }
    public Back() {
        this.markTaskComplete(null, 'Back');
    }
    private getDetails() {
        this._activitiHandlerService.GetTaskDetails().subscribe
            ((mtResponse: ActivitiModel.MTResponse<Model.PaymentObject>) => {
                const payload = mtResponse.payload;
                this.PaymentApplicationID = payload.applicationId;
                this.PaymentFailObject = {
                    amount: payload.amount,
                    mobileNumber: payload.mobilenumber,
                    emailId: payload.personalEmailId,
                    payNowFlag: payload.payNowFlag
                };
            });
    }
    // Mark task complete
    private markTaskComplete(data:any, actionName: string) {
        // data.proposerBankDetails.ifscCode = 'ICIC0000056';
        this._activitiHandlerService.MarkTaskAsCompleted(data, actionName).subscribe((mtResponse) => {
            if (!mtResponse.errorBean) {
                this._routerService.RouteToNextTask(mtResponse.nextTaskKey);
            }
        });
    }
}
