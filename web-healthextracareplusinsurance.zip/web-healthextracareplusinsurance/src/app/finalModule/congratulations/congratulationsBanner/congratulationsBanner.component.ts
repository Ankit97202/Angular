import { Component, OnInit } from '@angular/core';
import { CommonConstants } from 'src/app/common/utilities/commonConstants';
@Component({
    selector: 'congratulations-banner',
    templateUrl: './congratulationsBanner.template.html',
    styleUrls: ['./congratulationsBanner.style.css'],
})
export class CongratulationsBannerComponent implements OnInit {
    public MutualUrl = "";
    public emistoreDUrl = "";
    public EmistoreMUrl = "";
    // Constructor
    constructor() { }
    // On init
    public ngOnInit() {
        this.MutualUrl = CommonConstants.congratulationsBanner.MutualUrl;
        this.emistoreDUrl = CommonConstants.congratulationsBanner.emistoreDUrl;
        this.EmistoreMUrl = CommonConstants.congratulationsBanner.EmistoreMUrl;
    }
    mutualLink(){
        window.open(this.MutualUrl);
        
    }
    mobileLink(){
        if(window.screen.width >=768){
            window.open(this.emistoreDUrl);
        }
        else{
            window.open(this.EmistoreMUrl);
        }        
    }
}
