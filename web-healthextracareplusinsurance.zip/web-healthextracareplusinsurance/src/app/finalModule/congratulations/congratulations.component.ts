import { Component, OnInit } from '@angular/core';
import { ActivitiHandlerService } from '../../common/services/activitiHandler.service';
import { PaymentStatusService } from '../../paymentReview/paymentStatus.service';
@Component({
    templateUrl: './congratulations.template.html',
    styleUrls: ['./congratulations.style.css'],
    providers: [PaymentStatusService]
})
export class CongratulationsComponent implements OnInit {
    public ShowLoader: boolean = false;
    public ShowDownloadOption: boolean = false;
    public PolicyNum: string = null;
    public ShowPaymentLoader: boolean = false;
    private policyUrl: string = null;
    private paymentStatus: string = null;
    // Constructor
    constructor(
        private _activityHandler: ActivitiHandlerService,
        private paymentStatusService: PaymentStatusService
    ) { }
    // On init
    public ngOnInit() {
        this.getTaskDetails();
        this.ShowPaymentLoader  =true;
    }
    // Downloading Policy
    public DownloadPolicy() {
        if (this.policyUrl) {
            window.open(this.policyUrl, '_blank');
        } else {
            console.error('ERROR:: No policy url received from service');
        }
    }
    // Get Task Details
    private getTaskDetails() {
        this._activityHandler.GetTaskDetails().subscribe((resp:ActivitiModel.MTResponse<any>) => {
            let mtResponse: ActivitiModel.MTResponse<any> = resp;
            if (!mtResponse.errorBean) {
                console.log(mtResponse);
                this.fetchPaymentStatus(mtResponse.payload);
            }
        });
    }
    /*Payment scenario
    1. Transaction Status->  Y , Customer started with payment and completed policy issuance with PDF
        Sub-stage stamping -> 100% ,Policy issuance - congratulations page with policy number and Policy PDF link
    2. Transaction Status->  Y , Customer completed payment process, navigated to policy issuance page but only has policy number
        Sub-stage stamping -> 100% ,Policy issuance - congratulations page with policy number
    3. Transaction Status->  Y , Payment process completed but policy issuance failed
        Sub-stage stamping -> 90% ,Policy issuance - Payment success - Congratulations page on payment receival
    */
    private fetchPaymentStatus(data: any) {
        this.paymentStatusService.FetchPaymentStatus(data).subscribe((resp:ActivitiModel.MTResponse<any>) => {
            let mtPaymentStatusResponse: ActivitiModel.MTResponse<any> = resp;
            if(!resp.errorBean)
            {
            this.ShowDownloadOption = mtPaymentStatusResponse.payload.policyDocumentDownloaded;;
            this.PolicyNum = mtPaymentStatusResponse.payload.policyNumber;
            this.policyUrl = mtPaymentStatusResponse.payload.policyUrl;
            this.paymentStatus = mtPaymentStatusResponse.payload.paymentStatus;
            //add loader
            (async () => {
                await this.delay(4000);
                this.ShowPaymentLoader = false;
            })();
            if (this.policyUrl || this.PolicyNum) {
                this.markTaskComplete(null, 'policyIssued');
            }
         }
         else
         {
            this.ShowPaymentLoader = false;
            console.error('ERROR::', resp.errorBean);
         }
        });
    }
    private markTaskComplete(data, action) {
        this._activityHandler.MarkTaskAsCompleted(data, action, true).subscribe((resp) => {
            // blank
        });
    }
    private delay(ms: number) {
        return new Promise( resolve => setTimeout(resolve, ms) );
    }
}
