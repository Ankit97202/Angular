import { Component, OnInit, Output, ViewChild } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { FormValidator } from '../../common/services/formValidator.service';
import { ActivitiHandlerService } from '../../common/services/activitiHandler.service';
import { RouteHandlerService } from '../../common/services/routeHandler.service';
import { PincodeHandlerService } from '../../common/services/pincodeHandler.service';
import { CookieHandlerService } from '../../common/services/cookieHandler.service';
import { CommonConstants } from '../../common/utilities/commonConstants';
import { SharedService } from '../../common/services/sharedService';
import { Formatter } from 'src/app/common/services/formatter';
@Component({
  selector: 'app-address-details',
  templateUrl: './addressDetails.template.html',
  styleUrls: ['./addressDetails.style.css']
})
export class AddressDetailsComponent implements OnInit {
  public showLoader = false;
  public CurrentAddressDetails: FormGroup;
  public DisableArea: boolean;
  public HealthPlanDetails: Model.HealthPlanDetails;
  private _outputPayload = <Model.AddressDetailsOutputPayload> {};
  public SelectedPlanDetails: Model.SelectedPlanDetails;
  public InsuredCount:number;
  private addressDetails = <Model.addressModel>{};
  private _addressFields = ['locality', 'street', 'pincode', 'state'];
  constructor(
    private _sharedService: SharedService,
    private _cookieHandler: CookieHandlerService,
    public FormValidators: FormValidator,
    private _activitiHandlerService: ActivitiHandlerService,
    private _routerService: RouteHandlerService,
    private _formBuilder: FormBuilder,
    private _pincodeService: PincodeHandlerService,
    private _formatter: Formatter
  ) { }
  ngOnInit() {
    this.buildForm();
    this.getTaskDetails();
  }
  // Pin code change function.
  public OnPincodeChange($event, formGroup: FormGroup) {
    this.DisableArea = true;
    formGroup.controls['state'].setValue('');

    this._pincodeService.OnPinCodeChanged($event, () => {
      if (this._pincodeService.GeoLocationDetails) {
        formGroup.controls['pincode']
          .setValue(this._pincodeService.GeoLocationDetails.pinCode);
        formGroup.controls['state'].setValue(
          this._pincodeService.GeoLocationDetails.city.concat(
            ', ', this._pincodeService.GeoLocationDetails.stateShortName)
        );
        this.DisableArea = false;
      } else {
        formGroup.controls['pincode'].setValue('');
        formGroup.controls['state'].setValue('');
      }
    });
  }
  public Next() {
    this.preparePayload();
    this.markTaskComplete(this._outputPayload, null);
  }
  public Back() {
    this.markTaskComplete(null, 'Back');
  }
  public buildForm() {
    const fields = {
      locality: ['', [Validators.required]],
      street: ['', [Validators.required]],
      pincode: ['', [Validators.required]],
      state: ['']
    };
    this.CurrentAddressDetails = this._formBuilder.group(fields);
  }
  public onInputEntry($event, nextInput) {
    const input = $event.target;
    const length = input.value.length;
    const maxLength = input.attributes.maxlength.value;
    if (length >= maxLength) {
      document.getElementById(nextInput).focus();
    }
  }
  private preparePayload() {
    const formValue = this.CurrentAddressDetails.value;
    const addr = this._pincodeService.GeoLocationDetails;
    const permanentAddr = false;
    const addressDetails: Model.addressModel = {applAddress: []};
    const applAddress = <Model.ApplAddress> {};
    applAddress['line1'] = formValue['locality'];
    applAddress['line2'] = formValue['street'];
    applAddress['pinCode'] = addr.pinCode;
    applAddress['pinId'] = addr.pinId;
    applAddress['city'] = addr.city;
    applAddress['cityId'] = addr.cityId;
    applAddress['state'] = addr.state;
    applAddress['stateId'] = addr.stateId;
    applAddress['type'] = 'CURRENT';
    applAddress['countryId'] = addr.countryId;
    applAddress['locality'] = null;
    applAddress['localityKey'] = null;
    applAddress['country'] = addr.country;
    applAddress['addSource'] = null;
    applAddress['appSource'] = null;
    this.addressDetails.applAddress = [applAddress];
    this._outputPayload.address =  this.addressDetails;
    this._outputPayload.permanentAddr = false;
  }
  // Getting Component Task details
  private getTaskDetails() {
    this._activitiHandlerService.GetTaskDetails().subscribe((mtResponse: ActivitiModel.MTResponse<any>) => {
      if (!mtResponse.errorBean) {
        const applicationID = this._sharedService.getData(CommonConstants.QueryParamsKeys.ApplicationId);
        this.HealthPlanDetails = mtResponse.payload.healthPlanDetails;
        let journeyType = CommonConstants.DEFAULT_EMPTY_STRING;
        this.SelectedPlanDetails = mtResponse.payload.selectedPlanDetails;
        this.InsuredCount = mtResponse.payload.insuredCount;
        if (applicationID)   {
            journeyType = this._cookieHandler.GetCookie(CommonConstants.CookieKeys.JourneyType, applicationID);
        }
        if (journeyType === CommonConstants.DEFAULT_EMPTY_STRING) {
          if (mtResponse.payload.newTokens) {
              this.setUserAuthToken(mtResponse.payload);
          }
        }
        if (mtResponse.userInput) {
          this.setUserInput(mtResponse.userInput.address);
        }
        else if (mtResponse.payload.proposerDetails.addressDetails)
          this.setUserInput(mtResponse.payload.proposerDetails);

      }
    });
  }
  private setUserAuthToken(responseData: any) {
    if (responseData) {
        this._cookieHandler.SetCookie(CommonConstants.CookieKeys.JWToken,
            responseData.newTokens.tokens[0].token);
        this._cookieHandler.
            SetCookie(CommonConstants.CookieKeys.GuardKey,
                responseData.newTokens.tokens[0].guardKey);
        this._cookieHandler.SetCookie(CommonConstants.CookieKeys.GuardToken,
            this._formatter
                .ConvertGuradKeyToGuardToken(
                    responseData.newTokens.tokens[0].guardKey));
    }
  }
  private setUserInput(userInput) {
    let addrDetails;
  if(userInput.addressDetails !==undefined)
      addrDetails = userInput.addressDetails[0];
  else
      addrDetails = userInput.applAddress[0];
    if(addrDetails !== null) {
     this.CurrentAddressDetails.setValue({
      locality: addrDetails.line1,
      street: addrDetails.line2,
      pincode: addrDetails.pinCode,
      state: '',
    });
    this.OnPincodeChange({ target: { value: addrDetails.pinCode } }, this.CurrentAddressDetails);
   }
  }
  // Mark task complete
  private markTaskComplete(data, actionName: string) {
    this.showLoader = true;
    this._activitiHandlerService.MarkTaskAsCompleted(data, actionName).subscribe((mtResponse) => {
      this.showLoader = false;
      if (!mtResponse.errorBean) {
        this._routerService.RouteToNextTask(mtResponse.nextTaskKey);
    }
    });
  }
}
