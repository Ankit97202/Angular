import { Component, Input, EventEmitter, OnChanges, Output, AfterContentChecked } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { FormValidator } from '../../../common/services/formValidator.service';
import { Formatter } from '../../../common/services/formatter';
import { CommonConstants } from 'src/app/common/utilities/commonConstants';
import { PersoanlDetailsService } from './personalDetails.service';
const GENDER_LIST = [
  {
    title: 'Male',
    value: 'M'
  },
  {
    title: 'Female',
    value: 'F'
  }
];
@Component({
  selector: 'app-personal-details-form',
  templateUrl: './personalDetailsForm.template.html',
  providers: [PersoanlDetailsService],
  styleUrls: ['./personalDetailsForm.style.css']
})
export class PersonalDetailsFormComponent implements OnChanges, AfterContentChecked {
  // Public Variables
  public GenderList = GENDER_LIST;
  public PersonalDetailsFormGroup: FormGroup;
  public SelectedGender: { title: string; value: string };
  public IsCorrectMobile: string;
  public ChangeInDOB: boolean;
  public domainInvalid = true;
  @Input() public ParticipantDetailsObj: ActivitiModel.ParticipantDetails;
  @Input() public Relation: string;
  @Input() public IsActive: boolean;
  @Input() public IsPaymentDone: boolean;
  @Input() public isInsured: boolean;
  @Input() public Age: number;
  @Output() public ParticipantDetailsChanged: EventEmitter<Model.PersonalDetailsEmitterModel> = new EventEmitter();
  // Private Variables
  private changedParticipantDetails: Model.InsuredDetails;
  private _contactNumber: string;
  private _emailId: string;
  // Constructor
  constructor(
    public FormValidators: FormValidator,
    private formatter: Formatter,
    private _formBuilder: FormBuilder,
    private _persoanlDetailsService: PersoanlDetailsService,
  ) { }
  // On Change
  public ngOnChanges() {
    this.buildFormGroup();
    if (this.ParticipantDetailsObj && this.IsActive) {
      this.changedParticipantDetails = Object.assign(
        {},
        this.ParticipantDetailsObj
      );
      this.setUserInput();
    }
  }

  public ngAfterContentChecked() {
    this.PersonalDetailsFormGroup.controls['emailID'].valueChanges.subscribe(() => {
      const emailID = this.PersonalDetailsFormGroup.controls['emailID'].value;
      document.getElementById('emailID').setAttribute('style', 'font-size:' + (emailID.length > 20 ? '15px' : '20px'));
    })
  }


  public OnGenderSelection(event) {
    this.SelectedGender = GENDER_LIST.find(gl => gl.value === event);
    console.log('slected gender' + this.SelectedGender);
    this.onPersonalDetailsChange();
  }
  // Auto tab date of birth
  public onInputEntry($event, nextInput) {
    const input = $event.target;
    const length = input.value.length;
    const maxLength = input.attributes.maxlength.value;
    let err = this.FormValidators.FieldHasErrors(this.PersonalDetailsFormGroup, input.id);
    if (!err && ['year', 'day', 'month'].includes(input.id)) {
      err = this.PersonalDetailsFormGroup.controls.year.hasError('rangeError');
    }
    if (length >= maxLength && !err) {
      document.getElementById(nextInput).focus();
    }
  }
  public ValidateDOB(updatedValue) {
    return this.FormValidators.ValidateDOBYearAndMonth(updatedValue, this.PersonalDetailsFormGroup, this.Relation, this.Age);
  }
  /// Validate Mobile Number
  public ValidateMobile() {
    const mobileNo = this.PersonalDetailsFormGroup.controls['mobileNumber']
      .value;
    const test = /(\d)\1{9}/g;
    if (
      mobileNo &&
      !this.FormValidators.FieldHasErrors(
        this.PersonalDetailsFormGroup,
        'mobileNumber'
      )
    ) {
      if (
        mobileNo[0] === '6' ||
        mobileNo[0] === '7' ||
        mobileNo[0] === '8' ||
        mobileNo[0] === '9'
      ) {
        this.IsCorrectMobile = null;
      } else {
        this.IsCorrectMobile = 'Please provide your correct mobile number.';
      }
      if (mobileNo.match(test)) {
        this.IsCorrectMobile = 'Please provide your correct mobile number.';
      }
    } else {
      this.IsCorrectMobile = null;
    }
  }

  // On Change of any control value
  private onPersonalDetailsChange() {
    const formValue = this.PersonalDetailsFormGroup.value;
    this.changedParticipantDetails.firstName = this.formatter.GetName(
      'first',
      formValue['fullName']
    );
    this.changedParticipantDetails.middleName = this.formatter.GetName(
      'middle',
      formValue['fullName']
    );
    this.changedParticipantDetails.lastName = this.formatter.GetName(
      'last',
      formValue['fullName']
    );
    const dob = new Date(this.getDOBString(formValue));
    const dobObj = this.FormValidators.CalculateAge(dob);
    this.changedParticipantDetails.genderCode =
      this.SelectedGender && this.SelectedGender.value;
    this.changedParticipantDetails.genederCode =
      this.SelectedGender && this.SelectedGender.value;
    this.changedParticipantDetails.genderDesc =
      this.SelectedGender && this.SelectedGender.title;
    this.changedParticipantDetails.age = dobObj[0];
    if (this.Relation === 'SELF') {
      this.changedParticipantDetails.dateOfBirth = this.getDOBString(formValue);
      this.changedParticipantDetails.phoneNumberDetails = [
        this.getPhoneDetails()
      ];
      this.changedParticipantDetails.emailDetails = [this.getEmailDetails()];
    } else {
      this.changedParticipantDetails['dob'] = this.getDOBString(formValue);
    }
    if (this.isInsured) {
      this.changedParticipantDetails.apltHeight = 183;
      this.changedParticipantDetails.apltWeight = 70;
    }
    const isFormValid = (this.PersonalDetailsFormGroup.valid && this.domainInvalid) ? true : false;
    const emmittedObj: Model.PersonalDetailsEmitterModel = {
      isFormValid: isFormValid,
      participantDetails: this.changedParticipantDetails
    };
    this.ParticipantDetailsChanged.emit(emmittedObj);
  }
  private hasAgeChanged(detailsAge: number, changedAge: number): boolean {
    return !(changedAge === detailsAge);
  }
  // Getting phone number details
  private getPhoneDetails(): ActivitiModel.PhoneNumberDetails {
    this.IsCorrectMobile = null;
    const contactNum =
      this.PersonalDetailsFormGroup.controls['mobileNumber'].value ||
      this._contactNumber;
    const phoneNumberDetails: ActivitiModel.PhoneNumberDetails = {
      key: 0,
      areaCode: '91',
      countryCode: '91',
      isDNDActive: '0',
      isPreferred: 1,
      isVerified: 0,
      number: contactNum,
      applicantKey: 0,
      type: CommonConstants.APPLICANT_PHONE_TYPES.Mobile
    };
    return phoneNumberDetails;
  }
  // Getting Email details
  private getEmailDetails(): ActivitiModel.EmailDetails {
    const emailId =
      this.PersonalDetailsFormGroup.controls['emailID'].value || this._emailId;
    const emailDetails: ActivitiModel.EmailDetails = {
      key: 0,
      emailAddress: emailId,
      isVerified: 0,
      idPriority: 1,
      type: CommonConstants.APPLICANT_EMAIL_TYPES.Personal_1,
      applicantKey: 0
    };
    return emailDetails;
  }
  // Getting DOB as String form day/month/year controls
  private getDOBString(formValue: FormData) {
    const day =
      parseInt(formValue['day'], 10) < 10
        ? '0' + parseInt(formValue['day'], 10)
        : formValue['day'];
    const month =
      parseInt(formValue['month'], 10) < 10
        ? '0' + parseInt(formValue['month'], 10)
        : formValue['month'];
    const year = formValue['year'];
    return year + '-' + month + '-' + day;
  }
  // Building Form Group
  private buildFormGroup() {
    const dobValidation = name => (control: FormControl) =>
      this.ValidateDOB({ [name]: control.value });
    const mustHaveLastName = (control: FormControl) => {
      return !control.value.trim() || control.value.trim().includes(' ')
        ? null
        : { lastNameMandatory: true };
    };
    this.PersonalDetailsFormGroup = this._formBuilder.group({
      fullName: ['', [Validators.required, mustHaveLastName]],
      day: ['', [Validators.required, dobValidation('day')]],
      month: ['', [Validators.required, dobValidation('month')]],
      year: ['', [Validators.required, dobValidation('year')]],
      mobileNumber: ['', [this.Relation === 'SELF' ? Validators.required : Validators.nullValidator]],
      gender: ['', [Validators.required]],
      emailID: ['', [this.Relation === 'SELF' ? Validators.required : Validators.nullValidator]],
    });
    this.PersonalDetailsFormGroup.valueChanges.subscribe(() => {
      this.onPersonalDetailsChange();
    });
  }
  // Setting User Input
  private setUserInput() {
    const name = [
      this.ParticipantDetailsObj.firstName,
      this.ParticipantDetailsObj.middleName,
      this.ParticipantDetailsObj.lastName
    ]
      .join(' ')
      .trim();

    if (this.ParticipantDetailsObj.dateOfBirth) {
      const dateObj = this.ParticipantDetailsObj.dateOfBirth.split('-');
      this.dob(dateObj);
    } else if (this.ParticipantDetailsObj['dob']) {
      const dateObj = this.ParticipantDetailsObj['dob'].split('-');
      this.dob(dateObj);
    }

    if (this.ParticipantDetailsObj.genederCode || this.ParticipantDetailsObj['genderCode']) {
      this.SelectedGender = {
        title: this.ParticipantDetailsObj.genderDesc,
        value: this.ParticipantDetailsObj.genederCode ? this.ParticipantDetailsObj.genederCode : this.ParticipantDetailsObj['genderCode']
      };
    } else {
      this.SelectedGender = { title: null, value: null };
    }
    this.PersonalDetailsFormGroup.controls['fullName'].setValue(name);
    if (this.ParticipantDetailsObj.phoneNumberDetails) {
      this.PersonalDetailsFormGroup.controls['mobileNumber'].setValue(
        this.ParticipantDetailsObj.phoneNumberDetails[0].number
      );
    }
    this.PersonalDetailsFormGroup.controls['gender'].setValue(
      this.SelectedGender.value
    );
    if (
      this.ParticipantDetailsObj.emailDetails &&
      this.ParticipantDetailsObj.emailDetails.length > 0 &&
      this.ParticipantDetailsObj.emailDetails[0].emailAddress
    ) {
      this.PersonalDetailsFormGroup.controls['emailID'].setValue(
        this.ParticipantDetailsObj.emailDetails[0].emailAddress
      );
    }
    this.onPersonalDetailsChange();
  }
  private dob(dateObj) {
    const day =
      parseInt(dateObj[2], 10) < 10
        ? '0' + parseInt(dateObj[2], 10)
        : dateObj[2];
    const month =
      parseInt(dateObj[1], 10) < 10
        ? '0' + parseInt(dateObj[1], 10)
        : dateObj[1];
    const year = dateObj[0];
    if (year !== '1800') {
      this.PersonalDetailsFormGroup.controls['day'].patchValue(day);
      this.PersonalDetailsFormGroup.controls['month'].patchValue(month);
      this.PersonalDetailsFormGroup.controls['year'].patchValue(year);
    }
  }
}
