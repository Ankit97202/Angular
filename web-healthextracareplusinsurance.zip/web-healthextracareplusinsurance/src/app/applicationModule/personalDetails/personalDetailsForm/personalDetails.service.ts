import { Injectable } from '@angular/core';
import { ConfigService } from '../../../common/services/config.service';
import { HttpInterceptor } from '../../../common/services/httpInterceptor.service';
import { Observable } from 'rxjs/internal/Observable';
@Injectable({
    providedIn: 'root'
})
export class PersoanlDetailsService {
    constructor(private _httpInterceptor: HttpInterceptor) { }

    public ValidatePersonalEmailID(emailID: string): Observable<ActivitiModel.MTResponse<any>> {
        let url = ConfigService.getInstance()
            .getConfigObject().APIURL.validatePersonalEmailID;
        url = url.replace('{0}', emailID);
        return this._httpInterceptor.Get(url, true);
    }
}
