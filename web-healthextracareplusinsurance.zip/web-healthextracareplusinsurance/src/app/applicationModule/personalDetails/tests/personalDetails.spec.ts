import { FormBuilder } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TestBed, inject } from '@angular/core/testing';
import { of, Observable } from 'rxjs';
import { FormValidator } from '../../../common/services/formValidator.service';
import { RouteHandlerService } from '../../../common/services/routeHandler.service';
import { PopupComponent } from '../../../common/utilities/popup/popup.component';
import { ActivitiHandlerService } from '../../../common/services/activitiHandler.service';
import { PersonalDetailsComponent } from './../personalDetails.component';
import { HttpResponse, HttpClient, HttpHandler } from '@angular/common/http';
import { Formatter } from 'src/app/common/services/formatter';
import { SharedService } from 'src/app/common/services/sharedService';
import { AnalyticsService } from 'src/app/common/services/device.analytics.service';
import { CookieHandlerService } from 'src/app/common/services/cookieHandler.service';
import { RouteContextProvider } from 'src/app/common/services/routeContextProvider.service';
import { HttpInterceptor } from 'src/app/common/services/httpInterceptor.service';
import { CookieService } from 'ngx-cookie-service';
import { debug } from 'util';
import { HomeComponent } from 'src/app/home/home.component';
import { HomeService } from 'src/app/home/home.service';
import { HttpModule } from '@angular/http';
import { ActivatedRoute, Router } from '@angular/router';
let mockData: HttpResponse<any> = new HttpResponse({
  body: {
    payload: {
      motherSelected: false,
      proposerDetails: {
        lastName: null,
        genederCode: 'M',
        apltWeight: null,
        subsegmentMaster: null,
        apltcorecusid: null,
        apltcommprefchannel: null,
        apltempid: null,
        apltstatus: null,
        apltHeight: null,
        apltlstupdatedt: null,
        passportExpDate: null,
        genderDesc: 'Male',
        maritalStatusCode: null,
        nationalityCode: null,
        monthlyObligation: null,
        apltstatuschgdate: null,
        apltlstupdateby: null,
        relationship: null,
        apltcustcif: null,
        passportNumber: null,
        placeOfBirth: null,
        phoneNumberDetails: [
          {
            key: 119196,
            areaCode: 91,
            countryCode: 91,
            isDNDActive: null,
            isPreferred: null,
            isVerified: 0,
            number: 91330650746,
            applicantKey: 77906,
            type: 'MOBILE'
          }
        ],
        salutationCode: null,
        employmentDetails: null,
        applicationApplicantId: null,
        dateOfBirth: '1800-01-01',
        emailDetails: null,
        panNumber: null,
        maskAadhaarNumber: null,
        languageCode: null,
        firstName: null,
        applicantKey: 77906,
        aadhaarNumber: null,
        loanApplicationKey: null,
        apltinactivedt: null,
        phoneNumber: null,
        segmentMaster: null,
        apltisactive: null,
        maritalStatusDesc: null,
        apltisempflag: null,
        mobileVerifiedFlag: null,
        middleName: null,
        netSalary: null,
        apltgrossmthincome: null
      },
      sonCount: 0,
      fatherSelected: true,
      insuredDetails: [
        {
          no: 39587,
          firstName: null,
          middleName: null,
          lastName: null,
          birthPlace: null,
          dob: null,
          relationship: 'SELF',
          age: 26,
          genderCode: 'M',
          genderDesc: 'Male',
          maritalStatusCode: null,
          countryCode: null,
          height: null,
          weight: null,
          presentInIndiaFlg: false,
          indianPassportFlg: false,
          passportNum: null,
          passportExpdt: null,
          smokerFlg: false,
          nationalityCode: null,
          bmi: null,
          insuredDeleted: false
        }
      ],
      childCount: 0,
      applicationId: 186868,
      healthPlanDetails: {
        insuredDetails: [
          {
            no: 39583,
            firstName: null,
            middleName: null,
            lastName: null,
            birthPlace: null,
            dob: null,
            relationship: 'SPOUSE',
            age: 30,
            genderCode: null,
            genderDesc: null,
            maritalStatusCode: null,
            countryCode: null,
            height: null,
            weight: null,
            presentInIndiaFlg: false,
            indianPassportFlg: false,
            passportNum: null,
            passportExpdt: null,
            smokerFlg: false,
            nationalityCode: null,
            bmi: null,
            insuredDeleted: false
          },
          {
            no: 39584,
            firstName: null,
            middleName: null,
            lastName: null,
            birthPlace: null,
            dob: null,
            relationship: 'FATHER',
            age: 35,
            genderCode: null,
            genderDesc: null,
            maritalStatusCode: null,
            countryCode: null,
            height: null,
            weight: null,
            presentInIndiaFlg: false,
            indianPassportFlg: false,
            passportNum: null,
            passportExpdt: null,
            smokerFlg: false,
            nationalityCode: null,
            bmi: null,
            insuredDeleted: false
          },
          {
            no: 39582,
            firstName: null,
            middleName: null,
            lastName: null,
            birthPlace: null,
            dob: null,
            relationship: 'SELF',
            age: 26,
            genderCode: 'M',
            genderDesc: 'Male',
            maritalStatusCode: null,
            countryCode: null,
            height: null,
            weight: null,
            presentInIndiaFlg: false,
            indianPassportFlg: false,
            passportNum: null,
            passportExpdt: null,
            smokerFlg: false,
            nationalityCode: null,
            bmi: null,
            insuredDeleted: false
          }
        ],
        selectedPlanDetails: {
          agreegatedDed: 500000,
          policyTerm: 1,
          insuringFor: 3,
          riders: [
            {
              sumAssured: 1000000,
              selected: 'Y',
              netPremium: 712,
              gst: 128.16,
              grossPremium: 840,
              code: 'FAMB'
            }
          ],
          gst: 932.76,
          netPremium: 5182,
          sumAssured: 1500000,
          totalGST: 1060.92,
          insuringForDesc: 'Family',
          grossPremium: 6115,
          totalNetPremium: 5894,
          totalGrossPremium: 6955,
          selected: 'Y'
        },
        insuredCount: 3
      },
      spouseSelected: true,
      daughterCount: 0,
      selfSelected: true
    },
    userInput: null,
    status: 'SUCCESS',
    errorBean: null,
    nextTaskKey: 'healthExtraCareProposerDetails',
    progressInfo: {
      payload: [
        {
          name: 'Get Started',
          value: 20,
          active: true
        },
        {
          name: 'Verify Me',
          value: 0,
          active: false
        },
        {
          name: 'Close The Deal',
          value: 0,
          active: false
        }
      ],
      status: 'SUCCESS',
      errorBean: null
    },
    routesInfo: {
      mainRoute: 'applicationStage',
      subRoute: 'proposerPersonalDetails'
    }
  }
});
const mockDataDependant: HttpResponse<any> = new HttpResponse({
  body: {
    payload: {
      newTokens: {
        tokens: [
          {
            token:
              'eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJCYWphakZpblNlcnYiLCJleHAiOjE1NjY4ODkwNzMsImlhdCI6MTU1MTMzNzA3Mywic3ViIjoiYXV0aGVudGljYXRpb24iLCJsb2dpbiI6IjY5ODc0NTEyMDFAMTk5Mi0wNS0wNSIsInVzZXJUeXBlIjoxfQ.3sIKRrEAujwVV_Nvc17a3ILTNMMv_GBG6zmyt5yw0gc',
            guardKey: 'mME8bz0fJyY0',
            type: 'authtoken'
          }
        ]
      },
      motherSelected: false,
      sonCount: 0,
      fatherSelected: false,
      insuredDetails: [
        {
          no: 39883,
          firstName: 'sadad',
          middleName: null,
          lastName: 'asdasd',
          birthPlace: null,
          dob: null,
          relationship: 'SPOUSE',
          age: 26,
          genderCode: 'F',
          genderDesc: 'Female',
          maritalStatusCode: null,
          countryCode: null,
          height: 165,
          weight: 55,
          presentInIndiaFlg: false,
          indianPassportFlg: false,
          passportNum: null,
          passportExpdt: null,
          smokerFlg: false,
          nationalityCode: null,
          bmi: null,
          insuredDeleted: false
        }
      ],
      childCount: 0,
      applicationId: 182535,
      healthPlanDetails: {
        insuredDetails: [
          {
            no: 39882,
            firstName: 'Test',
            middleName: null,
            lastName: 'One',
            birthPlace: null,
            dob: '1992-05-05',
            relationship: 'SELF',
            age: 26,
            genderCode: 'M',
            genderDesc: 'Male',
            maritalStatusCode: null,
            countryCode: null,
            height: 178,
            weight: 75,
            presentInIndiaFlg: false,
            indianPassportFlg: false,
            passportNum: null,
            passportExpdt: null,
            smokerFlg: false,
            nationalityCode: null,
            bmi: null,
            insuredDeleted: false
          },
          {
            no: 39883,
            firstName: 'sadad',
            middleName: null,
            lastName: 'asdasd',
            birthPlace: null,
            dob: null,
            relationship: 'SPOUSE',
            age: 26,
            genderCode: 'F',
            genderDesc: 'Female',
            maritalStatusCode: null,
            countryCode: null,
            height: 165,
            weight: 55,
            presentInIndiaFlg: false,
            indianPassportFlg: false,
            passportNum: null,
            passportExpdt: null,
            smokerFlg: false,
            nationalityCode: null,
            bmi: null,
            insuredDeleted: false
          }
        ],
        selectedPlanDetails: {
          agreegatedDed: 500000,
          policyTerm: 1,
          insuringFor: 3,
          riders: [
            {
              sumAssured: 1000000,
              selected: 'Y',
              netPremium: 615,
              gst: 110.7,
              grossPremium: 726,
              code: 'IAMB'
            }
          ],
          gst: 739.98,
          netPremium: 4111,
          sumAssured: 1500000,
          totalGST: 850.68,
          insuringForDesc: 'Family',
          grossPremium: 4851,
          totalNetPremium: 4726,
          totalGrossPremium: 5577,
          selected: 'Y'
        },
        insuredCount: 2
      },
      spouseSelected: true,
      daughterCount: 0,
      selfSelected: true
    },
    userInput: null,
    status: 'SUCCESS',
    errorBean: null,
    nextTaskKey: 'healthExtraCareSpouseDetails',
    progressInfo: {
      payload: [
        { name: 'Get Started', value: 40, active: true },
        { name: 'Verify Me', value: 0, active: false },
        { name: 'Close The Deal', value: 0, active: false }
      ],
      status: 'SUCCESS',
      errorBean: null
    },
    routesInfo: {
      mainRoute: 'applicationStage',
      subRoute: 'proposerPersonalDetails'
    }
  }
});
const mockMartTaskdata: HttpResponse<any> = new HttpResponse({
  body: {
    payload: null,
    userInput: null,
    status: 'SUCCESS',
    errorBean: null,
    nextTaskKey: 'healthExtraCareFatherDetails',
    progressInfo: null,
    routesInfo: null
  }
});
const outputPayloadSelf: any = {
  isFormValid: true,
  participantDetails: {
    lastName: 'One',
    genederCode: 'M',
    apltWeight: '75',
    subsegmentMaster: null,
    apltcorecusid: null,
    apltcommprefchannel: null,
    apltempid: null,
    apltstatus: null,
    apltHeight: 178,
    apltlstupdatedt: null,
    passportExpDate: null,
    genderDesc: 'Male',
    maritalStatusCode: null,
    nationalityCode: null,
    monthlyObligation: null,
    apltstatuschgdate: null,
    apltlstupdateby: null,
    relationship: null,
    apltcustcif: null,
    passportNumber: null,
    placeOfBirth: null,
    phoneNumberDetails: [
      {
        key: 0,
        areaCode: '91',
        countryCode: '91',
        isDNDActive: '0',
        isPreferred: 1,
        isVerified: 0,
        number: '6987451201',
        applicantKey: 0,
        type: 'MOBILE'
      }
    ],
    salutationCode: null,
    employmentDetails: null,
    applicationApplicantId: null,
    dateOfBirth: '1992-05-05',
    emailDetails: [
      {
        key: 0,
        emailAddress: 'test.one@gmail.com',
        isVerified: 0,
        idPriority: 1,
        type: 'PERSON1',
        applicantKey: 0
      }
    ],
    panNumber: null,
    maskAadhaarNumber: null,
    languageCode: null,
    firstName: 'Test',
    applicantKey: 75421,
    aadhaarNumber: null,
    loanApplicationKey: null,
    apltinactivedt: null,
    phoneNumber: null,
    segmentMaster: null,
    apltisactive: null,
    maritalStatusDesc: null,
    apltisempflag: null,
    mobileVerifiedFlag: null,
    middleName: '',
    netSalary: null,
    apltgrossmthincome: null,
    genderCode: 'M',
    age: 26
  }
};
const outputPayloadSpouse: any = {
  isFormValid: true,
  participantDetails: {
    no: 38991,
    firstName: 'Test',
    middleName: '',
    lastName: 'Test',
    birthPlace: null,
    dob: '1992-05-07',
    relationship: 'SPOUSE',
    age: 26,
    genderCode: 'F',
    genderDesc: 'Female',
    maritalStatusCode: null,
    countryCode: null,
    height: 165,
    weight: 55,
    presentInIndiaFlg: false,
    indianPassportFlg: false,
    passportNum: null,
    passportExpdt: null,
    smokerFlg: false,
    nationalityCode: null,
    bmi: null,
    insuredDeleted: false,
    apltWeight: 55,
    apltHeight: 165
  }
};
const outputPayloadFather: any = {
  isFormValid: true,
  participantDetails: {
    no: 38995,
    firstName: 'asd',
    middleName: '',
    lastName: 'aaaaa',
    birthPlace: null,
    dob: '1968-05-07',
    relationship: 'FATHER',
    age: 50,
    genderCode: 'M',
    genderDesc: 'Male',
    maritalStatusCode: null,
    countryCode: null,
    height: 165,
    weight: '55',
    presentInIndiaFlg: false,
    indianPassportFlg: false,
    passportNum: null,
    passportExpdt: null,
    smokerFlg: false,
    nationalityCode: null,
    bmi: null,
    insuredDeleted: false,
    apltWeight: 55,
    apltHeight: 155
  }
};
const outputPayloadMother: any = {
  isFormValid: true,
  participantDetails: {
    no: 39105,
    firstName: 'asd',
    middleName: '',
    lastName: 'asd',
    birthPlace: null,
    dob: '1968-05-05',
    relationship: 'MOTHER',
    age: 50,
    genderCode: 'F',
    genderDesc: 'Female',
    maritalStatusCode: null,
    countryCode: null,
    height: 165,
    weight: 55,
    presentInIndiaFlg: false,
    indianPassportFlg: false,
    passportNum: null,
    passportExpdt: null,
    smokerFlg: false,
    nationalityCode: null,
    bmi: null,
    insuredDeleted: false,
    apltWeight: 55,
    apltHeight: 165
  }
};
const outputPayloadSon: any = {
  isFormValid: true,
  participantDetails: {
    no: 39106,
    firstName: 'asd',
    middleName: '',
    lastName: 'asd',
    birthPlace: null,
    dob: '2017-05-05',
    relationship: 'SON',
    age: 1,
    genderCode: 'M',
    genderDesc: 'Male',
    maritalStatusCode: null,
    countryCode: null,
    height: 165,
    weight: 55,
    presentInIndiaFlg: false,
    indianPassportFlg: false,
    passportNum: null,
    passportExpdt: null,
    smokerFlg: false,
    nationalityCode: null,
    bmi: null,
    insuredDeleted: false,
    apltWeight: 55,
    apltHeight: 165
  }
};
const outputPayloadDaughter: any = {
  isFormValid: true,
  participantDetails: {
    no: 39107,
    firstName: 'asd',
    middleName: '',
    lastName: 'asd',
    birthPlace: null,
    dob: '2018-01-01',
    relationship: 'DAUGHTER',
    age: 1,
    genderCode: 'F',
    genderDesc: 'Female',
    maritalStatusCode: null,
    countryCode: null,
    height: 165,
    weight: 55,
    presentInIndiaFlg: false,
    indianPassportFlg: false,
    passportNum: null,
    passportExpdt: null,
    smokerFlg: false,
    nationalityCode: null,
    bmi: null,
    insuredDeleted: false,
    apltWeight: 55,
    apltHeight: 165
  }
};
const getClientLoginSecKey: HttpResponse<any> = new HttpResponse({
  body: {
    payload: {
             secretKey:'bflclient321',
              systemTime:1553233998987
            },
    status: 'SUCCESS',
    errorBean: null,
  }
});
const mockAuthToken: any = {
  payload: {
    tokens: [
      {
        token:
          'eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJCYWphakZpblNlcnYiLCJleHAiOjE1Njc1MTMzODUsImlhdCI6MTU1MTk2MTM4NSwic3ViIjoiYXV0aGVudGljYXRpb24iLCJsb2dpbiI6ImJmbGNsaWVudCIsInVzZXJUeXBlIjowfQ.ZjcynJzrJi20bMV_dipcegnuMSzTWc-O4kcQ23uPk3E',
        guardKey: 'jPZp0Z9Z7gsk',
        type: 'authtoken'
      }
    ]
  },
  status: 'SUCCESS',
  errorBean: null
};
class MockActivitiHandlerService {
  public MarkTaskAsCompleted() {
    return of(mockMartTaskdata.body);
  }
  public GetTaskDetails() {
    return of(mockData.body);
  }
}
class MockHomeService {
  public GetSystemAuthToken() {
    return of(mockAuthToken);
  }
  public GetClientIdForUser(): string {
    // return 'IAMTest';
    return 'bflclient';
}
public GetSecretKeyForBasedOnClientId() {
  return of(getClientLoginSecKey.body);
}
}
describe('Personal Details Component', () => {
  // provide our implementations or mocks to the dependency injector
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [
        PersonalDetailsComponent,
        HttpInterceptor,
        Formatter,
        FormBuilder,
        RouteHandlerService,
        FormValidator,
        SharedService,
        AnalyticsService,
        RouteContextProvider,
        CookieHandlerService,
        CookieService,
        HomeComponent,
        HttpClient,
        HttpHandler,
        {
          provide: ActivitiHandlerService,
          useClass: MockActivitiHandlerService
        },
        {
          provide: HomeService,
          useClass: MockHomeService
        }
      ]
    });
  });
  it('Testing ngOnInit', inject(
    [PersonalDetailsComponent],
    (testComponent: PersonalDetailsComponent) => {
      testComponent.ngOnInit();
    }
  ));
  it('Testing Back', inject(
    [PersonalDetailsComponent, HomeService],
    (testComponent: PersonalDetailsComponent) => {
     testComponent.ngOnInit();
      testComponent.Back();
    }
  ));
  it('Testing OnDetailsChanged', inject(
    [PersonalDetailsComponent],
    (testComponent: PersonalDetailsComponent) => {
      debugger;
      testComponent.ngOnInit();
      testComponent.OnDetailsChanged(outputPayloadSelf);
    }
  ));
  it('Testing Next', inject(
    [PersonalDetailsComponent],
    (testComponent: PersonalDetailsComponent) => {
      testComponent.ngOnInit();
      testComponent.OnDetailsChanged(outputPayloadSelf);
      testComponent.Next();
    }
  ));
  it('Testing Next Spouse', inject(
    [PersonalDetailsComponent],
    (testComponent: PersonalDetailsComponent) => {
      mockData = mockDataDependant;
      testComponent.ngOnInit();
      testComponent.OnDetailsChanged(outputPayloadSpouse);
      testComponent.Next();
    }
  ));
  it('Testing Next Father', inject(
    [PersonalDetailsComponent],
    (testComponent: PersonalDetailsComponent) => {
      mockData = mockDataDependant;
      testComponent.ngOnInit();
      testComponent.OnDetailsChanged(outputPayloadFather);
      testComponent.Next();
    }
  ));
  it('Testing Next Mother', inject(
    [PersonalDetailsComponent],
    (testComponent: PersonalDetailsComponent) => {
      mockData = mockDataDependant;
      testComponent.ngOnInit();
      testComponent.OnDetailsChanged(outputPayloadMother);
      testComponent.Next();
    }
  ));
  it('Testing Next SON', inject(
    [PersonalDetailsComponent],
    (testComponent: PersonalDetailsComponent) => {
      mockData = mockDataDependant;
      testComponent.ngOnInit();
      testComponent.OnDetailsChanged(outputPayloadSon);
      testComponent.Next();
    }
  ));
  it('Testing Next Daughter', inject(
    [PersonalDetailsComponent],
    (testComponent: PersonalDetailsComponent) => {
      mockData = mockDataDependant;
      testComponent.ngOnInit();
      testComponent.OnDetailsChanged(outputPayloadDaughter);
      testComponent.Next();
    }
  ));
  it('Testing GetId', inject(
    [PersonalDetailsComponent],
    (testComponent: PersonalDetailsComponent) => {
      testComponent.ngOnInit();
      testComponent.GetId('FATHER', 1);
    }
  ));
});
