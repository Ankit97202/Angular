import { Component, OnInit, Output } from '@angular/core';
import { FormValidator } from '../../common/services/formValidator.service';
import { ActivitiHandlerService } from '../../common/services/activitiHandler.service';
import { CookieHandlerService } from '../../common/services/cookieHandler.service';
import { CommonConstants } from '../../common/utilities/commonConstants';
import { RouteHandlerService } from '../../common/services/routeHandler.service';
import { Formatter } from 'src/app/common/services/formatter';
import { ConfigService } from '../../common/services/config.service';
import { modelGroupProvider } from '@angular/forms/src/directives/ng_model_group';
import { SharedService } from '../../common/services/sharedService';
import { HomeComponent } from '../../home/home.component'
@Component({
  providers: [HomeComponent],
  selector: 'app-personal-details',
  templateUrl: './personalDetails.template.html',
  styleUrls: ['./personalDetails.style.css']
})
export class PersonalDetailsComponent implements OnInit {
  // Public Variables
  public SelectedPlanDetails: Model.SelectedPlanDetails;
  public IsValid = false;
  public IsLaISPh = true;
  public IsLaActive: boolean;
  public ProposerDetails: ActivitiModel.ParticipantDetails;
  public InsuredDetails: Model.InsuredDetails[];
  public SelectedInsuredDetails: Model.InsuredDetails[];
  public showLoader = false;
  public IsPaymentDone: boolean;
  public BREErrorMessage = CommonConstants.DEFAULT_EMPTY_STRING;
  public InsuredCount: number;
  // Private Variables
  private _outputPayload = <Model.PersonalDetailsOutputPayload>{};
  // tslint:disable-next-line:max-line-length
  private _exceptionKeysArr: string[] = [
    'healthExtraCareProposerDetails',
    'healthExtraCareSpouseDetails',
    'healthExtraCareFatherDetails',
    'healthExtraCareMotherDetails',
    'healthExtraCareChild1',
    'healthExtraCareChild2',
    'healthExtraCareChild3',
    'healthExtraCareChild4'
  ];
  private _exceptionKeysObject = {
    SELF: 'healthExtraCareProposerDetails',
    SPOUSE: 'healthExtraCareSpouseDetails',
    FATHER: 'healthExtraCareFatherDetails',
    MOTHER: 'healthExtraCareMotherDetails',
    CHILD: 'healthExtraCareChild'
  };
  private _defaultDob = '1992-01-01';
  public selectedTab = 'SELF';
  public isSelfInsured: boolean;
  public selfAge: number;
  // Constructor
  constructor(
    public FormValidators: FormValidator,
    private _activitiHandler: ActivitiHandlerService,
    private _cookieHandler: CookieHandlerService,
    private _routerService: RouteHandlerService,
    private _formatter: Formatter,
    private _sharedService: SharedService,
    private homeComponent: HomeComponent
  ) { }
  // ON component Init
  public ngOnInit() {
    this.homeComponent.authenticateSystem(false);
    this.getTaskDetails();
  }
  // On Page / Tab Next
  public Next() {
    if (this.selectedTab !== this._exceptionKeysObject.SELF) {
      const insured = this._outputPayload.proposerDetails;
      this.SelectedInsuredDetails[0].firstName = insured.firstName;
      this.SelectedInsuredDetails[0].middleName = insured.middleName;
      this.SelectedInsuredDetails[0].lastName = insured.lastName;
      this.SelectedInsuredDetails[0].age = insured.age;
      this.SelectedInsuredDetails[0].dob = insured.dob;
      this.SelectedInsuredDetails[0]['height'] = insured.apltHeight;
      this.SelectedInsuredDetails[0]['weight'] = insured.apltWeight;
      this.SelectedInsuredDetails[0].genderCode = insured.genderCode;
      this.SelectedInsuredDetails[0].genderDesc = insured.genderDesc;
      delete this._outputPayload.proposerDetails;
      this._outputPayload.insuredDetails = this.SelectedInsuredDetails;
    }
    this.markTaskComplete(this._outputPayload, '');
  }
  // On Page / Tab Back
  public Back() {
    {
      (async () => {
        await this.homeComponent.authenticateSystem(false);
      })();
    }
    this.markTaskComplete(null, 'Back');
  }
  // PH Details Change Event Handler Method
  public OnDetailsChanged(emittedValue: Model.PersonalDetailsEmitterModel) {
    this._outputPayload.proposerDetails = emittedValue.participantDetails;
    this.IsValid = emittedValue.isFormValid;
  }
  public OnActivitiErrorHandler(errObj: any) {
    if (
      this._formatter
        .toSmallCase(errObj[0].errorCode)
        .startsWith('healthExtraCarePluser')
    ) {
      this.BREErrorMessage = errObj[0].errorMessage;
    }
  }
  public GetId(relation, no) {
    if (relation && relation !== 'SELF') {
      if (relation !== 'SON' || relation !== 'DAUGHTER') {
        const id = this._exceptionKeysObject.CHILD;
        let index = 0;
        for (let i = 0; i < this.InsuredDetails.length; i++) {
          const element = this.InsuredDetails[i];
          if (
            element.relationship === 'SON' ||
            element.relationship === 'DAUGHTER'
          ) {
            index++;
            if (i === no) {
              return id + index;
            }
          }
        }
      }
      return this._exceptionKeysObject[relation];
    }
    return '';
  }
  // Removing default date of birth from participant details
  private checkMockDob() {
    const currentDob = this.ProposerDetails.dateOfBirth;
    if (this._defaultDob === currentDob) {
      this.ProposerDetails.dateOfBirth = null;
    }
  }
  private getTaskDetails() {
    this._activitiHandler.GetTaskDetails().subscribe(
      (
        mtResponse: ActivitiModel.MTResponse<Model.PersonalDetailsInputPayload>
      ) => {
        if (!mtResponse.errorBean) {
          const applicationID = this._sharedService.getData(CommonConstants.QueryParamsKeys.ApplicationId);
          this.ProposerDetails = mtResponse.payload.proposerDetails;
          this.SelectedPlanDetails = mtResponse.payload.healthPlanDetails.selectedPlanDetails;
          this.InsuredCount = mtResponse.payload.healthPlanDetails.insuredCount;
          if (mtResponse.payload.insuredDetails && mtResponse.nextTaskKey !== this._exceptionKeysObject.SELF) {
            this.SelectedInsuredDetails = mtResponse.payload.insuredDetails;
          }
          if (mtResponse.payload.healthPlanDetails.insuredDetails) {
            this.InsuredDetails = this.formatter(mtResponse.payload.healthPlanDetails.insuredDetails);
          }
          const self = this.InsuredDetails.filter(_ => _.relationship === 'SELF')[0];
          if (mtResponse.nextTaskKey === this._exceptionKeysObject.SELF) {
            if (self) {
              this.isSelfInsured = true;
              this.selfAge = self.age;
            }
          } else {
            const gender = this.ProposerDetails ? this.ProposerDetails.genederCode : null;
            this.setGender(gender);
          }
          this.selectedTab = mtResponse.nextTaskKey;
          let journeyType = CommonConstants.DEFAULT_EMPTY_STRING;
          if (applicationID) {
            journeyType = this._cookieHandler.GetCookie(CommonConstants.CookieKeys.JourneyType);
          }
          if (mtResponse.nextTaskKey !== this._exceptionKeysObject.SELF) {
            if (journeyType === CommonConstants.DEFAULT_EMPTY_STRING) {
              if (mtResponse.payload.newTokens) {
                this.setUserAuthToken(mtResponse.payload);
              }
            }
          }
        }
      },
      error => {
        console.error('ERROR::', error);
      }
    );
  }
  private setUserAuthToken(responseData: any) {
    if (responseData) {
      this._cookieHandler.SetCookie(
        CommonConstants.CookieKeys.JWToken,
        responseData.newTokens.tokens[0].token
      );
      this._cookieHandler.SetCookie(
        CommonConstants.CookieKeys.GuardKey,
        responseData.newTokens.tokens[0].guardKey
      );
      this._cookieHandler.SetCookie(
        CommonConstants.CookieKeys.GuardToken,
        this._formatter.ConvertGuradKeyToGuardToken(
          responseData.newTokens.tokens[0].guardKey
        )
      );
    }
  }
  // MArk Task Details Call
  private markTaskComplete(
    data: Model.PersonalDetailsOutputPayload,
    taskName: string
  ) {
    this.showLoader = true;
    console.log(data);
    this.BREErrorMessage = CommonConstants.DEFAULT_EMPTY_STRING;
    this._activitiHandler
      .MarkTaskAsCompleted(data, taskName, true)
      .subscribe((mtResponse: ActivitiModel.MTResponse<any>) => {
        this.showLoader = false;
        if (!mtResponse.errorBean) {
          this._routerService.RouteToNextTask(
            mtResponse.nextTaskKey,
            this._exceptionKeysArr,
            key => {
              this.getTaskDetails();
            }
          );
        } else {
          this.BREErrorMessage = CommonConstants.DEFAULT_ERROR_MESSAGE;
        }
      });
  }
  private formatServiceErrorMessage(errorMessage: string): string {
    errorMessage = errorMessage.slice(
      13,
      errorMessage.lastIndexOf(', Message')
    );
    return errorMessage;
  }
  private formatter(array: Model.InsuredDetails[]) {
    let formatedArray = [];
    Object.keys(this._exceptionKeysObject).forEach(ele => {
      if (ele !== 'CHILD') {
        const element = array.filter(_ => _.relationship === ele);
        if (element.length) {
          formatedArray = formatedArray.concat(element);
        }
      }
    });
    const elementChild = array.filter(_ => _.relationship === 'SON' || _.relationship === 'DAUGHTER');
    if (elementChild.length) {
      formatedArray = formatedArray.concat(elementChild);
    }
    return formatedArray;
  }
  private setGender(proposerGender) {
    if (!this.SelectedInsuredDetails[0].genderCode) {
      if (proposerGender && proposerGender === 'M' && this.SelectedInsuredDetails[0].relationship === 'SPOUSE') {
        this.SelectedInsuredDetails[0].genderCode = 'F';
        this.SelectedInsuredDetails[0].genderDesc = 'Female';
      } else if (proposerGender && proposerGender === 'F' && this.SelectedInsuredDetails[0].relationship === 'SPOUSE') {
        this.SelectedInsuredDetails[0].genderCode = 'M';
        this.SelectedInsuredDetails[0].genderDesc = 'Male';
      }
      if (this.SelectedInsuredDetails[0].relationship === 'FATHER' || this.SelectedInsuredDetails[0].relationship === 'SON') {
        this.SelectedInsuredDetails[0].genderCode = 'M';
        this.SelectedInsuredDetails[0].genderDesc = 'Male';
      }
      if (this.SelectedInsuredDetails[0].relationship === 'MOTHER' || this.SelectedInsuredDetails[0].relationship === 'DAUGHTER') {
        this.SelectedInsuredDetails[0].genderCode = 'F';
        this.SelectedInsuredDetails[0].genderDesc = 'Female';
      }
    }
  }
}
