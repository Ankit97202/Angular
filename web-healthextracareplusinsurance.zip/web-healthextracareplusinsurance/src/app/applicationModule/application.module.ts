import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';
import * as ModuleComponent from './index';
import { ConfigResolve } from './../common/services/config.resolve.service';
import { CommonConstants } from './../common/utilities/commonConstants';
import { SharedModule } from './../common/utilities/shared/shared.module';
import { RatingModule } from 'ngx-bootstrap';
@NgModule({
  declarations: [
    ModuleComponent.NomineeDetailsComponent,
    ModuleComponent.AddressDetailsComponent,
    ModuleComponent.ReviewApplicationComponent,
    ModuleComponent.PersonalDetailsComponent,
    ModuleComponent.PersonalDetailsFormComponent,
    ModuleComponent.MedicalDeclarationComponent,
    ModuleComponent.AddressNomineeDetailsComponent,
    ModuleComponent.AddressDetailsFormComponent,
    ModuleComponent.NomineeDetailsFormComponent
  ],
  imports: [
    // import Angular's modules
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    SharedModule,
    RatingModule.forRoot(),
    RouterModule.forChild([
      {
        path: CommonConstants.Routes.Application.ProposerPersonalDetails,
        component: ModuleComponent.PersonalDetailsComponent,
        resolve: { config: ConfigResolve }
      },
      {
        path: CommonConstants.Routes.Application.AddressDetails,
        component: ModuleComponent.AddressNomineeDetailsComponent,
        resolve: { config: ConfigResolve }
      },
      {
        path: CommonConstants.Routes.Application.ReviewApplication,
        component: ModuleComponent.ReviewApplicationComponent,
        resolve: { config: ConfigResolve }
      },
      {
        path: CommonConstants.Routes.Application.MedicalDeclaration,
        component: ModuleComponent.MedicalDeclarationComponent,
        resolve: { config: ConfigResolve }
      }
    ])
  ],
  providers: [
    // expose our Services and Providers into Angular's dependency injection
  ]
})
export class ApplicationModule {}
