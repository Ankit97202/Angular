declare module Model {
    export interface ReviewApplicationInputPayload {
        healthExtraCarePlusPlanDetailsResponse : Model.PlanDetailsResponse;
        healthExtraCarePlusAddressRequest : Model.healthExtraCarePlusAddressRequest;
        phAgeChanged?: boolean;
        laAgeChanged?: boolean;
    }
    export interface ReviewApplicationOutputPayload {
        disclaimerFlag?: boolean;
        tncAcceptedFlag?: boolean;
        applicationId?: string;
        phAgeChanged?: boolean;
        laAgeChanged?: boolean;
    }
    export interface BiDetails{
        policyDocumentUrl: string;
    }
    export interface PlanDetailsResponse {
        selectedPlanDetails: ActivitiModel.PlanDetails;
    }
    export interface healthExtraCarePlusAddressRequest{
        lifeAssured : Model.ParticipantAddressDetails;
        proposer : Model.ParticipantAddressDetails;
    }
    export interface ParticipantAddressDetails{
        age? : string;
        gender? : string;
        address : Model.AddressDetails[];
    }
    export interface AddressDetails {
        addressLine1: string;
        addressLine2: string;
        areaLocalityName: string;
        city: string;
        cityCode: string;
        flatNumber: string;
        houseNumber: string;
        pinCode: string;
        state: string;
        stateCode: string;
        street: string;
        type: string;
    }
}
