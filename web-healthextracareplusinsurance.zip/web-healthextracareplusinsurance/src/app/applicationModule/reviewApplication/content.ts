export class AppSummaryContent {
    // tslint:disable-next-line:max-line-length
    public static Terms_Conditions_Content = [' I/We hereby declare, on my behalf and on behalf of all persons proposed to be insured, that the above statements, answers and/or particulars given by me are true and complete in all respects to the best of my knowledge and that I/We am/are authorized to propose on behalf of these other persons.',
        // tslint:disable-next-line:max-line-length
        ' I understand that the information provided by me will form the basis of the insurance policy, is subject to the Board approved underwriting policy of the insurance company and that the policy will come into force only after fill receipt of the premium chargeable.',
        // tslint:disable-next-line:max-line-length
        ' I/We further declare that l/we will notify in writing any change occurring in the occupation or general health of the life to be insured/proposer after the proposal has been submitted but before communication of the risk acceptance by the company.',
        // tslint:disable-next-line:max-line-length
        ' I/We declare and consent to the company seeking medical information from any doctor or from a hospital who at anytime has attended on the life to be insured/proposer or from any past or present employer concerning anything which affects the physical or mental health of the life to be assured/proposer and seeking information from any insurance company to which an application for insurance on the life to be assured/proposer has been made for the purpose of underwriting the proposal and/or claim settlement.',
        // tslint:disable-next-line:max-line-length
        ' I/We authorize the company to share information pertaining to my proposal including the medical records for the sole purpose of proposal underwriting and/or claims settlement and with any Governmental and/or Regulatory authority.',
        // tslint:disable-next-line:max-line-length
        ' I/we hereby unconditionally allow the Company to share all my / our information being collected in this proposal form or through telephone / email / web-inputs means or other means, as updated from time to time within group entities.'
    ];
}
