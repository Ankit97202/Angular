import { Component, OnInit, ViewChildren, QueryList, OnChanges, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivitiHandlerService } from '../../common/services/activitiHandler.service';
import { CookieHandlerService } from '../../common/services/cookieHandler.service';
import { CommonConstants } from '../../common/utilities/commonConstants';
import { RouteHandlerService } from '../../common/services/routeHandler.service';
import { Formatter } from '../../common/services/formatter';
import { AppSummaryContent } from './content';
import { PopupComponent } from './../../common/utilities/popup/popup.component';
import { SharedService } from './../../common/services/sharedService';
import { addSpaceToDigit } from './../../common/utilities/pipes/SpacePipe.pipe';
const Content_Types = {
  TnC: 'Terms & Conditions',
  disclaimer: 'Disclaimer'
};
@Component({
  templateUrl: './reviewApplication.template.html',
  styleUrls: ['./reviewApplication.style.css']
})
export class ReviewApplicationComponent implements OnInit {
  @ViewChildren(PopupComponent) public PopupComponent: QueryList<any>;
  public TermsFormGroup: FormGroup;
  public IsValid: boolean;
  customClass = 'customClass';
  public isFirstOpen = true;
  public IsLaISPh = true;
  public conditions: boolean;
  public ContentPopup;
  public Config = { show: false, backdrop: 'static' };
  public CurrentContent: Array<string>;
  public IsLaActive: boolean;
  public genderDesPh: string;
  public genderDesLa: string;
  public NoOfRiders: number;
  public ReviewApplicationBiUrl: string;
  public areYouNRIPh: string;
  public areYouNRILa: string;
  public formattedPHDOB: string;
  public formattedLADOB: string;
  public ParticipantPhOccupation: string;
  public ParticipantLaOccupation: string;
  public PlanSummaryObject: ActivitiModel.PlanDetails;
  public PhAddressDetails: Model.AddressDetails[];
  public LaAddressDetails: Model.AddressDetails[];
  public showLoader = false;
  public SelectedPlanDetails: Model.SelectedPlanDetails;
  public ProposerDetails: Model.InsuredDetails;
  public InsuredDetails: Model.InsuredDetails[];
  public NomineeDetails: Model.NomineeDetails;
  public InsuredForDesc: string;
  public ShowHelpText = false;
  public ErrorMessage: string = null;
  // Private Variables
  private _inputPayload: Model.ReviewApplicationInputPayload;
  private _outputPayload = <Model.ReviewApplicationOutputPayload>{};
  constructor(
    private _formBuilder: FormBuilder,
    private _activitiHandler: ActivitiHandlerService,
    private _cookieHandler: CookieHandlerService,
    private _sharedService: SharedService,
    public formatter: Formatter,
    private _routerService: RouteHandlerService
  ) {}
  public ngOnInit() {
    this.buildTermsFormGroup();
    this.getDetails();
    this.initContentPopup();
  }
  public ModifyDetails(taskKey: string) {
    this.ErrorMessage = null;
    this._activitiHandler
      .MarkTaskAsCompleted(null, taskKey)
      .subscribe((mtResponse: ActivitiModel.MTResponse<any>) => {
        if (!mtResponse.errorBean) {
          this._routerService.RouteToNextTask(mtResponse.nextTaskKey);
        } else {
          this.ErrorMessage = CommonConstants.DEFAULT_ERROR_MESSAGE;
        }
      });
  }
  /*Initialize Popup*/
  private initContentPopup() {
    this.ContentPopup = {
      Id: 'content-modal',
      Title: '',
      Config: <CustomModalOptions>{ show: false, closeOption: true }
    };
    console.log(
      'this.config.closeOption:',
      this.ContentPopup.Config.closeOption
    );
  }
  /* Getting Popup Instances Based on Id */
  private getModalDirectiveInstanceBasedOnId(popupId: string): any {
    return this.PopupComponent.filter((item: PopupComponent, index: number) => {
      return item.id === popupId;
    })[0].modalControl;
  }
  // Show Modal Popup
  public ShowChildModal(id: string, contentType?: string): void {
    if (contentType) {
      this.initContentPopup();
      this.ContentPopup.Title = Content_Types[contentType];
      this.CurrentContent = AppSummaryContent.Terms_Conditions_Content;
    }
    this.getModalDirectiveInstanceBasedOnId(id).show();
  }
  // Hide Modal Popup
  public HideChildModal(id: string): void {
    this.TermsFormGroup.controls['conditions'].setValue(true);
    this.getModalDirectiveInstanceBasedOnId(id).hide();
  }
  // Next Button Click
  public Next(formValue: FormData) {
    let payload = {
      tncAcceptedFlag: formValue['conditions'],
      goGreenFlag: formValue["goGreen"],
    };
    this.markTaskComplete(payload, "");
  }
  // Back Button Click
  public Back() {
    this.markTaskComplete(null, 'Back');
  }
   // Set Terms & Conditions Form Controls Value
   public AgreeTerms(controlName: string, formValue: FormData) {
    if (formValue[controlName] === false) {
      this.TermsFormGroup.controls[controlName].setValue("");
    }
  }
  public space(input)
    {
        if(input !==null)
        addSpaceToDigit(input);
    }
  // Setting TnC Data To the Form Group
  private setUserInput(userInput: Model.ReviewApplicationOutputPayload) {
    this.TermsFormGroup.setValue({
      goGreen: userInput["goGreenFlag"] || null,
      conditions: userInput["tncAcceptedFlag"] || null
    });
  }
  // Get the details of page when page loads
  private getDetails() {
    this.showLoader = true;
    this._activitiHandler.GetTaskDetails().subscribe((resp: ActivitiModel.MTResponse<any>) => {
        if (!resp.errorBean) {
                this.showLoader = false;
               this.InsuredForDesc = resp.payload.healthPlanDetailsResponse.insuringForDesc;
               this.ProposerDetails = resp.payload.healthPlanDetailsResponse.proposerDetails;
               this.InsuredDetails = resp.payload.healthPlanDetailsResponse.insuredDetails;
               this.SelectedPlanDetails = resp.payload.healthPlanDetailsResponse.selectedPlanDetails;
               this.NomineeDetails = resp.payload.nomineeDetails;
            if (resp.userInput) {
                this.setUserInput(resp.userInput);
            }
        }
    });
}
// Build Terms & Conditions form Group
  private buildTermsFormGroup() {
    this.TermsFormGroup = this._formBuilder.group({
      conditions: ['', Validators.compose([Validators.required])],
      goGreen:['true', Validators.compose([Validators.required])]
    });
  }
  // Mark Task As Completed Activiti Call
  private markTaskComplete(
    data: Model.ReviewApplicationOutputPayload,
    taskName: string
  ) {
    this.showLoader = true;
    this.ErrorMessage = null;
    this._activitiHandler
      .MarkTaskAsCompleted(data, taskName)
      .subscribe((mtResponse: ActivitiModel.MTResponse<any>) => {
        this.showLoader = false;
        if (!mtResponse.errorBean) {
          this._routerService.RouteToNextTask(mtResponse.nextTaskKey);
        } else {
          this.ErrorMessage = CommonConstants.DEFAULT_ERROR_MESSAGE;
        }
      });
  }
}
