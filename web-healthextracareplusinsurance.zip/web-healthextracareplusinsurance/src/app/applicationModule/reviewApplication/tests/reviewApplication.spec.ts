import { FormBuilder } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TestBed, inject } from '@angular/core/testing';
import { of, Observable } from 'rxjs';
import { HttpResponse, HttpClient, HttpHandler } from '@angular/common/http';
import { Formatter } from 'src/app/common/services/formatter';
import { SharedService } from 'src/app/common/services/sharedService';
import { AnalyticsService } from 'src/app/common/services/device.analytics.service';
import { CookieHandlerService } from 'src/app/common/services/cookieHandler.service';
import { RouteContextProvider } from 'src/app/common/services/routeContextProvider.service';
import { HttpInterceptor } from 'src/app/common/services/httpInterceptor.service';
import { CookieService } from 'ngx-cookie-service';
import { debug } from 'util';
import { RouteHandlerService } from 'src/app/common/services/routeHandler.service';
import { FormValidator } from 'src/app/common/services/formValidator.service';
import { ActivitiHandlerService } from 'src/app/common/services/activitiHandler.service';
import { ConfigService } from 'src/app/common/services/config.service';
import { ReviewApplicationComponent } from '../..';
const mockMartTaskdata: HttpResponse<any> = new HttpResponse({
    body: {
        "payload":null,
        "userInput":null,
        "status":"SUCCESS",
        "errorBean":null,
        "nextTaskKey":"healthExtraCareProductSummary",
        "progressInfo":null,
        "routesInfo":null
     }
  });
const mockData: HttpResponse<any> = new HttpResponse({
    body: {
        payload: {
            healthPlanDetailsResponse: {
              insuringFor: 3,
              insuringForDesc: 'Family',
              insuredDetails: [
                {
                  no: 6822,
                  firstName: 'Name',
                  middleName: null,
                  lastName: 'Surname',
                  birthPlace: null,
                  dob: '1989-11-01',
                  relationship: 'SELF',
                  age: 29,
                  genderCode: 'M',
                  genderDesc: 'Male',
                  maritalStatusCode: null,
                  countryCode: null,
                  height: 190,
                  weight: 80,
                  presentInIndiaFlg: false,
                  indianPassportFlg: false,
                  passportNum: null,
                  passportExpdt: null,
                  smokerFlg: false,
                  nationalityCode: null,
                  bmi: null,
                  insuredDeleted: false
                },
                {
                  no: 6823,
                  firstName: 'Spouse',
                  middleName: null,
                  lastName: 'Surname',
                  birthPlace: null,
                  dob: '1993-10-27',
                  relationship: 'SPOUSE',
                  age: 25,
                  genderCode: 'F',
                  genderDesc: 'Female',
                  maritalStatusCode: null,
                  countryCode: null,
                  height: 160,
                  weight: 69,
                  presentInIndiaFlg: false,
                  indianPassportFlg: false,
                  passportNum: null,
                  passportExpdt: null,
                  smokerFlg: false,
                  nationalityCode: null,
                  bmi: null,
                  insuredDeleted: false
                }
              ],
              selectedPlanDetails: {
                sumAssured: 200000,
                planCode: 'HGFF',
                variantCode: 'HGFF2',
                netPremium: 4694,
                gst: 845,
                grossPremium: 5539,
                zone: 'ZONEB',
                policyTerm: 1,
                displayName: 'Health Guard Family Floater - Silver Plan'
              },
              proposerDetails: {
                age: null,
                dob: '1989-11-01',
                firstName: 'Name',
                lastName: 'Surname',
                middleName: null,
                gender: 'M',
                genderDesc: 'Male',
                mobileNumber: '7344123114',
                maritalStatusdesc: 'MARRIED',
                email: 'emailid@gmail.com',
                passportNumber: null,
                aadhaarCardNumber: null,
                pan: null,
                occupationtype: 1,
                occupationDesc: 'Salaried',
                income: 100000,
                mailingAddress: {
                  flatNumber: null,
                  houseNumber: null,
                  street: null,
                  type: null,
                  addressLine1: 'Wakad',
                  addressLine2: null,
                  city: 'PUNE',
                  cityCode: '1948',
                  state: 'MAHARASHTRA',
                  stateCode: 'MH',
                  pinCode: '411057',
                  areaLocalityName: null
                },
                permanentAddress: null,
                pinCode: '411057'
              },
              proposedSumAssuredList: [150000, 200000]
            },
            nomineeDetails: {
              firstName: 'Nominee',
              middleName: null,
              lastName: 'Surname',
              relationship: 'SON',
              dateOfBirth: null
            }
          },
          userInput: null,
          status: 'SUCCESS',
          errorBean: null,
          nextTaskKey: 'healthExtraCareProductSummary',
          progressInfo: {
            payload: [
              {
                name: 'Explore Right Plan',
                value: 100,
                active: false
              },
              {
                name: 'Application Stage',
                value: 100,
                active: false
              },
              {
                name: 'Final Check',
                value: 25,
                active: true
              },
              {
                name: 'Close The Deal',
                value: 0,
                active: false
              }
            ],
            status: 'SUCCESS',
            errorBean: null
          },
          routesInfo: {
            mainRoute: 'appSummary',
            subRoute: ''
          }
    }
});
class MockActivitiHandlerService {
    public MarkTaskAsCompleted() {
      return of(mockMartTaskdata.body);
    }
    public GetTaskDetails() {
      return of(mockData.body);
    }
  }
describe('ReviewApplicationComponent Component', () => {
    // provide our implementations or mocks to the dependency injector
    beforeEach(() => {
      TestBed.configureTestingModule({
        imports: [RouterTestingModule],
        providers: [
          HttpInterceptor,
          ReviewApplicationComponent,
          Formatter,
          FormBuilder,
          RouteHandlerService,
          FormValidator,
          SharedService,
          AnalyticsService,
          RouteContextProvider,
          CookieHandlerService,
          CookieService,
          HttpClient,
          HttpHandler,
          {
            provide: ActivitiHandlerService,
            useClass: MockActivitiHandlerService
          }
        ]
      });
    });
    const data: any = {
        changedValue: false
      };
    const FormData: any = {conditions: true, goGreen: "true"};
    const controlName: any = "goGreen";
    it('Testing ngOnInit', inject(
      [ReviewApplicationComponent],
      (testComponent: ReviewApplicationComponent) => {
        testComponent.ngOnInit();
      }
    ));
    it('Testing Next', inject(
        [ReviewApplicationComponent],
        (testComponent: ReviewApplicationComponent) => {
          testComponent.ngOnInit();
          testComponent.Next(FormData);
        }
      ));
      it('Testing Back', inject(
        [ReviewApplicationComponent],
        (testComponent: ReviewApplicationComponent) => {
          testComponent.ngOnInit();
          testComponent.Back();
        }
      ));
    it('Testing ModifyDetails', inject(
      [ReviewApplicationComponent],
      (testComponent: ReviewApplicationComponent) => {
        testComponent.ngOnInit();
        const taskKey = "editNominee";
        testComponent.ModifyDetails(taskKey);
      }
    ));
    it('Testing AgreeTerms', inject(
      [ReviewApplicationComponent],
      (testComponent: ReviewApplicationComponent) => {
        testComponent.ngOnInit();
        testComponent.AgreeTerms(controlName, FormData);
      }
    ));
  });
