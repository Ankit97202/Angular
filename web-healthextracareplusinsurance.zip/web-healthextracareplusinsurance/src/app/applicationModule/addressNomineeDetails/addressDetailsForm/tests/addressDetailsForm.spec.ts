import { AddressDetailsFormComponent } from '../../..';
import { FormBuilder, FormGroup } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TestBed, inject } from '@angular/core/testing';
import { of, Observable } from 'rxjs';
import { FormValidator } from '../../../../common/services/formValidator.service';
import { RouteHandlerService } from '../../../../common/services/routeHandler.service';
import { HttpResponse, HttpClient, HttpHandler } from '@angular/common/http';
import { Formatter } from 'src/app/common/services/formatter';
import { SharedService } from 'src/app/common/services/sharedService';
import { AnalyticsService } from 'src/app/common/services/device.analytics.service';
import { CookieHandlerService } from 'src/app/common/services/cookieHandler.service';
import { RouteContextProvider } from 'src/app/common/services/routeContextProvider.service';
import { HttpInterceptor } from 'src/app/common/services/httpInterceptor.service';
import { CookieService } from 'ngx-cookie-service';
import { debug } from 'util';
import { PincodeHandlerService } from 'src/app/common/services/pincodeHandler.service';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
const Address = {
  key: 10181430,
  applicantKey: 80501,
  flatNumber: null,
  houseNumber: null,
  street: null,
  type: 'CURRENT',
  line1: 'asd',
  line2: 'asdasd',
  cityId: 1784,
  city: 'PUNE',
  cityCode: '1948',
  stateId: 257,
  state: 'MAHARASHTRA',
  stateCode: 'MH',
  countryId: 91,
  country: 'INDIA',
  countryCode: 'IN',
  pinId: 116219,
  pinCode: '411006',
  locality: 'YERWADA S.O',
  localityKey: null,
  areaLocalityName: null,
  addSource: null,
  appSource: null,
  occupancyType: null,
  occupancyName: null,
  pinOglFlag: null,
  pinNegativeAreaFlag: null,
  addressDeSelectedFlag: false
};
const PinCode = {
  payload: {
    city: 'PUNE',
    cityId: 1784,
    state: 'MAHARASHTRA',
    stateId: 257,
    stateShortName: 'MH',
    pinCode: '411007',
    pinId: 113597,
    country: 'INDIA',
    countryId: 91,
    latitude: null,
    longitude: null,
    formattedAddress: 'PUNE, MAHARASHTRA 411007, INDIA',
    pinNegativeAreaFlg: 0,
    pinOglFlg: 0
  },
  status: 'SUCCESS',
  errorBean: null
};
class MockActivitiHandlerService {
  public OnPinCodeChanged() {
    return of(PinCode);
  }
}
describe('Address Details Component', () => {
  // provide our implementations or mocks to the dependency injector
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [
        AddressDetailsFormComponent,
        HttpInterceptor,
        FormBuilder,
        FormValidator,
        SharedService,
        RouteContextProvider,
        CookieHandlerService,
        CookieService,
        HttpInterceptor,
        HttpClient,
        HttpHandler,
        {
          provide: PincodeHandlerService,
          useClass: MockActivitiHandlerService
        }
      ]
    });
  });
  it('Testing ngOnInit for Address', inject(
    [AddressDetailsFormComponent],
    (testComponent: AddressDetailsFormComponent) => {
      testComponent.addressDetailsObj = Address;
      testComponent.ngOnChanges();
    }
  ));
  it('Testing OnPincodeChange', inject(
    [AddressDetailsFormComponent],
    (testComponent: AddressDetailsFormComponent) => {
      const pincode: any = {};
      pincode.target = {};
      pincode.target.value = 411007;
      testComponent.addressDetailsObj = Address;
      testComponent.ngOnChanges();
      testComponent.OnPincodeChange(pincode, testComponent.CurrentAddressDetails);
    }
  ));
});
