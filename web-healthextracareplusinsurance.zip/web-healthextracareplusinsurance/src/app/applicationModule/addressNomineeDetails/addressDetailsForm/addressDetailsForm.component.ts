import { Component, OnInit, Output, ViewChild, EventEmitter, Input, OnChanges } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { FormValidator } from '../../../common/services/formValidator.service';
import { ActivitiHandlerService } from '../../../common/services/activitiHandler.service';
import { RouteHandlerService } from '../../../common/services/routeHandler.service';
import { PincodeHandlerService } from '../../../common/services/pincodeHandler.service';
import { CookieHandlerService } from '../../../common/services/cookieHandler.service';
import { CommonConstants } from '../../../common/utilities/commonConstants';
import { SharedService } from '../../../common/services/sharedService';
import { Formatter } from 'src/app/common/services/formatter';
@Component({
  selector: 'app-address-details-form',
  templateUrl: './addressDetailsForm.template.html',
  styleUrls: ['./addressDetailsForm.style.css']
})
export class AddressDetailsFormComponent implements OnChanges {
  public showLoader = false;
  public CurrentAddressDetails: FormGroup;
  public DisableArea: boolean;
  private _outputPayload = <Model.AddressDetailsOutputPayload> {};
  private addressDetails = <Model.addressModel>{};
  private _addressFields = ['locality', 'street', 'pincode', 'state'];
  @Input() public addressDetailsObj: any;
  @Output() public addressDetailsChanged: EventEmitter<
    Model.addressDetailsEmitterModel
    > = new EventEmitter();
  constructor(
    public FormValidators: FormValidator,
    private _formBuilder: FormBuilder,
    private _pincodeService: PincodeHandlerService,
  ) { }
  ngOnChanges() {
    this.buildForm();
    this.setUserInput(this.addressDetailsObj);
  }
  // Pin code change function.
  public OnPincodeChange($event, formGroup: FormGroup) {
    this.DisableArea = true;
    formGroup.controls['state'].setValue('');
    this._pincodeService.OnPinCodeChanged($event, () => {
      if (this._pincodeService.GeoLocationDetails) {
        formGroup.controls['pincode']
          .setValue(this._pincodeService.GeoLocationDetails.pinCode);
        formGroup.controls['state'].setValue(
          this._pincodeService.GeoLocationDetails.city.concat(
            ', ', this._pincodeService.GeoLocationDetails.stateShortName)
        );
        this.DisableArea = false;
      } else {
        formGroup.controls['pincode'].setValue('');
        formGroup.controls['state'].setValue('');
      }
    });
  }
  private buildForm() {
    const fields = {
      locality: ['', [Validators.required]],
      street: ['', [Validators.required]],
      pincode: ['', [Validators.required]],
      state: ['']
    };
    this.CurrentAddressDetails = this._formBuilder.group(fields);
    this.CurrentAddressDetails.valueChanges.subscribe(() => {
      this.preparePayload();
    });
  }
  public onInputEntry($event, nextInput) {
    const input = $event.target;
    const length = input.value.length;
    const maxLength = input.attributes.maxlength.value;
    if (length >= maxLength) {
      document.getElementById(nextInput).focus();
    }
  }
  private preparePayload() {
    const formValue = this.CurrentAddressDetails.value;
    const addr = this._pincodeService.GeoLocationDetails;
    const permanentAddr = false;
    const addressDetails: Model.addressModel = {applAddress: []};
    const applAddress = <Model.ApplAddress> {};
    applAddress['line1'] = formValue['locality'];
    applAddress['line2'] = formValue['street'];
    if (addr) {
      applAddress['pinCode'] = addr.pinCode;
      applAddress['pinId'] = addr.pinId;
      applAddress['city'] = addr.city;
      applAddress['cityId'] = addr.cityId;
      applAddress['state'] = addr.state;
      applAddress['stateId'] = addr.stateId;
      applAddress['countryId'] = addr.countryId;
      applAddress['country'] = addr.country;
      applAddress['type'] = 'CURRENT';
      applAddress['locality'] = null;
      applAddress['localityKey'] = null;
      applAddress['addSource'] = null;
      applAddress['appSource'] = null;
    }
    this.addressDetails.applAddress = [applAddress];
    this._outputPayload.address =  this.addressDetails;
    this._outputPayload.permanentAddr = false;
    const isFormValid = this.CurrentAddressDetails.valid;
    const emmittedObj: Model.addressDetailsEmitterModel = {
      isFormValid: isFormValid,
      address: this._outputPayload
    };
    this.addressDetailsChanged.emit(emmittedObj);
  }
  private setUserInput(addrDetails) {
    if (addrDetails !== null) {
     this.CurrentAddressDetails.setValue({
      locality: addrDetails.line1,
      street: addrDetails.line2,
      pincode: addrDetails.pinCode,
      state: '',
    });
    this.OnPincodeChange({ target: { value: addrDetails.pinCode } }, this.CurrentAddressDetails);
   }
  }
}
