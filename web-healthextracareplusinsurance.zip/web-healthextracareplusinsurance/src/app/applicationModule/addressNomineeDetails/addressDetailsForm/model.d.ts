declare module Model {
    export interface AddressDetailsInputPayload{
        proposerDetails: Model.ProposerDetailsModel;
        healthPlanDetails: Model.HealthPlanDetails;
    }
    export interface AddressDetailsOutputPayload{
        // healthPlanDetails: Model.HealthPlanDetails;
        address: Model.addressModel;
        permanentAddr: boolean;
    }
    export interface addressDetailsEmitterModel{
        address: Model.AddressDetailsOutputPayload;
        isFormValid: boolean;
    }
    export interface addressModel{
        applAddress: Model.ApplAddress[];
    }
    export interface ApplAddress{
        line1 : string;
        line2 : string;
        type : string;
        city : string;
        cityId : number;
        state : string;
        stateId : number;
        countryId : number;
        pinCode : string;
        pinId : number;
        locality : string;
        localityKey : number;
        country : string;
        addSource : string;
        appSource : string;
    }
    export interface ProposerDetailsModel{
        firstName: string;
        middleName:string;
        lastName: string;
        genederCode: string;
        subsegmentMaster: string;
        apltcorecusid: string;
        apltcommprefchannel:string;
        addressDetails: ActivitiModel.AddressDetailsModel[];
        apltempid: string;
        apltstatus: string;
        apltlstupdatedt: string;
        passportExpDate: string;
        genderDesc: string;
        maritalStatusCode: string;
        nationalityCode: string;
        monthlyObligation: string;
        apltstatuschgdate: string;
        apltlstupdateby: string;
        relationship: string;
        apltcustcif: string;
        passportNumber: string;
        phoneNumberDetails: ActivitiModel.PhoneNumberDetails[];
        salutationCode: string;
        employmentDetails: string;
        applicationApplicantId: string;
        dateOfBirth: string;
        emailDetails: ActivitiModel.EmailDetails[];
        panNumber: string;
        maskAadhaarNumber: string;
        applicantProducts: Model.ApplicantProducts[];
        languageCode: string;
        applicantKey: number;
        aadhaarNumber: string;
        loanApplicationKey: string;
        apltinactivedt: string;
        phoneNumber: string;
        apltisactive: string;
        segmentMaster: string;
        maritalStatusDesc: string;
        apltisempflag: string;
        mobileVerifiedFlag: string;
        apltgrossmthincome: string;
        netSalary: string;
    }
    export interface ApplicantProducts{
         applicationId : number;
         applicantId : number;
         prodMasKey : number;
         prodMasCode : string;
         prodMasDesc : string;
    }
    export interface ProposerHealthDetails{
        age: string;
        dob: string;
        firstName: string;
        lastName: string;
        middleName: string;
        gender: string;
        genderDesc: string;
        mobileNumber: string;
        maritalStatusdesc: string;
        email: string;
        passportNumber: string;
        aadhaarCardNumber: string;
        pan: string;
        occupationtype: string;
        occupationDesc: string;
        income: string;
        mailingAddress: string;
        pinCode: string;
        permanentAddress: string;
    }
}
