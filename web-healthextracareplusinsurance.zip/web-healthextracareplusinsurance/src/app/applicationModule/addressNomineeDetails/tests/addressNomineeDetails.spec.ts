import { AddressNomineeDetailsComponent } from '../..';
import { FormBuilder } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TestBed, inject } from '@angular/core/testing';
import { of, Observable } from 'rxjs';
import { FormValidator } from '../../../common/services/formValidator.service';
import { RouteHandlerService } from '../../../common/services/routeHandler.service';
import { PopupComponent } from '../../../common/utilities/popup/popup.component';
import { ActivitiHandlerService } from '../../../common/services/activitiHandler.service';
import { HttpResponse } from '@angular/common/http';
import { Formatter } from 'src/app/common/services/formatter';
import { SharedService } from 'src/app/common/services/sharedService';
import { AnalyticsService } from 'src/app/common/services/device.analytics.service';
import { CookieHandlerService } from 'src/app/common/services/cookieHandler.service';
import { RouteContextProvider } from 'src/app/common/services/routeContextProvider.service';
import { HttpInterceptor } from 'src/app/common/services/httpInterceptor.service';
import { CookieService } from 'ngx-cookie-service';
import { debug } from 'util';
const mockMartTaskdata: HttpResponse<any> = new HttpResponse({
  body: {
    payload: null,
    userInput: null,
    status: 'SUCCESS',
    errorBean: null,
    nextTaskKey: 'healthExtraCareNominee',
    progressInfo: null,
    routesInfo: null
  }
});
let mockData: HttpResponse<any> = new HttpResponse({
  body: {
    payload: {
      newTokens: {
        tokens: [
          {
            token:
              'eyJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJCYWphakZpblNlcnYiLCJleHAiOjE1NjczMjkyOTAsImlhdCI6MTU1MTc3NzI5MCwic3ViIjoiYXV0aGVudGljYXRpb24iLCJsb2dpbiI6IjY5ODc0NTEyMDFAMTk5Mi0wNS0wNSIsInVzZXJUeXBlIjoxfQ.EcV7Sh-ikQ6oNNk3E1m0fb5nWYm71V9yMMrMrj-ex-8',
            guardKey: 'HLOoDytiYF2t',
            type: 'authtoken'
          }
        ]
      },
      proposerDetails: {
        lastName: 'One',
        genederCode: 'M',
        apltWeight: 75,
        subsegmentMaster: null,
        apltcorecusid: null,
        apltcommprefchannel: null,
        addressDetails: [
          {
            key: 10178017,
            applicantKey: 75421,
            flatNumber: null,
            houseNumber: null,
            street: null,
            type: 'CURRENT',
            line1: 'aaaaaaaaa',
            line2: 'ddddddd',
            cityId: 1784,
            city: 'PUNE',
            cityCode: '1948',
            stateId: 257,
            state: 'MAHARASHTRA',
            stateCode: 'MH',
            countryId: 91,
            country: 'INDIA',
            countryCode: 'IN',
            pinId: 113597,
            pinCode: '411007',
            locality: 'AUNDH T.S. S.O',
            localityKey: null,
            areaLocalityName: null,
            addSource: null,
            appSource: null,
            occupancyType: null,
            occupancyName: null,
            pinOglFlag: null,
            pinNegativeAreaFlag: null,
            addressDeSelectedFlag: false
          }
        ],
        apltempid: null,
        apltstatus: null,
        apltHeight: 165,
        apltlstupdatedt: null,
        passportExpDate: null,
        genderDesc: 'Male',
        maritalStatusCode: null,
        nationalityCode: null,
        monthlyObligation: null,
        apltstatuschgdate: null,
        apltlstupdateby: null,
        relationship: null,
        apltcustcif: null,
        passportNumber: null,
        placeOfBirth: null,
        phoneNumberDetails: [
          {
            key: 121455,
            areaCode: '91',
            countryCode: '91',
            isDNDActive: 0,
            isPreferred: 1,
            isVerified: 0,
            number: '6987451201',
            applicantKey: 75421,
            type: 'MOBILE'
          }
        ],
        salutationCode: null,
        employmentDetails: null,
        applicationApplicantId: null,
        dateOfBirth: '1992-05-05',
        emailDetails: [
          {
            key: 118688,
            emailAddress: 'test.one@gmail.com',
            isVerified: 0,
            idPriority: 1,
            type: 'PERSON1',
            applicantKey: 75421
          }
        ],
        panNumber: null,
        maskAadhaarNumber: null,
        applicantProducts: [
          {
            applicationId: 182535,
            applicantId: 75421,
            prodMasKey: 3,
            prodMasCode: 'INSURANCE',
            prodMasDesc: 'Insurance'
          }
        ],
        languageCode: null,
        firstName: 'Test',
        applicantKey: 75421,
        aadhaarNumber: null,
        loanApplicationKey: null,
        apltinactivedt: null,
        phoneNumber: null,
        applicantRelatives: [
          {
            apltrelativekey: 23170,
            araadhaarnum: null,
            ardob: null,
            aremailid: null,
            arfname: 'aad',
            arisactive: 1,
            arlname: 'fgdg',
            arlstupdateby: null,
            armname: null,
            armobilenum: null,
            arpan: null,
            arpassportexpdt: '2019-02-28',
            arpassportnum: null,
            relationCode: 'SPOUSE'
          },
          {
            apltrelativekey: 23171,
            araadhaarnum: null,
            ardob: null,
            aremailid: null,
            arfname: 'aad',
            arisactive: 1,
            arlname: 'fgdg',
            arlstupdateby: null,
            armname: null,
            armobilenum: null,
            arpan: null,
            arpassportexpdt: '2019-02-28',
            arpassportnum: null,
            relationCode: 'SPOUSE'
          },
          {
            apltrelativekey: 23173,
            araadhaarnum: null,
            ardob: null,
            aremailid: null,
            arfname: 'aad',
            arisactive: 1,
            arlname: 'fgdg',
            arlstupdateby: null,
            armname: null,
            armobilenum: null,
            arpan: null,
            arpassportexpdt: '2019-02-28',
            arpassportnum: null,
            relationCode: 'SPOUSE'
          },
          {
            apltrelativekey: 23155,
            araadhaarnum: null,
            ardob: null,
            aremailid: null,
            arfname: 'aad',
            arisactive: 1,
            arlname: 'asdfsdfgdfgdg',
            arlstupdateby: null,
            armname: null,
            armobilenum: null,
            arpan: null,
            arpassportexpdt: '2019-02-27',
            arpassportnum: null,
            relationCode: 'SPOUSE'
          },
          {
            apltrelativekey: 23423,
            araadhaarnum: null,
            ardob: null,
            aremailid: null,
            arfname: 'aad',
            arisactive: 1,
            arlname: 'fgdg',
            arlstupdateby: null,
            armname: null,
            armobilenum: null,
            arpan: null,
            arpassportexpdt: '2019-03-04',
            arpassportnum: null,
            relationCode: 'SPOUSE'
          },
          {
            apltrelativekey: 23210,
            araadhaarnum: null,
            ardob: null,
            aremailid: null,
            arfname: 'aad',
            arisactive: 1,
            arlname: 'fgdg',
            arlstupdateby: null,
            armname: null,
            armobilenum: null,
            arpan: null,
            arpassportexpdt: '2019-02-28',
            arpassportnum: null,
            relationCode: 'SPOUSE'
          },
          {
            apltrelativekey: 23214,
            araadhaarnum: null,
            ardob: null,
            aremailid: null,
            arfname: 'aad',
            arisactive: 1,
            arlname: 'fgdg',
            arlstupdateby: null,
            armname: null,
            armobilenum: null,
            arpan: null,
            arpassportexpdt: '2019-02-28',
            arpassportnum: null,
            relationCode: 'SPOUSE'
          },
          {
            apltrelativekey: 23218,
            araadhaarnum: null,
            ardob: null,
            aremailid: null,
            arfname: 'aad',
            arisactive: 1,
            arlname: 'fgdg',
            arlstupdateby: null,
            armname: null,
            armobilenum: null,
            arpan: null,
            arpassportexpdt: '2019-02-28',
            arpassportnum: null,
            relationCode: 'SPOUSE'
          },
          {
            apltrelativekey: 23231,
            araadhaarnum: null,
            ardob: null,
            aremailid: null,
            arfname: 'aad',
            arisactive: 1,
            arlname: 'fgdg',
            arlstupdateby: null,
            armname: null,
            armobilenum: null,
            arpan: null,
            arpassportexpdt: '2019-02-28',
            arpassportnum: null,
            relationCode: 'SPOUSE'
          },
          {
            apltrelativekey: 23233,
            araadhaarnum: null,
            ardob: null,
            aremailid: null,
            arfname: 'aad',
            arisactive: 1,
            arlname: 'fgdg',
            arlstupdateby: null,
            armname: null,
            armobilenum: null,
            arpan: null,
            arpassportexpdt: '2019-02-28',
            arpassportnum: null,
            relationCode: 'SPOUSE'
          },
          {
            apltrelativekey: 23192,
            araadhaarnum: null,
            ardob: null,
            aremailid: null,
            arfname: 'aad',
            arisactive: 1,
            arlname: 'fgdg',
            arlstupdateby: null,
            armname: null,
            armobilenum: null,
            arpan: null,
            arpassportexpdt: '2019-02-28',
            arpassportnum: null,
            relationCode: 'SPOUSE'
          },
          {
            apltrelativekey: 22984,
            araadhaarnum: null,
            ardob: null,
            aremailid: null,
            arfname: 'aad',
            arisactive: 1,
            arlname: 'adsadasdassssssssssss',
            arlstupdateby: null,
            armname: null,
            armobilenum: null,
            arpan: null,
            arpassportexpdt: '2019-02-25',
            arpassportnum: null,
            relationCode: 'SPOUSE'
          },
          {
            apltrelativekey: 23152,
            araadhaarnum: null,
            ardob: null,
            aremailid: null,
            arfname: 'aad',
            arisactive: 1,
            arlname: 'asdf',
            arlstupdateby: null,
            armname: null,
            armobilenum: null,
            arpan: null,
            arpassportexpdt: '2019-02-27',
            arpassportnum: null,
            relationCode: 'SPOUSE'
          },
          {
            apltrelativekey: 23153,
            araadhaarnum: null,
            ardob: null,
            aremailid: null,
            arfname: 'aad',
            arisactive: 1,
            arlname: 'asdf',
            arlstupdateby: null,
            armname: null,
            armobilenum: null,
            arpan: null,
            arpassportexpdt: '2019-02-27',
            arpassportnum: null,
            relationCode: 'SPOUSE'
          },
          {
            apltrelativekey: 23154,
            araadhaarnum: null,
            ardob: null,
            aremailid: null,
            arfname: 'aad',
            arisactive: 1,
            arlname: 'asdfsdfgdfgdg',
            arlstupdateby: null,
            armname: null,
            armobilenum: null,
            arpan: null,
            arpassportexpdt: '2019-02-27',
            arpassportnum: null,
            relationCode: 'SPOUSE'
          },
          {
            apltrelativekey: 23445,
            araadhaarnum: null,
            ardob: null,
            aremailid: null,
            arfname: 'aad',
            arisactive: 1,
            arlname: 'fgdg',
            arlstupdateby: null,
            armname: null,
            armobilenum: null,
            arpan: null,
            arpassportexpdt: '2019-03-05',
            arpassportnum: null,
            relationCode: 'SPOUSE'
          }
        ],
        segmentMaster: null,
        apltisactive: null,
        maritalStatusDesc: null,
        apltisempflag: null,
        mobileVerifiedFlag: null,
        middleName: '',
        netSalary: null,
        apltgrossmthincome: null
      },
      selectedPlanDetails: {
        agreegatedDed: 500000,
        policyTerm: 1,
        insuringFor: 3,
        riders: [
          {
            sumAssured: 1000000,
            selected: 'Y',
            netPremium: 615,
            gst: 110.7,
            grossPremium: 726,
            code: 'IAMB'
          }
        ],
        gst: 739.98,
        netPremium: 4111,
        sumAssured: 1500000,
        totalGST: 850.68,
        insuringForDesc: 'Family',
        grossPremium: 4851,
        totalNetPremium: 4726,
        totalGrossPremium: 5577,
        selected: 'Y'
      },
      insuredCount: 2
    },
    userInput: null,
    status: 'SUCCESS',
    errorBean: null,
    nextTaskKey: 'healthExtraCareAddress',
    progressInfo: {
      payload: [
        { name: 'Get Started', value: 60, active: true },
        { name: 'Verify Me', value: 0, active: false },
        { name: 'Close The Deal', value: 0, active: false }
      ],
      status: 'SUCCESS',
      errorBean: null
    },
    routesInfo: {
      mainRoute: 'applicationStage',
      subRoute: 'addressNomineeDetails'
    }
  }
});
const healthExtraCareNominee: HttpResponse<any> = new HttpResponse({
  body: {
    payload: {
      nomineeDetails: {
        firstName: 'aad',
        lastName: 'fgdg',
        middleName: null,
        dateOfBirth: null,
        relationship: 'SPOUSE'
      },
      selectedPlanDetails: {
        agreegatedDed: 500000,
        policyTerm: 1,
        insuringFor: 3,
        riders: [
          {
            sumAssured: 1000000,
            selected: 'Y',
            netPremium: 615,
            gst: 110.7,
            grossPremium: 726,
            code: 'IAMB'
          }
        ],
        gst: 739.98,
        netPremium: 4111,
        sumAssured: 1500000,
        totalGST: 850.68,
        insuringForDesc: 'Family',
        grossPremium: 4851,
        totalNetPremium: 4726,
        totalGrossPremium: 5577,
        selected: 'Y'
      },
      insuredCount: 2
    },
    userInput: null,
    status: 'SUCCESS',
    errorBean: null,
    nextTaskKey: 'healthExtraCareNominee',
    progressInfo: {
      payload: [
        { name: 'Get Started', value: 80, active: true },
        { name: 'Verify Me', value: 0, active: false },
        { name: 'Close The Deal', value: 0, active: false }
      ],
      status: 'SUCCESS',
      errorBean: null
    },
    routesInfo: {
      mainRoute: 'applicationStage',
      subRoute: 'addressNomineeDetails'
    }
  }
});
const addressPayload: any = {
  isFormValid: true,
  address: {
    address: {
      applAddress: [
        {
          line1: 'aaaaaaaaa ',
          line2: 'ddddddd',
          pinCode: '411007',
          pinId: 113597,
          city: 'PUNE',
          cityId: 1784,
          state: 'MAHARASHTRA',
          stateId: 257,
          countryId: 91,
          country: 'INDIA',
          type: 'CURRENT',
          locality: null,
          localityKey: null,
          addSource: null,
          appSource: null
        }
      ]
    },
    permanentAddr: false
  }
};
const nomineePayload: any = {
  IsValid: true,
  nomineeDetails: {
    nomineeDetails: {
      firstName: 'aad',
      middleName: '',
      lastName: 'fgdg',
      relationship: 'SPOUSE'
    },
    selectedPlanDetails: null
  }
};
class MockActivitiHandlerService {
  public MarkTaskAsCompleted() {
    return of(mockMartTaskdata.body);
  }
  public GetTaskDetails() {
    return of(mockData.body);
  }
}
describe('Address Nominee Details Component', () => {
  // provide our implementations or mocks to the dependency injector
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [
        AddressNomineeDetailsComponent,
        HttpInterceptor,
        Formatter,
        FormBuilder,
        RouteHandlerService,
        FormValidator,
        SharedService,
        AnalyticsService,
        RouteContextProvider,
        CookieHandlerService,
        CookieService,
        {
          provide: ActivitiHandlerService,
          useClass: MockActivitiHandlerService
        }
      ]
    });
  });
  it('Testing ngOnInit for Address', inject(
    [AddressNomineeDetailsComponent],
    (testComponent: AddressNomineeDetailsComponent) => {
      testComponent.ngOnInit();
    }
  ));
  it('Testing ngOnInit for Nominee', inject(
    [AddressNomineeDetailsComponent],
    (testComponent: AddressNomineeDetailsComponent) => {
      mockData = healthExtraCareNominee;
      testComponent.ngOnInit();
    }
  ));
  it('Testing OnDetailsChanged', inject(
    [AddressNomineeDetailsComponent],
    (testComponent: AddressNomineeDetailsComponent) => {
      testComponent.ngOnInit();
      testComponent.OnDetailsChanged(addressPayload);
    }
  ));
  it('Testing OnNomineeDetailsChanged', inject(
    [AddressNomineeDetailsComponent],
    (testComponent: AddressNomineeDetailsComponent) => {
      testComponent.ngOnInit();
      testComponent.OnNomineeDetailsChanged(nomineePayload);
    }
  ));
  it('Testing Next for Address', inject(
    [AddressNomineeDetailsComponent],
    (testComponent: AddressNomineeDetailsComponent) => {
      testComponent.ngOnInit();
      testComponent.OnDetailsChanged(addressPayload);
      testComponent.Next();
    }
  ));
  it('Testing Next for Nominee', inject(
    [AddressNomineeDetailsComponent],
    (testComponent: AddressNomineeDetailsComponent) => {
      testComponent.ngOnInit();
      testComponent.OnNomineeDetailsChanged(nomineePayload);
      testComponent.Next();
    }
  ));
  it('Testing Back', inject(
    [AddressNomineeDetailsComponent],
    (testComponent: AddressNomineeDetailsComponent) => {
      testComponent.ngOnInit();
      testComponent.Back();
    }
  ));
});
