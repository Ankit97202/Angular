import { Component, OnInit, Output, ViewChild } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { FormValidator } from '../../common/services/formValidator.service';
import { ActivitiHandlerService } from '../../common/services/activitiHandler.service';
import { RouteHandlerService } from '../../common/services/routeHandler.service';
import { PincodeHandlerService } from '../../common/services/pincodeHandler.service';
import { CookieHandlerService } from '../../common/services/cookieHandler.service';
import { CommonConstants } from '../../common/utilities/commonConstants';
import { SharedService } from '../../common/services/sharedService';
import { Formatter } from 'src/app/common/services/formatter';
@Component({
  selector: 'app-address-nominee-details',
  templateUrl: './addressNomineeDetails.template.html',
  styleUrls: ['./addressNomineeDetails.style.css']
})
export class AddressNomineeDetailsComponent implements OnInit {
  public selectedTab: string;
  public showLoader = false;
  public CurrentAddressDetails: FormGroup;
  public DisableArea: boolean;
  public HealthPlanDetails: Model.HealthPlanDetails;
  public addressDetailsObj: any = null;
  public nomineeDetailsObj: any = null;
  private _outputPayload: any;
  public SelectedPlanDetails: Model.SelectedPlanDetails;
  public InsuredCount: number;
  private addressDetails = <Model.addressModel>{};
  private _addressFields = ['locality', 'street', 'pincode', 'state'];
  public IsValid = false;
  public ErrorMessage: string = null;
  private _exceptionKeysArr: string[] = [
    'healthextracarenominee',
    'healthextracareaddress'
  ];
  constructor(
    private _sharedService: SharedService,
    private _cookieHandler: CookieHandlerService,
    public FormValidators: FormValidator,
    private _activitiHandlerService: ActivitiHandlerService,
    private _routerService: RouteHandlerService,
    private _formatter: Formatter
  ) { }
  ngOnInit() {
    this.getTaskDetails();
  }
  public Next() {
    this.markTaskComplete(this._outputPayload, null);
  }
  public Back() {
    this.markTaskComplete(null, 'Back');
  }
  public OnDetailsChanged(emittedValue: Model.addressDetailsEmitterModel) {
    this._outputPayload = emittedValue.address;
    this.IsValid = emittedValue.isFormValid;
  }
  public OnNomineeDetailsChanged(emittedValue: Model.NomineeDetailsEmitterModel) {
    this._outputPayload = emittedValue.nomineeDetails;
    this.IsValid = emittedValue.IsValid;
  }
  // Getting Component Task details
  private getTaskDetails() {
    this._activitiHandlerService.GetTaskDetails().subscribe((mtResponse: ActivitiModel.MTResponse<any>) => {
      if (!mtResponse.errorBean) {
        const applicationID = this._sharedService.getData(CommonConstants.QueryParamsKeys.ApplicationId);
        let journeyType = CommonConstants.DEFAULT_EMPTY_STRING;
        if (applicationID) {
          journeyType = this._cookieHandler.GetCookie(CommonConstants.CookieKeys.JourneyType);
        }
        this.selectedTab = mtResponse.nextTaskKey;
        if (journeyType === CommonConstants.DEFAULT_EMPTY_STRING) {
          if (mtResponse.payload && mtResponse.payload.newTokens) {
            this.setUserAuthToken(mtResponse.payload);
          }
        }
        this.HealthPlanDetails = mtResponse.payload.healthPlanDetails;
        this.SelectedPlanDetails = mtResponse.payload.selectedPlanDetails;
        this.InsuredCount = mtResponse.payload.insuredCount;
        if (this.selectedTab === 'healthExtraCareAddress') {
          if (mtResponse.userInput) {
            this.addressDetailsObj = mtResponse.userInput.address.applAddress[0];
            // this.setUserInput(mtResponse.userInput.address);
          } else if (mtResponse.payload.proposerDetails.addressDetails) {
            this.addressDetailsObj = mtResponse.payload.proposerDetails.addressDetails[0];
            //  this.setUserInput(mtResponse.payload.proposerDetails);
          }
        } else {
          if (mtResponse.userInput) {
            this.nomineeDetailsObj = mtResponse.userInput;
            // this.setUserInput(mtResponse.userInput);
          } else if (mtResponse.payload) {
            this.nomineeDetailsObj = mtResponse.payload;
            // this.setUserInput(mtResponse.payload);
          }
        }
      }
    });
  }
  private setUserAuthToken(responseData: any) {
    if (responseData) {
      this._cookieHandler.SetCookie(CommonConstants.CookieKeys.JWToken,
        responseData.newTokens.tokens[0].token);
      this._cookieHandler.
        SetCookie(CommonConstants.CookieKeys.GuardKey,
          responseData.newTokens.tokens[0].guardKey);
      this._cookieHandler.SetCookie(CommonConstants.CookieKeys.GuardToken,
        this._formatter
          .ConvertGuradKeyToGuardToken(
            responseData.newTokens.tokens[0].guardKey));
    }
  }
  // Mark task complete
  private markTaskComplete(data, actionName: string) {
    this.showLoader = true;
    this.ErrorMessage = null;
    this._activitiHandlerService.MarkTaskAsCompleted(data, actionName).subscribe((mtResponse) => {
      this.showLoader = false;
      if (!mtResponse.errorBean) {
        this.IsValid = false;
        this._routerService.RouteToNextTask(
          mtResponse.nextTaskKey,
          this._exceptionKeysArr,
          key => {
            this.getTaskDetails();
          }
        );
      } else {
        this.ErrorMessage = CommonConstants.DEFAULT_ERROR_MESSAGE;
      }
    });
  }
}
