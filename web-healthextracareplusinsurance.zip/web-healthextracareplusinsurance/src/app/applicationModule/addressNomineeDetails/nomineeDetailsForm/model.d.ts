declare module Model {
  export interface NomineeDetailsInputPayload {
    selectedPlanDetails: Model.SelectedPlanDetails;
    nomineeDetails: Model.NomineeDetails;
  }
  export interface NomineeDetailsOutputPayload {
    nomineeDetails: Model.NomineeDetails;
    selectedPlanDetails: Model.SelectedPlanDetails;
  }
  export interface NomineeDetailsEmitterModel {
    nomineeDetails: Model.NomineeDetailsOutputPayload;
    IsValid: boolean;
  }
  export interface NomineeDetails {
    firstName?: string;
    middleName?: string;
    lastName?: string;
    dateOfBirth?: string;
    relationship: string;
  }
  export interface ProposerDetails {
    age: string;
    dob: string;
    firstName: string;
    lastName: string;
    middleName: string;
    gender: string;
    genderDesc: string;
    mobileNumber: string;
    maritalStatusdesc: string;
    email: string;
    passportNumber: string;
    aadhaarCardNumber: string;
    pan: string;
    occupationtype: string;
    occupationDesc: string;
    income: string;
    mailingAddress: string;
    permanentAddress: string;
    pinCode: string;
  }
}
