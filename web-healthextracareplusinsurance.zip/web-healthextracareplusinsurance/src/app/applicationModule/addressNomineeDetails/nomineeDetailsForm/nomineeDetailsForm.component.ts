import { Component, OnInit, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { FormValidator } from '../../../common/services/formValidator.service';
import { ActivitiHandlerService } from '../../../common/services/activitiHandler.service';
import { RouteHandlerService } from '../../../common/services/routeHandler.service';
import { Formatter } from '../../../common/services/formatter';
import { NomineeDetailsService } from './nomineeDetails.service';
@Component({
    selector: 'app-nominee-form-details',
    templateUrl: './nomineeDetailsForm.template.html',
    styleUrls: ['./nomineeDetailsForm.style.css']
})
export class NomineeDetailsFormComponent implements OnChanges {
    public NomineeDetailsFormGroup: FormGroup;
    public Nomineedetails: Model.NomineeDetails;
    public SelectedPlanDetails: Model.SelectedPlanDetails;
    public NomineeRelationship: any[];
    public IsValid: boolean;
    public showLoader = false;
    public InsuredCount: number;
    private _outputPayload = <Model.NomineeDetailsOutputPayload>{};
    private _isAppointeeValid: boolean;
    @Input() public nomineeDetailsObj: any;
    @Output() public nomineeDetailsChanged: EventEmitter<
      Model.NomineeDetailsEmitterModel
      > = new EventEmitter();
    constructor(
        public FormValidators: FormValidator,
        public Formatters: Formatter,
        private _formBuilder: FormBuilder,
        private _nomineeDetailsService: NomineeDetailsService
    ) { }
    // On component Init
    public ngOnChanges() {
        this.buildFormGroup();
        this.setUserInput(this.nomineeDetailsObj);
        this.fetchNomineeRelationship();
    }
    // Auto tab date of birth
    public onInputEntry($event, nextInput) {
        const input = $event.target;
        const length = input.value.length;
        const maxLength = input.attributes.maxlength.value;
        if (length >= maxLength) {
          document.getElementById(nextInput).focus();
        }
    }
    // Validate Space of Field
    public ValidateSpace($event) {
        if ($event.keyCode === 32) {
            return false;
        } else {
            return this.FormValidators.IsAlphabet($event);
        }
    }
    // Building Nominee Form Group
    private buildFormGroup() {
      const mustHaveLastName = (control: FormControl) => {
        return !control.value.trim() || control.value.trim().includes(' ')
          ? null
          : { lastNameMandatory: true };
      };
      this.NomineeDetailsFormGroup = this._formBuilder.group({
          nomineeName: ['', [Validators.required, mustHaveLastName]],
          relationship: ['', Validators.compose([Validators.required])]
      });
      this.NomineeDetailsFormGroup.valueChanges.subscribe(() => {
          this.IsValid = this.NomineeDetailsFormGroup.valid;
          const payload: Model.NomineeDetailsOutputPayload = this.getFinalPayload();
          const emmittedObj: Model.NomineeDetailsEmitterModel = {
            IsValid: this.IsValid,
            nomineeDetails: payload
          };
          this.nomineeDetailsChanged.emit(emmittedObj);
      });
    }
    // Creating Output Payload For Mark Task Call
    private getFinalPayload(): Model.NomineeDetailsOutputPayload {
        const formValue = this.NomineeDetailsFormGroup.value;
        const nomineeDetails = <Model.NomineeDetails>{};
        const nomineeName = formValue['nomineeName'];
        nomineeDetails.firstName = this.Formatters.GetName('first', nomineeName);
        nomineeDetails.middleName = this.Formatters.GetName('middle', nomineeName);
        nomineeDetails.lastName = this.Formatters.GetName('last', nomineeName);
        nomineeDetails.relationship = formValue['relationship'];
        const OutputPayload = <Model.NomineeDetailsOutputPayload>{
            nomineeDetails: nomineeDetails,
            selectedPlanDetails: this.SelectedPlanDetails ? this.SelectedPlanDetails : null
        };
        return OutputPayload;
    }
    // Setting Nominee Details Data To the Form Group
    private setUserInput(userInput: Model.NomineeDetailsOutputPayload) {
        if (userInput) {
        const nomineeName = userInput.nomineeDetails.firstName + ' ' +
            (userInput.nomineeDetails.middleName ? userInput.nomineeDetails.middleName + ' ' : '') +
            userInput.nomineeDetails.lastName;
        if (nomineeName !== 'null null') {
          this.NomineeDetailsFormGroup.controls['nomineeName'].setValue(nomineeName);
        }
        this.NomineeDetailsFormGroup.controls['relationship'].setValue(userInput.nomineeDetails.relationship);
        }
    }
    private fetchNomineeRelationship() {
        this._nomineeDetailsService.FetchNomineeRelationships().subscribe((response) => {
            if (!response.errorBean) {
                this.NomineeRelationship = response.payload;
            }
        });
    }
}
