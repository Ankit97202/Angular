import { FormBuilder, FormGroup } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TestBed, inject } from '@angular/core/testing';
import { of, Observable } from 'rxjs';
import { FormValidator } from '../../../../common/services/formValidator.service';
import { RouteHandlerService } from '../../../../common/services/routeHandler.service';
import { HttpResponse, HttpClient, HttpHandler } from '@angular/common/http';
import { Formatter } from 'src/app/common/services/formatter';
import { SharedService } from 'src/app/common/services/sharedService';
import { AnalyticsService } from 'src/app/common/services/device.analytics.service';
import { CookieHandlerService } from 'src/app/common/services/cookieHandler.service';
import { RouteContextProvider } from 'src/app/common/services/routeContextProvider.service';
import { HttpInterceptor } from 'src/app/common/services/httpInterceptor.service';
import { CookieService } from 'ngx-cookie-service';
import { debug } from 'util';
import { PincodeHandlerService } from 'src/app/common/services/pincodeHandler.service';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { NomineeDetailsFormComponent } from 'src/app/applicationModule';
import { NomineeDetailsService } from '../nomineeDetails.service';
const nomineeDetails = {
  nomineeDetails: {
    firstName: 'asd',
    lastName: 'asd',
    middleName: null,
    dateOfBirth: null,
    relationship: 'MOTHER'
  },
  selectedPlanDetails: {
    agreegatedDed: 500000,
    policyTerm: 1,
    insuringFor: 2,
    riders: [
      {
        sumAssured: 1000000,
        selected: 'Y',
        netPremium: 385,
        gst: 69.3,
        grossPremium: 454,
        code: 'IAMB'
      }
    ],
    gst: 462.78,
    netPremium: 2571,
    sumAssured: 1500000,
    totalGST: 532.08,
    insuringForDesc: 'Individual',
    grossPremium: 3034,
    totalNetPremium: 2956,
    totalGrossPremium: 3488,
    selected: 'Y'
  },
  insuredCount: 1
};
const mockData: HttpResponse<any> = new HttpResponse({
  body: {
    payload: [
      { rcmcode: 'DAUGHTER', rcmtype: 4 },
      { rcmcode: 'FATHER', rcmtype: 1 },
      { rcmcode: 'MOTHER', rcmtype: 1 },
      { rcmcode: 'SON', rcmtype: 4 },
      { rcmcode: 'SPOUSE', rcmtype: 2 }
    ],
    status: 'SUCCESS',
    errorBean: null
  }
});
class MockActivitiHandlerService {
  public FetchNomineeRelationships() {
    return of(mockData.body);
  }
}
describe('Nominee Details Form Componant', () => {
  // provide our implementations or mocks to the dependency injector
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [
        NomineeDetailsFormComponent,
        HttpInterceptor,
        FormBuilder,
        FormValidator,
        SharedService,
        RouteContextProvider,
        CookieHandlerService,
        CookieService,
        HttpInterceptor,
        HttpClient,
        HttpHandler,
        {
          provide: NomineeDetailsService,
          useClass: MockActivitiHandlerService
        }
      ]
    });
  });
  it('Testing ngOnInit for Address', inject(
    [NomineeDetailsFormComponent],
    (testComponent: NomineeDetailsFormComponent) => {
      testComponent.nomineeDetailsObj = nomineeDetails;
      testComponent.ngOnChanges();
    }
  ));
});
