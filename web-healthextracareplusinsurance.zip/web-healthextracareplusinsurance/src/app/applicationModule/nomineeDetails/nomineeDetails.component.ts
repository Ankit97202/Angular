import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { FormValidator } from '../../common/services/formValidator.service';
import { ActivitiHandlerService } from '../../common/services/activitiHandler.service';
import { RouteHandlerService } from '../../common/services/routeHandler.service';
import { Formatter } from '../../common/services/formatter';
import { NomineeDetailsService } from '../addressNomineeDetails/nomineeDetailsForm/nomineeDetails.service';
@Component({
    templateUrl: './nomineeDetails.template.html',
    styleUrls: ['./nomineeDetails.style.css']
})
export class NomineeDetailsComponent implements OnInit {
    public NomineeDetailsFormGroup: FormGroup;
    public Nomineedetails: Model.NomineeDetails;
    public SelectedPlanDetails: Model.SelectedPlanDetails;
    public NomineeRelationship: any[];
    public IsValid: boolean;
    public showLoader = false;
    public InsuredCount:number;
    private _outputPayload = <Model.NomineeDetailsOutputPayload>{};
    private _isAppointeeValid: boolean;
    constructor(
        public FormValidators: FormValidator,
        public Formatters: Formatter,
        private _formBuilder: FormBuilder,
        private _activitiHandlerService: ActivitiHandlerService,
        private _routerService: RouteHandlerService,
        private _nomineeDetailsService: NomineeDetailsService
    ) { }
    // On component Init
    public ngOnInit() {
        this.buildFormGroup();
        this.fetchNomineeRelationship();
    }
    // On Back
    public Back() {
        this.markTaskComplete(null, 'Back');
    }
    // On Next
    public Next() {
        const payload: Model.NomineeDetailsOutputPayload = this.getFinalPayload();
        this.markTaskComplete(payload, '');
    }
    // Auto tab date of birth
    public onInputEntry($event, nextInput) {
        const input = $event.target;
        const length = input.value.length;
        const maxLength = input.attributes.maxlength.value;
        if (length >= maxLength) {
          document.getElementById(nextInput).focus();
        }
    }
    // Validate Space of Field
    public ValidateSpace($event) {
        if ($event.keyCode === 32) {
            return false;
        } else {
            return this.FormValidators.IsAlphabet($event);
        }
    }
    // Building Nominee Form Group
    private buildFormGroup() {
      const mustHaveLastName = (control: FormControl) => {
        return !control.value.trim() || control.value.trim().includes(' ')
          ? null
          : { lastNameMandatory: true };
      };
      this.NomineeDetailsFormGroup = this._formBuilder.group({
          nomineeName: ['', [Validators.required, mustHaveLastName]],
          relationship: ['', Validators.compose([Validators.required])]
      });
      this.NomineeDetailsFormGroup.valueChanges.subscribe(() => {
          this.IsValid = this.NomineeDetailsFormGroup.valid;
      });
    }
    // Creating Output Payload For Mark Task Call
    private getFinalPayload(): Model.NomineeDetailsOutputPayload {
        const formValue = this.NomineeDetailsFormGroup.value;
        const nomineeDetails = <Model.NomineeDetails>{};
        const nomineeName = formValue['nomineeName'];
        nomineeDetails.firstName = this.Formatters.GetName('first', nomineeName);
        nomineeDetails.middleName = this.Formatters.GetName('middle', nomineeName);
        nomineeDetails.lastName = this.Formatters.GetName('last', nomineeName);
        nomineeDetails.relationship = formValue['relationship'];
        const OutputPayload = <Model.NomineeDetailsOutputPayload>{
            nomineeDetails: nomineeDetails,
            selectedPlanDetails: this.SelectedPlanDetails ? this.SelectedPlanDetails : null
        };
        return OutputPayload;
    }
    // Setting Nominee Details Data To the Form Group
    private setUserInput(userInput: Model.NomineeDetailsOutputPayload) {
        if(userInput){
        const nomineeName = userInput.nomineeDetails.firstName + ' ' +
            (userInput.nomineeDetails.middleName ? userInput.nomineeDetails.middleName + ' ' : '') +
            userInput.nomineeDetails.lastName;
        if(nomineeName !== 'null null')
        this.NomineeDetailsFormGroup.controls['nomineeName'].setValue(nomineeName);
        this.NomineeDetailsFormGroup.controls['relationship'].setValue(userInput.nomineeDetails.relationship);
        }
    }
    // Getting Component Task details
    private getTaskDetails() {
        this._activitiHandlerService.GetTaskDetails().subscribe((mtResponse) => {
            if (!mtResponse.errorBean) {
                console.log('payload:', mtResponse.payload);
                this.SelectedPlanDetails = mtResponse.payload.selectedPlanDetails;
                this.InsuredCount = mtResponse.payload.insuredCount;
                this.Nomineedetails = mtResponse.payload.nomineeDetails;
                if (mtResponse.userInput) {
                    this.setUserInput(mtResponse.userInput);
                } else if (!mtResponse.userInput) {
                    this.setUserInput(mtResponse.payload);
                }
            }
        }
      );
    }
    // Mark task complete
    private markTaskComplete(data, actionName: string) {
        this.showLoader = true;
        this._activitiHandlerService.MarkTaskAsCompleted(data, actionName).subscribe((mtResponse) => {
            this.showLoader = false;
            if (!mtResponse.errorBean) {
                this._routerService.RouteToNextTask(mtResponse.nextTaskKey);
            }
        });
    }
    private fetchNomineeRelationship() {
        this._nomineeDetailsService.FetchNomineeRelationships().subscribe((response) => {
            if (!response.errorBean) {
                this.NomineeRelationship = response.payload;
                this.getTaskDetails();

            }
        });
    }
}
