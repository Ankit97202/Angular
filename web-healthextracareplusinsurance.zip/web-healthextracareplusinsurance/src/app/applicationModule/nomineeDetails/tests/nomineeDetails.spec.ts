import { NomineeDetailsService } from './../../addressNomineeDetails/nomineeDetailsForm/nomineeDetails.service';
import { TestBed, inject } from '@angular/core/testing';
import { BaseRequestOptions, ConnectionBackend, Http, Response, ResponseOptions, XHRBackend } from '@angular/http';
import { RouterTestingModule } from '@angular/router/testing';
import { ActivitiHandlerService } from './../../../common/services/activitiHandler.service';
import { CookieHandlerService } from 'src/app/common/services/cookieHandler.service';
import { RouteContextProvider } from 'src/app/common/services/routeContextProvider.service';
import { AnalyticsService } from 'src/app/common/services/device.analytics.service';
import { SharedService } from 'src/app/common/services/sharedService';
import { RouteHandlerService } from './../../../common/services/routeHandler.service';
import { FormValidator } from './../../../common/services/formValidator.service';
import { Formatter } from 'src/app/common/services/formatter';
import { NomineeDetailsComponent } from './../nomineeDetails.component';
import { Observable } from 'rxjs/Observable';
import { FormBuilder } from '@angular/forms';
import { HttpInterceptor } from '../../../common/services/httpInterceptor.service';
import { of } from 'rxjs';
import { MockBackend } from '@angular/http/testing';
import { HttpResponse } from '@angular/common/http';
const mockMarkTaskdata: HttpResponse<any> = new HttpResponse({
    body: {
      payload: null,
      userInput: null,
      status: 'SUCCESS',
      errorBean: null,
      nextTaskKey: 'healthExtraCareMedicalDetails',
      progressInfo: null,
      routesInfo: null
    }
  });
const mockData: HttpResponse<any> = new HttpResponse({
    body: {
      payload: {
        insuringFor: null,
        selectedPlanDetails: {
          sumAssured: 500000,
          planCode: 'HXCP',
          variantCode: 'HXCP1',
          netPremium: 5621,
          gst: 1012,
          grossPremium: 6633,
          zone: 'ZONEB',
          policyTerm: 1,
          displayName: 'Health Extra Care Plus'
        },
        nomineeDetails: {
          firstName: null,
          lastName: null,
          middleName: null,
          dateOfBirth: null,
          relationship: null
        }
      },
      status: 'SUCCESS',
      errorBean: null,
      userInput: null,
      nextTaskKey: 'healthExtraCareNominee',
      progressInfo: {
        payload: [
          {
            name: 'Explore Right Plan',
            value: 100,
            active: false
          },
          {
            name: 'Application Stage',
            value: 100,
            active: false
          },
          {
            name: 'Final Check',
            value: 0,
            active: true
          },
          {
            name: 'Close The Deal',
            value: 0,
            active: false
          }
        ],
        status: 'SUCCESS',
        errorBean: null
      },
      routesInfo: {
        mainRoute: 'applicationStage',
        subRoute: 'nomineeDetails'
      }
    }
});
const MockRelationships: HttpResponse<any> = new HttpResponse({
    body: {
      payload: [
        { rcmcode: 'SPOUSE', rcmtype: 2 },
        { rcmcode: 'DAUGHTER', rcmtype: 4 },
        { rcmcode: 'FATHER', rcmtype: 1 },
        { rcmcode: 'MOTHER', rcmtype: 1 },
        { rcmcode: 'SON', rcmtype: 4 }
      ]
    }
  });
const MockSelectedPlanDetails: any = {
  sumAssured: 500000,
  planCode: 'HXCP',
  variantCode: 'HXCP1',
  netPremium: 5621,
  gst: 1012,
  grossPremium: 6633,
  zone: 'ZONEB',
  policyTerm: 1,
  displayName: 'Health Extra Care Plus'
};
class MockActivitiHandlerService {
  public MarkTaskAsCompleted() {
    return of(mockMarkTaskdata.body);
  }
  public GetTaskDetails() {
    return of(mockData.body);
  }
}
// tslint:disable-next-line:max-classes-per-file
class MockNomineeDetailsService {
  public FetchNomineeRelationships() {
    return of(MockRelationships.body);
  }
}
describe('Nominee Details Component', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [
        NomineeDetailsComponent,
        HttpInterceptor,
        Formatter,
        FormValidator,
        FormBuilder,
        RouteHandlerService,
        FormValidator,
        SharedService,
        AnalyticsService,
        RouteContextProvider,
        MockBackend,
        { provide: XHRBackend, useClass: MockBackend },
        CookieHandlerService,
        {
          provide: ActivitiHandlerService,
          useClass: MockActivitiHandlerService
        },
        { provide: NomineeDetailsService, useClass: MockNomineeDetailsService },
        {
          provide: Http,
          useFactory: (
            backend: ConnectionBackend,
            defaultOptions: BaseRequestOptions
          ) => {
            return new Http(backend, defaultOptions);
          },
          deps: [MockBackend, BaseRequestOptions]
        }
      ]
    });
  });
  it('Testing ngOnInit', inject(
    [NomineeDetailsComponent],
    (testComponent: NomineeDetailsComponent) => {
      testComponent.ngOnInit();
    }
  ));
  it('Testing Next', inject(
    [NomineeDetailsComponent],
    (testComponent: NomineeDetailsComponent) => {
      testComponent.ngOnInit();
      testComponent.Next();
    }
  ));
  it('Testing Back', inject(
    [NomineeDetailsComponent],
    (testComponent: NomineeDetailsComponent) => {
      testComponent.ngOnInit();
      testComponent.SelectedPlanDetails = MockSelectedPlanDetails;
      testComponent.Back();
    }
  ));
});
