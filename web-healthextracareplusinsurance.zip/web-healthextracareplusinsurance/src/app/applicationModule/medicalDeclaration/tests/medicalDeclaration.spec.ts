import { FormBuilder } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TestBed, inject } from '@angular/core/testing';
import { of, Observable } from 'rxjs';
import { HttpResponse, HttpClient, HttpHandler } from '@angular/common/http';
import { Formatter } from 'src/app/common/services/formatter';
import { SharedService } from 'src/app/common/services/sharedService';
import { AnalyticsService } from 'src/app/common/services/device.analytics.service';
import { CookieHandlerService } from 'src/app/common/services/cookieHandler.service';
import { RouteContextProvider } from 'src/app/common/services/routeContextProvider.service';
import { HttpInterceptor } from 'src/app/common/services/httpInterceptor.service';
import { CookieService } from 'ngx-cookie-service';
import { debug } from 'util';
import { RouteHandlerService } from 'src/app/common/services/routeHandler.service';
import { FormValidator } from 'src/app/common/services/formValidator.service';
import { ActivitiHandlerService } from 'src/app/common/services/activitiHandler.service';
import { ConfigService } from 'src/app/common/services/config.service';
import { MedicalDeclarationComponent } from '../..';
const mockMartTaskdata: HttpResponse<any> = new HttpResponse({
    body: {
        "payload":null,
        "userInput":null,
        "status":"SUCCESS",
        "errorBean":null,
        "nextTaskKey":"healthExtraCareProductSummary",
        "progressInfo":null,
        "routesInfo":null
     }
  });

const mockData: HttpResponse<any> = new HttpResponse({
    body: {
        'payload': {
            'insuranceQues': {
              'insPlanQueSets': [
                {
                  'headerDescId': 11,
                  'headerDesc': 'Medical Declaration',
                  'insPlanQuestions': [
                    {
                      'helpText': null,
                      'isMain': 'N',
                      'parentQuestionId': null,
                      'questionId': 'HGFF-QMD2-2',
                      'questionKey': 104,
                      'questionDesc': 'If Yes',
                      'action': null,
                      'ansRequired': 1,
                      'inputType': 'INPUTBOX',
                      'displayOrder': 4,
                      'datasource': null,
                      'placeHolder': null,
                      'possibleAnswers': [
                        {
                          'nextQuestions': null,
                          'questionResponseKey': 254,
                          'questionResponse': 'Enter Details',
                          'choiceCode': null,
                          'responseOrder': 1,
                          'defaultSelection': 'N',
                          'nextQuestion': null,
                          'validation': 'TEXT'
                        }
                      ],
                      'responseTemplateBean': []
                    },
                    {
                      // tslint:disable-next-line:max-line-length
                      'helpText': null,
                      'isMain': 'Y',
                      'parentQuestionId': null,
                      'questionId': 'HGFF-QMD1-1',
                      'questionKey': 107,
                      // tslint:disable-next-line:max-line-length
                      'questionDesc': 'Do you or any of the family members who need to be covered have/had any health complaints, have met with an accident or were hospitalised in the period prior to taking this policy?',
                      'action': null,
                      'ansRequired': 1,
                      'inputType': 'BUTTON',
                      'displayOrder': 1,
                      'datasource': null,
                      'placeHolder': null,
                      'possibleAnswers': [
                        {
                          'nextQuestions': null,
                          'questionResponseKey': 257,
                          'questionResponse': 'No',
                          'choiceCode': null,
                          'responseOrder': 1,
                          'defaultSelection': 'Y',
                          'nextQuestion': null,
                          'validation': 'TEXT'
                        },
                        {
                          'nextQuestions': null,
                          'questionResponseKey': 258,
                          'questionResponse': 'Yes',
                          'choiceCode': null,
                          'responseOrder': 2,
                          'defaultSelection': 'N',
                          'nextQuestion': 108,
                          'validation': 'TEXT'
                        }
                      ],
                      'responseTemplateBean': []
                    },
                    {
                      'helpText': null,
                      'isMain': 'N',
                      'parentQuestionId': null,
                      'questionId': 'HGFF-QMD1-2',
                      'questionKey': 108,
                      'questionDesc': 'If Yes',
                      'action': null,
                      'ansRequired': 1,
                      'inputType': 'INPUTBOX',
                      'displayOrder': 2,
                      'datasource': null,
                      'placeHolder': null,
                      'possibleAnswers': [
                        {
                          'nextQuestions': null,
                          'questionResponseKey': 259,
                          'questionResponse': 'Enter Details',
                          'choiceCode': null,
                          'responseOrder': 1,
                          'defaultSelection': 'N',
                          'nextQuestion': null,
                          'validation': 'TEXT'
                        }
                      ],
                      'responseTemplateBean': []
                    },
                    {
                      // tslint:disable-next-line:max-line-length
                      'helpText': null,
                      'isMain': 'Y',
                      'parentQuestionId': null,
                      'questionId': 'HGFF-QMD2-1',
                      'questionKey': 109,
                      'questionDesc': 'Are you or any of the family members to be covered under any form of medication for any illness/diseases?',
                      'action': null,
                      'ansRequired': 1,
                      'inputType': 'BUTTON',
                      'displayOrder': 3,
                      'datasource': null,
                      'placeHolder': null,
                      'possibleAnswers': [
                        {
                          'nextQuestions': null,
                          'questionResponseKey': 260,
                          'questionResponse': 'No',
                          'choiceCode': null,
                          'responseOrder': 1,
                          'defaultSelection': 'Y',
                          'nextQuestion': null,
                          'validation': 'TEXT'
                        },
                        {
                          'nextQuestions': null,
                          'questionResponseKey': 261,
                          'questionResponse': 'Yes',
                          'choiceCode': null,
                          'responseOrder': 2,
                          'defaultSelection': 'N',
                          'nextQuestion': 104,
                          'validation': 'TEXT'
                        }
                      ],
                      'responseTemplateBean': []
                    }
                  ]
                }
              ],
              'insProductPlanCode': 'HGFF',
              'gender': 'Male',
              'nominee': {
                'firstName': null,
                'middleName': null,
                'lastName': null,
                'relation': null,
                'dateOfBirth': null
              },
              'insProductPlan': 'Health Guard Family Floater',
              'applicationId': 114174
            },
            'healthPlanDetails': {
              'insuringFor': 3,
              'insuringForDesc': 'Family',
              'proposerDetails': {
                'age': null,
                'dob': '1800-01-01',
                'firstName': 'Name',
                'lastName': 'Surname',
                'middleName': null,
                'gender': 'M',
                'genderDesc': 'Male',
                'mobileNumber': '7344123114',
                'maritalStatusdesc': null,
                'email': null,
                'passportNumber': null,
                'aadhaarCardNumber': null,
                'pan': null,
                'occupationtype': null,
                'occupationDesc': null,
                'income': null,
                'mailingAddress': null,
                'permanentAddress': null,
                'pinCode': '411057'
              },
              'proposedSumAssuredList': [
                150000,
                200000
              ],
              'insuredDetails': [
                {
                  'no': 6822,
                  'firstName': 'Name',
                  'middleName': null,
                  'lastName': 'Surname',
                  'birthPlace': null,
                  'dob': null,
                  'relationship': 'SELF',
                  'age': 29,
                  'genderCode': null,
                  'genderDesc': null,
                  'maritalStatusCode': null,
                  'countryCode': null,
                  'height': null,
                  'weight': null,
                  'presentInIndiaFlg': false,
                  'indianPassportFlg': false,
                  'passportNum': null,
                  'passportExpdt': null,
                  'smokerFlg': false,
                  'nationalityCode': null,
                  'bmi': null,
                  'insuredDeleted': false
                },
                {
                  'no': 6823,
                  'firstName': null,
                  'middleName': null,
                  'lastName': null,
                  'birthPlace': null,
                  'dob': null,
                  'relationship': 'SPOUSE',
                  'age': 25,
                  'genderCode': null,
                  'genderDesc': null,
                  'maritalStatusCode': null,
                  'countryCode': null,
                  'height': null,
                  'weight': null,
                  'presentInIndiaFlg': false,
                  'indianPassportFlg': false,
                  'passportNum': null,
                  'passportExpdt': null,
                  'smokerFlg': false,
                  'nationalityCode': null,
                  'bmi': null,
                  'insuredDeleted': false
                }
              ],
              'selectedPlanDetails': {
                'sumAssured': 200000,
                'planCode': 'HGFF',
                'variantCode': 'HGFF2',
                'netPremium': 4694,
                'gst': 845,
                'grossPremium': 5539,
                'zone': 'ZONEB',
                'policyTerm': 1,
                'displayName': 'Health Guard Family Floater - Silver Plan'
              },
              'applicationId': '114174',
              'planModified': false
            }
          },
          'userInput': null,
          'status': 'SUCCESS',
          'errorBean': null,
          'nextTaskKey': 'healthExtraCareMedicalDetails',
          'progressInfo': {
            'payload': [
              {
                'name': 'Explore Right Plan',
                'value': 100,
                'active': false
              },
              {
                'name': 'Application Stage',
                'value': 100,
                'active': false
              },
              {
                'name': 'Final Check',
                'value': 0,
                'active': true
              },
              {
                'name': 'Close The Deal',
                'value': 0,
                'active': false
              }
            ],
            'status': 'SUCCESS',
            'errorBean': null
          },
          'routesInfo': {
            'mainRoute': 'insuranceQuestions',
            'subRoute': ''
          }
    }
});
class MockActivitiHandlerService {
    public MarkTaskAsCompleted() {
      return of(mockMartTaskdata.body);
    }
    public GetTaskDetails() {
      return of(mockData.body);
    }
  }
describe('GetQuoteForm Component', () => {
    const $event = {
        target: {
            value: ""
        }
    }
    // provide our implementations or mocks to the dependency injector
    beforeEach(() => {
      TestBed.configureTestingModule({
        imports: [RouterTestingModule],
        providers: [
          HttpInterceptor,
          MedicalDeclarationComponent,
          Formatter,
          FormBuilder,
          RouteHandlerService,
          FormValidator,
          SharedService,
          AnalyticsService,
          RouteContextProvider,
          CookieHandlerService,
          CookieService,
          HttpClient,
          HttpHandler,
          {
            provide: ActivitiHandlerService,
            useClass: MockActivitiHandlerService
          }
        ]
      });
    });
    const data: any = {
        changedValue: false
      };
    it('Testing ngOnInit', inject(
      [MedicalDeclarationComponent],
      (testComponent: MedicalDeclarationComponent) => {
        testComponent.ngOnInit();
      }
    ));
    it('Testing Next', inject(
        [MedicalDeclarationComponent],
        (testComponent: MedicalDeclarationComponent) => {
          testComponent.ngOnInit();
          testComponent.Next();
        }
      ));
      it('Testing Back', inject(
        [MedicalDeclarationComponent],
        (testComponent: MedicalDeclarationComponent) => {
          testComponent.ngOnInit();
          testComponent.Back();
        }
      ));
    it('Testing QuestionnaireHandler', inject(
      [MedicalDeclarationComponent],
      (testComponent: MedicalDeclarationComponent) => {
        testComponent.ngOnInit();
        testComponent.QuestionnaireHandler(data);
      }
    ));
    it('Testing NavigateToErrorPage', inject(
      [MedicalDeclarationComponent],
      (testComponent: MedicalDeclarationComponent) => {
        testComponent.ngOnInit();
        testComponent.NavigateToErrorPage($event);
      }
    ));
  });
