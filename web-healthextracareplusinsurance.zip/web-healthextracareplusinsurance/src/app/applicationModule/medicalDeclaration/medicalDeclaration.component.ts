import { Component, OnInit, ViewChildren, QueryList } from '@angular/core';
import { ActivitiHandlerService } from '../../common/services/activitiHandler.service';
import { RouteHandlerService } from '../../common/services/routeHandler.service';
import { CookieHandlerService } from '../../common/services/cookieHandler.service';
import { CommonConstants } from '../../common/utilities/commonConstants';
import { PopupComponent } from './../../common/utilities/popup/popup.component';
@Component({
    templateUrl: './medicalDeclaration.template.html',
    styleUrls: ['./medicalDeclaration.style.css']
})
export class MedicalDeclarationComponent implements OnInit {
    // Public variables
    @ViewChildren(PopupComponent) public PopupComponent: QueryList<any>;
    public SelectedPlanDetails: Model.SelectedPlanDetails;
    public PlanSummaryObject: ActivitiModel.PlanDetails;
    public QuestionList: Model.InsuranceQuesttanaire[];
    public AllUserAnswers: Model.InsuranceAnswers[] = [];
    public QuestionnaireUserInput: Model.InsuranceAnswers;
    public IsValid: boolean;
    public UserInput: Model.MedicalDeclarationOutputPayload;
    public showLoader = false;
    public ContentPopup;
    public Config = { show: false, backdrop: 'static' };
    public IsYesFlag = false;
    public insProductPlanCode: string;
    public insProductPlan: string;
    public InsuredCount: number;
    // Private Variables
    private _inputPayload: Model.MedicalDeclarationInputPayload;
    private _outputPaylaod = <Model.MedicalDeclarationOutputPayload>{};
    public ErrorMessage: string = null;
    // Constructor
    constructor(
        private _activitiHandler: ActivitiHandlerService,
        private _routerService: RouteHandlerService,
        private _cookieHandler: CookieHandlerService
    ) { }
    // On component Init
    public ngOnInit() {
        this.getTaskDetails();
        this.initContentPopup();
    }
    // On Next
    public Next() {
        this.markTaskComplete(this._outputPaylaod, '');
    }
    public Back() {
        this.markTaskComplete(null, 'Back');
    }
    // Insurance Questionnaire Event Handler
    public QuestionnaireHandler(changedValue: Model.QuestionnaireEmitterObj) {
        this.IsValid = changedValue.isAllFormsValid;
        this.AllUserAnswers = changedValue.responseTemplate;
        this._outputPaylaod.insProductPlan = this.insProductPlan;
        this._outputPaylaod.insProductPlanCode = this.insProductPlanCode;
        this._outputPaylaod.responseTemplate = changedValue.responseTemplate;
        console.log(this.AllUserAnswers);
    }
    // Show Modal Popup
    public ShowChildModal(id: string, contentType?: string): void {
        if (contentType) {
            this.initContentPopup();
        }
        this.getModalDirectiveInstanceBasedOnId(id).show();
    }
    // Hide Modal Popup
    public HideChildModal(id: string): void {
        this.getModalDirectiveInstanceBasedOnId(id).hide();
    }
    // Redirected to error page depend on the next key provided by the service
    public NavigateToErrorPage($event) {
        let payload = {
            rejectionSrc: 'BAGIC',
            rejectionCode: 'HXCPREJ1'
        }
        this.markTaskComplete(payload, 'Ok');
    }
    public NavigateToPreviousPage($event) {
        this.markTaskComplete(null, '');
        this.getModalDirectiveInstanceBasedOnId(this.ContentPopup.Id).hide();
    }
    /* Getting Popup Instances Based on Id */
    private getModalDirectiveInstanceBasedOnId(popupId: string): any {
        return this.PopupComponent.filter((item: PopupComponent, index: number) => {
            return item.id === popupId;
        })[0].modalControl;
    }
    /*Initialize Popup*/
    private initContentPopup() {
        this.ContentPopup = {
            Id: 'content-modal',
            Title: 'Medical Declaration',
            Config: <CustomModalOptions>{ show: false, closeOption: true }
        };
        console.log('this.config.closeOption:', this.ContentPopup.Config.closeOption);
    }
    private checkAnyAnswerYes(): boolean {
        for (const answer of this.AllUserAnswers) {
            if (answer.questionResponseBean[0].questionResponseValue === 'Yes') {
                this.IsYesFlag = true;
                return true;
            }
        }
        return false;
    }
    // Getting Task Details
    private getTaskDetails() {
        this.IsValid = false;
        this._activitiHandler.GetTaskDetails().subscribe((mtResponse: ActivitiModel.MTResponse<Model.MedicalDeclarationInputPayload>) => {
            if (!mtResponse.errorBean) {
                this._inputPayload = mtResponse.payload;
                this.insProductPlanCode = this._inputPayload.insuranceQues.insProductPlanCode;
                this.insProductPlan = this._inputPayload.insuranceQues.insProductPlan;
                this.QuestionList = this._inputPayload.insuranceQues.insPlanQueSets;
                this.SelectedPlanDetails = this._inputPayload.selectedPlanDetails;
                this.InsuredCount = this._inputPayload.insuredCount;
                if (mtResponse.userInput) {
                    this.QuestionnaireUserInput = mtResponse.userInput.responseTemplate;
                }
            }
        });
    }
    // Mark Task As Complete
    private markTaskComplete(payload: any, taskName: string) {
        this.showLoader = true;
        this.ErrorMessage = null;
        this._activitiHandler.MarkTaskAsCompleted(payload, taskName).subscribe((mtResponse: ActivitiModel.MTResponse<any>) => {
            this.showLoader = false;
            if (!mtResponse.errorBean) {
                if (mtResponse.nextTaskKey === 'healthExtraCareRejectPopup') {
                    this.getModalDirectiveInstanceBasedOnId(this.ContentPopup.Id).show();
                } else {
                    this._routerService.RouteToNextTask(mtResponse.nextTaskKey);
                }
            } else {
                this.ErrorMessage = CommonConstants.DEFAULT_ERROR_MESSAGE;
            }
        });
    }
}
