declare module Model {
    export interface MedicalDeclarationInputPayload {
        insuranceQues: Model.InsuranceQues;
        healthPlanDetails: Model.HealthPlanDetails;
        selectedPlanDetails?: Model.SelectedPlanDetails;
        insuredCount?:number;
    }
    export interface InsuranceQues{
        insPlanQueSets: Model.InsuranceQuesttanaire[];
        insProductPlanCode: string;
        gender: string;
        nominee: Model.NomineeDetailsModel;
        insProductPlan: string;
        applicationId: number;
    }
    export interface NomineeDetailsModel{
        firstName: string;
        middleName?: string;
        lastName: string;
        dateOfBirth: string;
        relation: string;
    }
    export interface HealthPlanDetails{
        insuringFor: number;
        insuringForDesc: string;
        proposerDetail: Model.ProposerDetails;
        proposedSumAssuredList: number[];
        insuredDetails: Model.InsuredDetails[];
        selectedPlanDetails: Model.SelectedPlanDetails;
        applicationId: string;
        planModified: boolean;
    }
    export interface MedicalDeclarationOutputPayload {
        insProductPlan: string;
        insProductPlanCode: string;
        responseTemplate: Model.InsuranceAnswers[];
    }
    export interface InsuredDetailsModel{
        no : number;
        firstName :  string ;
        middleName ?: string;
        lastName : string ;
        birthPlace ?: string;
        dob ?: string;
        relationship : string;
        age : number;
        genderCode ?: string;
        genderDesc ?: string;
        maritalStatusCode ?: string;
        countryCode ?: string;
        height ?: string;
        weight ?: string;
        presentInIndiaFlg : boolean;
        indianPassportFlg : boolean;
        passportNum ?: string;
        passportExpdt ?: string;
        smokerFlg : boolean;
        nationalityCode ?: string;
        bmi ?: string;
        insuredDeleted : boolean;
    }
}
