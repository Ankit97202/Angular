import { Routes } from '@angular/router';
import { CommonConstants } from './common/utilities/commonConstants';
import { HomeComponent } from './home/home.component';
import { ConfigResolve } from './common/services/config.resolve.service';
import { ResumeApplicationComponent } from './resumeApplication/resumeApplication.component';
import { ExistingCustomerComponent } from './existingCustomer/existingCustomer.component';
import { CustomerLoginComponent } from './customerLogin/customerLogin.component';
import { GetQuoteFormComponent } from './getQuote/getQuoteForm/getQuoteForm.component';
export const ROUTES: Routes = [
    {
        path: CommonConstants.Routes.Home,
        component: HomeComponent,
        resolve: { config: ConfigResolve}
    },
    {
        path: CommonConstants.Routes.Application.GetQuoteForm,
        component: GetQuoteFormComponent,
        resolve: { config: ConfigResolve}
    },
     {
        path: CommonConstants.Routes.Application.Home,
        loadChildren: './applicationModule/application.module#ApplicationModule',
        resolve: { config: ConfigResolve }
    }, {
        path: CommonConstants.Routes.Verification.Home,
        loadChildren: './verificationModule/verification.module#VerificationModule',
        resolve: { config: ConfigResolve }
    }, {
        path: CommonConstants.Routes.FinalModule.Home,
        loadChildren: './finalModule/final.module#FinalModule',
        resolve: { config: ConfigResolve }
    }, {
        path: CommonConstants.Routes.ResumeApplication,
        component: ResumeApplicationComponent,
        resolve: { config: ConfigResolve},
    },
    {
        path: CommonConstants.Routes.ApplicationList,
        component: ExistingCustomerComponent,
        resolve: { config: ConfigResolve}
    },
    {
        path: CommonConstants.Routes.CustomerLogin,
        component: CustomerLoginComponent,
        resolve: { config: ConfigResolve }
    },
];