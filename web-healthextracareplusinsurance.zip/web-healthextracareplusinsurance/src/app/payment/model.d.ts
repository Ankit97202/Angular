declare module Model {
    export interface PaymentDetails {
        orderId: string;
        bagicRefNumber: string;
        paymentSuccessFlag?: boolean;
        paymentId?: string;
    }
    export interface PaymentOutputPayload {
        orderId?: string;
        paymentId?: string;
    }
    export interface PaymentObject {
        mobileNumber?: string;
        emailId?: string;
        payNowFlag?: boolean;
        applicationId?: number;
        orderId?: string;
        paymentId?: string;
        mobilenumber?:string;
        personalEmailId?: string;
        amount?:number;
    }
}
