import { Component, Input, OnChanges } from '@angular/core';
import { PaymentService } from './payment.service';
import { CookieHandlerService } from './../common/services/cookieHandler.service';
import { CommonConstants } from './../common/utilities/commonConstants';
import { ActivitiHandlerService } from './../common/services/activitiHandler.service';
import { RouteHandlerService } from './../common/services/routeHandler.service';
import { environment } from '../../environments/environment';
import { Formatter } from '../common/services/formatter';
declare var Razorpay: any;
const Old_Key = 'rzp_test_aDFuTkMrVvaeEx';
@Component({
    selector: 'app-payment-link',
    templateUrl: './payment.template.html',
    styleUrls: ['./payment.style.css'],
    providers: [PaymentService]
})
export class PaymentComponent implements OnChanges {
    @Input() public PaymentObject: Model.PaymentObject;
    @Input() public ButtonName: string;
    public Amount: number;
    // Private Variables
    private _paymentObject;
    private _orderId: string;
    private _bagicRefNum: string;
    private _mobileNumber: string;
    private _emailId: string;
    public PaymentClosed: boolean;
    public PaymentIdReceived = false;
    public MainLoadingText = 'Stay with us. We\'re almost done...';
    // Constructor
    constructor(
        public formatter: Formatter,
        private _paymentService: PaymentService,
        private _cookieHandlerService: CookieHandlerService,
        private _activitiHandler: ActivitiHandlerService,
        private _routerService: RouteHandlerService
    ) { }
    // On Component Init
    public ngOnChanges() {
        this.addPaymentScript();
        this.setValues();
    }
    public PayByRazorPay(event) {
        this.getPaymentDetails();
        this.PaymentIdReceived = true;
    }
    // Setting Payment Input Object
    private setValues() {
        if (this.PaymentObject) {
            this.Amount = this.PaymentObject.amount;
            this._mobileNumber = this.PaymentObject.mobileNumber;
            this._emailId = this.PaymentObject.emailId;
        } else {
            console.error('ERROR:: No payment object received.');
        }
    }
    // Adding Razorpay JS to the file
    private addPaymentScript() {
        const path = 'https://checkout.razorpay.com/v1/checkout.js';
        const scriptTag = document.createElement('script');
        scriptTag.setAttribute('src', path);
        scriptTag.setAttribute('type', 'text/javascript');
        document.body.appendChild(scriptTag);
    }
    // Creating Payment Object
    private createPaymentObject() {
        this._paymentObject = {
            key: environment['PaymentKey'],
            amount: (this.Amount * 100), // 2000 paise = INR 20
            name: 'Bajaj Finserv Direct Ltd',
            description: 'Insurance Premium',
            image: null,
            handler: (response) => {
                console.log(response);
                const payload: Model.PaymentOutputPayload = {
                    orderId: this._orderId,
                    paymentId: response.razorpay_payment_id
                };
                this.PaymentIdReceived = false;
                this.markTaskComplete(payload, '');
            },
            prefill: {
                contact: this._mobileNumber,
                email: this._emailId
            },
            modal: {
                escape: false,
                ondismiss: (response) => {
                    const payload: Model.PaymentObject = {
                        applicationId: null,
                        orderId: this._orderId,
                        paymentId: null,
                        mobilenumber: this._mobileNumber,
                        personalEmailId: this._emailId,
                        amount: this.Amount
                    };
                    this.PaymentClosed = true;
                    this.markTaskComplete(payload, 'paymentClosed');
                }
            },
            order_id: this._orderId,
            theme: {
                color: '#034263'
            }
        };
    }
    private getPaymentDetails() {
        const appId = this._cookieHandlerService.GetCookie(CommonConstants.CookieKeys.LoanApplicationId);
        if (appId) {
            const data = {
                payNowFlag: this.PaymentObject.payNowFlag
            };
            this._paymentService.GetPaymentDetails(appId, data).subscribe((mtResponse: ActivitiModel.MTResponse<Model.PaymentDetails>) => {
                if (!mtResponse.errorBean) {
                    this._orderId = mtResponse.payload.orderId;
                    this._bagicRefNum = mtResponse.payload.bagicRefNumber;
                    const paymentFlag = mtResponse.payload.paymentSuccessFlag;
                    if (!paymentFlag) {
                        this.createPaymentObject();
                        const razorPayObj = new Razorpay(this._paymentObject);
                        razorPayObj.open();
                    } else {
                        const payload: Model.PaymentOutputPayload = {
                            orderId: this._orderId,
                            paymentId: mtResponse.payload.paymentId
                        };
                        this.markTaskComplete(payload, '');
                    }
                } else {
                    setInterval(() => {
                        this.PaymentIdReceived = false;
                    }, 1000);
                }
            });
        } else {
            console.error('ERROR::Unable to find application Id.');
        }
    }
    private markTaskComplete(data: Model.PaymentOutputPayload, actionName: string) {
        this._activitiHandler.MarkTaskAsCompleted(data, actionName).subscribe((mtResponse: ActivitiModel.MTResponse<any>) => {
            if (!mtResponse.errorBean) {
                this._routerService.RouteToNextTask(mtResponse.nextTaskKey, null, null, true);
            }
            location.reload();
        });
    }
}