import { Component, OnInit, Input } from '@angular/core';
import { FormValidator } from './../common/services/formValidator.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonConstants } from '../common/utilities/commonConstants';
import { ConfigService } from '../common/services/config.service';
import { HttpInterceptor } from '../common/services/httpInterceptor.service';
import { CookieHandlerService } from '../common/services/cookieHandler.service';
import { Formatter } from '../common/services/formatter';
import { ActivitiHandlerService } from '../common/services/activitiHandler.service';
import { RouteHandlerService } from '../common/services/routeHandler.service';
import { SharedService } from '../common/services/sharedService';
import { AnalyticsService } from '../common/services/device.analytics.service';
const ErrorCodes = {
    InvalidMobileOTP: 'InvalidMobileOTP',
    RetryExhausted: 'RetryExhausted'
};
const DOB_DATE_RANGES = {
    MaxAge: 70,
    MinAge: 18
};
@Component({
    selector: 'app-resume-application',
    templateUrl: './resumeApplication.template.html',
    styleUrls: ['./resumeApplication.style.css']
})
export class ResumeApplicationComponent implements OnInit {
    @Input() public ParamObj;
    public ResumeApplicationForm: FormGroup;
    public MobileNumber: string;
    public DateOfBirth: string;
    public IsErrorOTP: boolean;
    public IsServiceFailure: boolean;
    public ResendOtpExceedFlag: boolean;
    public OTPFieldVisibility: boolean;
    public WrongOtpMsg: string;
    public ServiceOTPError: string;
    public incorrectOTP = 0;
    private outputPayload = {};
    public OTPResend = 0;
    private year: string;
    private month: string;
    private day: string;
    public IsOTPResend = false;
    public MobileOtpTrails = 0;
    public DOBCustomError: string;
    public IsCorrectMobile: string = null;
    public ServiceError :string;
    constructor(
        public FormValidators: FormValidator,
        private _formBuilder: FormBuilder,
        private _httpInterceptor: HttpInterceptor,
        private _cookieHandler: CookieHandlerService,
        private _formatter: Formatter,
        private _activitiHandler: ActivitiHandlerService,
        private _routerService: RouteHandlerService,
        private _sharedService: SharedService,
        private _analyticsService: AnalyticsService
    ) { }
    // On Page Init
    public ngOnInit() {
        this.buildResumeApplicationForm();
        this.autoPopulateFields();
    }
    // Disabling Event
    public IsPaste(event) {
        event.preventDefault();
    }
    public SendMobileOTP(): void {
        if (this.ParamObj) {
            this.getOTP(this.onOTPReceived);
        } else {
            this.initProcess(() => {
                this.getOTP(this.onOTPReceived);
            });
        }
    }
    public ResendOTP(formValue: FormData) {
        this.IsOTPResend = false;
        if (this.OTPResend === 4) {
            this.OTPResend = 5;
            this.IsOTPResend =true; 
        }
        if (this.OTPResend !== 5) { //TODO - Need to change logic in future -Hema temp change         
        this.getOTP(this.onResendOTPReceived);
        this.IsOTPResend = true;
        this.OTPResend++;
        }
    }
    public NavigateToView() {
        this.IsOTPResend = false;
        const outputPayload = this.createPayload();
        if (this.MobileOtpTrails >= 5) {
            return;
        }
        this._httpInterceptor.Post(ConfigService.getInstance()
            .getConfigObject().APIURL.resumeSendOtp, outputPayload)
            .subscribe((mtResponse: ActivitiModel.MTResponse<any>) => {
                if (!mtResponse.errorBean) {
                    this.setUserAuthToken(mtResponse.payload);
                    this._cookieHandler.SetCookie(
                        CommonConstants.CookieKeys.JourneyType,
                        'Resume'
                    );
                    const activitiPayload = this.getFormValuesAsPayload(true);
                    this._activitiHandler.MarkTaskAsCompleted(activitiPayload, 'resume')
                        .subscribe((resp) => {
                            this.onActivitSuccess(resp);
                        });
                }
                else if(CommonConstants.errorCodes.includes(mtResponse.errorBean[0].errorCode)){
                    this.MobileOtpTrails++;
                    this. ServiceOTPError = mtResponse.errorBean[0].errorMessage;
                }
                 else {
                    this.MobileOtpTrails++;
                    this.WrongOtpMsg = 'Please provide a valid OTP.';
                }
            });
    }
    // Validate Mobile Number
    public ValidateMobile() {
        const mobileNo = this.ResumeApplicationForm
            .controls['mobile'].value;
        const test = /(\d)\1{9}/g;
        if (mobileNo && !this.FormValidators.FieldHasErrors(
            this.ResumeApplicationForm, 'mobile')) {
            if (mobileNo[0] === '6' || mobileNo[0] === '7' || mobileNo[0] === '8' || mobileNo[0] === '9') {
                this.IsCorrectMobile = null;
            } else {
                this.IsCorrectMobile = 'Mobile number should start with 6, 7, 8, 9';
            }
            if (mobileNo.match(test)) {
                this.IsCorrectMobile = 'Please provide valid mobile number.';
            }
        } else {
            this.IsCorrectMobile = null;
        }
    }
    public ValidateDOB() {
        const formData = this.ResumeApplicationForm.value;
        if (formData.day && formData.month && formData.year) {
            const DOBObj = {
                Day: formData.day,
                Month: formData.month,
                Year: formData.year
            };
            this.DOBCustomError = this.FormValidators.IsDateOfBirthValid(DOBObj, null, DOB_DATE_RANGES.MinAge, DOB_DATE_RANGES.MaxAge);
        }
    }
    public NextFocus(curr, next): void {
        setTimeout(() => {
            const val = curr['value'] || '';
            if (val.length >= 2) {
                next.focus();
            }
        });
    }
    private autoPopulateFields() {
        if (this.ParamObj) {
            const DOB = (this.ParamObj.DOB) ? (this.ParamObj.DOB).split('-') : null;
            this.MobileNumber = this.ParamObj.mobileNumber;
            this.day = DOB[2];
            this.month = DOB[1];
            this.year = DOB[0];
            this.DateOfBirth = this.day + '/' + this.month + '/' + this.year;
            if (this.ParamObj.OTP) {
                this.OTPFieldVisibility = true;
                this.ResumeApplicationForm.patchValue({ otp: this.ParamObj.OTP });
            }
        }
    }
    // Building Form Group
    private buildResumeApplicationForm() {
        this.ResumeApplicationForm = this._formBuilder.group({
            mobile: ['', Validators.compose([Validators.required])],
            day: ['', Validators.compose([Validators.required])],
            month: ['', Validators.compose([Validators.required])],
            year: ['', Validators.compose([Validators.required, Validators.pattern('[0-9]{4}$')])],
            otp: ['', Validators.compose([Validators.required])],
        });
        this.ResumeApplicationForm.controls['day'].valueChanges.subscribe(() => {
            this.DOBCustomError = null;
        });
        this.ResumeApplicationForm.controls['month'].valueChanges.subscribe(() => {
            this.DOBCustomError = null;
        });
        this.ResumeApplicationForm.controls['year'].valueChanges.subscribe(() => {
            this.DOBCustomError = null;
        });
        this.ResumeApplicationForm.controls['mobile'].valueChanges.subscribe(() => {
            this.IsCorrectMobile = null;
        });
        this.ResumeApplicationForm.valueChanges.subscribe((updatedValue) => {
            this.WrongOtpMsg = null;
        });
    }
    private createPayload() {
        const _outputPayload = {};
        if (this.ParamObj) {
            _outputPayload['mobile'] = this.MobileNumber;
            _outputPayload['otp'] = this.ResumeApplicationForm.controls['otp'].value;
            _outputPayload['dateOfBirth'] = this.year + '-' + this.month + '-' + this.day;
            _outputPayload['source'] = CommonConstants.SourceTypes.Journey;
            _outputPayload['productCode'] = CommonConstants.LOAN_PRODUCT_CATEGORY_CODES.Health_ExtraInsurance;
            _outputPayload['insProductType'] = CommonConstants.LOAN_PRODUCT_CODES.Health_ExtraInsurance;
            return _outputPayload;
        } else {
            _outputPayload['mobile'] = this.ResumeApplicationForm.controls['mobile'].value;
            _outputPayload['otp'] = this.ResumeApplicationForm.controls['otp'].value;
            const dob = this.ResumeApplicationForm.controls['year'].value + '-' +
                this.ResumeApplicationForm.controls['month'].value + '-' +
                this.ResumeApplicationForm.controls['day'].value;
            _outputPayload['dateOfBirth'] = dob;
            _outputPayload['source'] = CommonConstants.SourceTypes.Journey;
            _outputPayload['productCode'] = CommonConstants.LOAN_PRODUCT_CATEGORY_CODES.Health_ExtraInsurance;
            _outputPayload['insProductType'] = CommonConstants.LOAN_PRODUCT_CODES.Health_ExtraInsurance;
            return _outputPayload;
        }
    }
    private getFormValuesAsPayload(isActivityCall?: boolean) {
        const outputPayload = {};
        let dob: string;
        if (this.ParamObj) {
            if (isActivityCall) {
                dob = this.year + '-' + this.month + '-' + this.day;
            } else {
                dob = this.day + '-' + this.month + '-' + this.year;
            }
            outputPayload['mobile'] = this.MobileNumber;
            outputPayload['dateOfBirth'] = dob;
            outputPayload['productCode'] = CommonConstants.LOAN_PRODUCT_CATEGORY_CODES.Health_ExtraInsurance;
            outputPayload['insProductType'] = CommonConstants.LOAN_PRODUCT_CODES.Health_ExtraInsurance;
            return outputPayload;
        } else {
            outputPayload['mobile'] = this.ResumeApplicationForm.controls['mobile'].value;
            outputPayload['otp'] = this.ResumeApplicationForm.controls['otp'].value;
            if (isActivityCall) {
                dob = this.ResumeApplicationForm.controls['year'].value + '-' +
                    this.ResumeApplicationForm.controls['month'].value + '-' +
                    this.ResumeApplicationForm.controls['day'].value;
                outputPayload['dateOfBirth'] = dob;
            } else {
                dob = this.ResumeApplicationForm.controls['day'].value + '-' +
                    this.ResumeApplicationForm.controls['month'].value + '-' +
                    this.ResumeApplicationForm.controls['year'].value;
                outputPayload['dateOfBirth'] = dob;
            }
            outputPayload['productCode'] = CommonConstants.LOAN_PRODUCT_CATEGORY_CODES.Health_ExtraInsurance;
            outputPayload['insProductType'] = CommonConstants.LOAN_PRODUCT_CODES.Health_ExtraInsurance;
            return outputPayload;
        }
    }
    private setUserAuthToken(responseData: any) {
        if (responseData) {
            this._cookieHandler.SetCookie(CommonConstants.CookieKeys.JWToken,
                responseData.tokens[0].token);
            this._cookieHandler.SetCookie(CommonConstants.CookieKeys.GuardKey,
                responseData.tokens[0].guardKey);
            this._cookieHandler.SetCookie(CommonConstants.CookieKeys.GuardToken,
                this._formatter
                    .ConvertGuradKeyToGuardToken(
                        responseData.tokens[0].guardKey));
        }
    }
    private onActivitSuccess(mtResponse: ActivitiModel.MTResponse<any>) {
        if (mtResponse.errorBean) {
            mtResponse.errorBean.forEach(
                (item: { errorCode: string, errorMessage: string }, index: number) => {
                    if (item.errorCode === ErrorCodes.InvalidMobileOTP) {
                        this.IsErrorOTP = true;
                    } else if (item.errorCode !== ErrorCodes.RetryExhausted) {
                        this.IsServiceFailure = true;
                    }
                });
        } else {
            this._routerService.RouteToNextTask(mtResponse.nextTaskKey);
        }
    }
    private onResendOTPReceived(mtResponse: ActivitiModel.MTResponse<any>) {
        if (mtResponse.errorBean) {
            this.IsServiceFailure = true;
        }
    }
    private onOTPReceived(mtResponse: ActivitiModel.MTResponse<any>) {
        if (!mtResponse.errorBean) {
            this.OTPFieldVisibility = true;
        }
    }
    private getOTP(callback): void {
        this.outputPayload = this.getFormValuesAsPayload();
        this.outputPayload['otp'] = CommonConstants.DEFAULT_EMPTY_STRING;
        this.outputPayload['source'] = CommonConstants.SourceTypes.Journey;
        this._httpInterceptor.Post(ConfigService.getInstance()
            .getConfigObject().APIURL.resumeGetOtp, this.outputPayload)
            .subscribe((response) => {
                if(!response.errorBean)   
                  callback.call(this, response);
                else if(CommonConstants.errorCodes.includes(response.errorBean[0].errorCode))
                {
                    this.IsOTPResend =false;
                     this.ServiceError = response.errorBean[0].errorMessage; 
                }
            });
    }
    private initProcess(onSuccessCallback: Function) {
        const productCode = this._sharedService.getData(
            CommonConstants.QueryParamsKeys.Productcode); // this.getProductCode();
        this.startActivitiWithApplicationCreate(
            productCode,
            CommonConstants.LOAN_PRODUCT_CATEGORY_CODES.Health_ExtraInsurance,
            (mtResponse: Model.MTResponse<any>) => {
                onSuccessCallback(mtResponse);
            });
    }
    private startActivitiWithApplicationCreate(
        loanProduct: string,
        productCategoryCode: string,
        onSuccessCallback: Function,
        calculatorProductType?: number,
        isLocationProvided?: boolean) {
        const startActivitiRequest: any = {
            activitiName: 'startFlow',
            payload: this.getApplicationCreateRequest(
                loanProduct, productCategoryCode, calculatorProductType, isLocationProvided)
        };
        this.startActiviti(startActivitiRequest, onSuccessCallback);
    }
    private getApplicationCreateRequest(
        LoanProduct: string,
        ProductCategoryCode: string,
        CalculatorProductType?: number,
        IsLocationProvided?: boolean) {
        let mediumFromWeb = this._sharedService.getData(CommonConstants.QueryParamsKeys
            .appUtmMedium);
        const medium = 'Webengage_repeat_visitor_finance_homepage_PL_apply_online_link';
        if (mediumFromWeb !== '' && typeof (mediumFromWeb) !== 'object') {
            mediumFromWeb = this.CheckUtmMediumForDevice(
                this._sharedService.getData(CommonConstants.QueryParamsKeys
                    .appUtmMedium).toString());
        } else if (mediumFromWeb !== '') {
            mediumFromWeb = this.CheckUtmMediumForDevice(medium);
        } else {
            mediumFromWeb = this.CheckUtmMediumForDevice(mediumFromWeb);
        }
        return {
            appJourneyStamp: 'journeyStamp',
            appSource: 'Browser',
            appStatus: 0,
            bflBranch: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.BFLBranch)) || '320',
            productCategoryCode: ProductCategoryCode,
            insuranceApplications: {
                insProduct: CommonConstants.LOAN_PRODUCT_CODES.Health_ExtraInsurance
            },
            appUtmRefCode: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.appUtmRefCode)) || '',
            appUtmSource: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.appUtmSource)) || 'Organic',
            appUtmMedium: mediumFromWeb || medium,
            appUtmCampaign: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.appUtmCampaign)) || '',
            appUtmTerm: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.appUtmTerm)) || '',
            appUtmContent: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.appUtmContent)) || '',
            gclId: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.GCLID))
                || 'EAIaIQobChMIsZGIyZn01AIV1IdoCh19HAKqEAAYASAAEgKWjfD_BwE',
            applicantId: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.ApplicantId)) || '',
            applicationId: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.ApplicationId)) || '',
            appApplicantId: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.ApplicationApplicantId)) || '',
            emailQuote: false,
            resumeJourney: true
        };
    }
    private checkUtmSources(utmObj) {
        if (Object.keys(utmObj).length !== 0) {
            return utmObj;
        } else {
            return false;
        }
    }
    private CheckUtmMediumForDevice(value: string) {
        const deviceDetails: DeviceDetails = this._analyticsService.GetDeviceDetails();
        if (deviceDetails.mobile) {
            value = value.concat('_mobile');
        }
        return value;
    }
    private startActiviti(request: any, onSuccessCallback: Function) {
        this._activitiHandler.StartActiviti(request, true)
            .subscribe((data: ActivitiModel.ActivitiResponse) => {
                console.log('Raw Activiti working now');
                if (!data.errorBean) {
                    this._cookieHandler.SetCookie(CommonConstants.CookieKeys.LoanApplicationId,
                        data.payload.applicationKey);
                    this._cookieHandler.SetCookie(CommonConstants.CookieKeys.ProcessInstanceDetails,
                        data.payload.processInstanceDetails);
                    this._cookieHandler.SetCookie(CommonConstants.CookieKeys.LoanApplicationKey,
                        data.payload.loanApplicationKey);
                    onSuccessCallback(data);
                }
            },
                (Error) => {
                    console.log(Error);
                });
    }
}