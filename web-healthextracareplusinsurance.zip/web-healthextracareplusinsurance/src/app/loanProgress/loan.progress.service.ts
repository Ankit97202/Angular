import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
@Injectable()
export class LoanProgressService {
    constructor() {// empty
    }
    public GetProgressData(): Observable<any> {
        let progressData: any = {
            payload: [{
                name: 'Get Eligibility',
                active: true,
                value: 25
            }, {
                name: 'Design your product',
                active: false,
                value: 0
            },
            {
                name: 'Verification',
                active: false,
                value: 0
            },
            {
                name: 'E-Sign',
                active: false,
                value: 0
            }],
            status: 'SUCCESS',
            errorBean: null
        };
        return Observable.of(progressData);
    }
}
