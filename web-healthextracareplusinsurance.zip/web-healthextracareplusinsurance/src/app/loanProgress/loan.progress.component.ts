import { Component, Input, OnInit, OnChanges } from '@angular/core';
import { LoanProgressService } from './loan.progress.service';
@Component({
    selector: 'app-loan-progress',
    templateUrl: './loan.progress.template.html',
    providers: [LoanProgressService],
    styleUrls: ['./loan.progress.style.css']
})
export class LoanProgressComponent implements OnChanges {
    public SubstagePayload = [
    {
        name: 'Get Started',
        subStage: [
            { index: 0, progress: 20 },
            { index: 1, progress: 40 },
            { index: 2, progress: 60 },
            { index: 3, progress: 80 },
            { index: 4, progress: 100}
        ],
        icon: './assets/img/svg/Get_Started_Get_Started.svg'
    }, {
        name: 'Verify Me',
        subStage: [
            { index: 0, progress: 10 },
            { index: 1, progress: 45 },
            { index: 2, progress: 100 }
        ],
        icon: './assets/img/svg/Bajaj_Icon-03.svg'
    }, {
        name: 'Close The Deal',
        subStage: [],
        icon: './assets/img/svg/Bajaj_Icon_Close_Deal.svg'
    }];
    public LoanProgressState: Model.ProgressStateInfo[];
    @Input() public progressState;
    public ProgressPayload = [];
    constructor(private _loanProgressService: LoanProgressService) { }
    public ngOnChanges(changes: any): void {
        console.log('ngOnChange for Progress State');
        this.LoanProgressState = this.progressState;
        this.mergePayload();
    }
    private mergePayload() {
        this.ProgressPayload = [];
        for (let i = 0; i < this.SubstagePayload.length; i++) {
            for (let j = 0; j < this.LoanProgressState.length; j++) {
                if (i === j) {
                    this.ProgressPayload.push({
                        name: this.SubstagePayload[i].name,
                        active: this.LoanProgressState[i].active,
                        value: this.LoanProgressState[i].value,
                        subStage: this.SubstagePayload[i].subStage,
                        icon: this.SubstagePayload[i].icon
                    });
                } else {
                    continue;
                }
            }
        }
    }
}
