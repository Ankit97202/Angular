import { Component, OnInit } from '@angular/core';
import { CommonConstants } from '../common/utilities/commonConstants';
@Component({
    selector: 'customFooter',
    templateUrl: './footer.template.html',
    styleUrls: ['./footer.style.css']
})
export class FooterComponent {
    public footerText = CommonConstants.footerText;
}
