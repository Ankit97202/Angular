import { Component, Input, EventEmitter, OnChanges, Output, OnInit, QueryList, ViewChildren } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, ValidatorFn } from '@angular/forms';
import { FormValidator } from '../../common/services/formValidator.service';
import { Formatter } from '../../common/services/formatter';
import { CommonConstants } from 'src/app/common/utilities/commonConstants';
import { NgxBootstrapSliderModule } from 'ngx-bootstrap-slider';
import { PopupComponent } from '../../common/utilities/popup/popup.component';
import { convertToDoubleDigit } from '../../common/utilities/pipes/DoubleDigit.pipe';
import { ActivitiHandlerService } from '../../common/services/activitiHandler.service';
import { CookieHandlerService } from '../../common/services/cookieHandler.service';
import { RouteHandlerService } from '../../common/services/routeHandler.service';
import { NullTemplateVisitor } from '@angular/compiler';
import { SELECTOR } from 'ngx-bootstrap/modal/modal-options.class';
import { ToastrManager } from 'ng6-toastr-notifications';
import { addSpaceToDigit } from '../../common/utilities/pipes/SpacePipe.pipe';
import { FooterComponent } from '../../footer/footer.component';
import { PersoanlDetailsService } from 'src/app/applicationModule/personalDetails/personalDetailsForm/personalDetails.service';
function RangeValidator(min: Number, max: Number): ValidatorFn {
    return (control: FormControl): { [key: string]: any } => {
        const input = Number(control.value);
        return (input > max || input < min) ?
            {
                'RangeError': `Age should be between ${min < 1 ? (Number(min) * 12)
                    : (min)} - ${max} Years`
            } : null;
    };
}
const ageRanges = {
    entry: {
        adult: { min: 18, max: 80 },
        child: { min: 0, max: 25 }
    },
    renewable: {
        adult: { min: 18, max: 100 },
        child: { min: 0.25, max: 35 }
    }
};
@Component({
    selector: 'app-get-quote-form',
    templateUrl: './getQuoteForm.template.html',
    styleUrls: ['./getQuoteForm.style.css'],
})
export class GetQuoteFormComponent implements OnInit {
    value = 0;
    isOpened: boolean;
    editFlag: boolean;
    public showLoader = false;
    @ViewChildren(PopupComponent) public PopupComponent: QueryList<any>;
    public ContentPopup;
    public AggregatePopup;
    public AirAmbPopup;
    public GetQuoteFormGroup: FormGroup;
    public IndividialRelationFormGroup: FormGroup;
    public FamilyRelationFormGroup: FormGroup;
    public InsuredData = [{ relationDesc: 'Self' },
    { relationDesc: 'Spouse' },
    { relationDesc: 'Father' },
    { relationDesc: 'Mother' },
    { relationDesc: 'Son' },
    { relationDesc: 'Daughter' }];
    public InsuredForText: string;
    public Config = { show: false, backdrop: 'static' };
    public GetInsuranceDetails: any;
    public GetInsuredDetails: any;
    public GetrecommendedPlans: GetQuoteModel.RecommendedPlans;
    public GetProductFeatures: GetQuoteModel.ProductFeatures[];
    public BuynowPlans: GetQuoteModel.BuynowPlans;
    public SelectedPlanDetails: GetQuoteModel.SelectedPlanDetails;
    public ModifiedBuynowPlans: any;
    public IsEnabled = false;
    public AgreegatedeductibleAmount: any = '';
    public planCode: any;
    public minSliderValue: number;
    public maxSliderValue: number;
    public tickArraywithL: any[] = [];
    public tickArray: any[] = [];
    public defaultValue;
    public AirAmbulanceSelected: boolean;
    public TotalPremium: any = '';
    public SelectedValueOnSlider: number;
    public SliderStep: number;
    public EmailFormGroup: FormGroup;
    public ReponsePlanDetails: any;
    public tickPositionArray: any[] = [];
    public GetQuoteSliderFormGroup: FormGroup;
    public planDetails: any;
    public AirAmbulanceSelectedValue: string;
    public ErrorMessage: string = CommonConstants.DEFAULT_EMPTY_STRING;
    public IsGetQuoteFailed = false;
    public domainInvalid = true;
    public PriceTampering: string;
    // Constructor
    constructor(
        public FormValidators: FormValidator,
        public toastr: ToastrManager,
        public formatter: Formatter,
        private _formBuilder: FormBuilder,
        private _activitiHandler: ActivitiHandlerService,
        private _cookieHandler: CookieHandlerService,
        private _routerService: RouteHandlerService,
        private _persoanlDetailsService: PersoanlDetailsService
    ) {
        this.isOpened = false;
    }
    public onSelect() {
        if (this.isOpened) {
            this.isOpened = false;
        } else {
            this.isOpened = true;
        }
    }
    // On Component Init
    public ngOnInit() {
        this.buildGetQuoteForm();
        this.buildFamilyFormGroup();
        this.buildEmailQuoteGroup();
        this.getTaskDetails();
    }
    // Show Modal Popup
    public ShowChildModal(id: string, contentType?: string): void {
        if (contentType) {
            this.initContentPopup();
        }
        this.getModalDirectiveInstanceBasedOnId(id).show();
    }
    private _mergeInsuredData(data, preData = {}) {
        return { ...data, ...preData };
    }
    public UpdateInsuredFor(id: string) {
        const val = this.IndividialRelationFormGroup.value;
        let insuredDetails = this.GetInsuredDetails;
        const children = { Son: 0, Daughter: 0 };
        insuredDetails = insuredDetails.map((ind) => {
            const relation = ind.relationship.charAt(0) + ind.relationship.slice(1).toLowerCase();
            const age = Array.isArray(val[relation]) ? val[relation][children[relation]++] : val[relation];
            ind.age = (age !== null ? age : ind.age);
            ind.insuredDeleted = (age === null || age === undefined);
            Array.isArray(val[relation]) ? delete val[relation][children[relation] - 1] : delete val[relation];
            return ind;
        });
        for (const relation in val) {
            if (val[relation]) {
                if (Array.isArray(val[relation])) {
                    insuredDetails.push(
                        ...val[relation]
                            .filter(v => !!v)
                            .map((ind, index) => ({
                                relationship: relation.toUpperCase(), age: val[relation][index],
                                dob: null, no: null, insuredDeleted: false
                            }))
                    );
                } else {
                    insuredDetails.push({
                        relationship: relation.toUpperCase(), age: val[relation],
                        dob: null, no: null, insuredDeleted: false
                    });
                }
            }
        }
        this.GetInsuredDetails = insuredDetails.map(ind => ({ ...ind, age: Number(ind.age) }));
        this.markTaskComplete({
            insuredDetails: this.GetInsuredDetails
        }, 'editMemebers', false, () => {
            this.getTaskDetails(() => { this.HideChildModal(id) });
        });
        this.IsEnabled = false;
    }
    // Hide Modal Popup
    public HideChildModal(id: string): void {
        this.getModalDirectiveInstanceBasedOnId(id).hide();
    }
    public onIncr(data, age) {
        const newControl = new FormControl(age, Validators.compose([Validators.required,
        RangeValidator(ageRanges.entry.child.min, ageRanges.entry.child.max)]));
        const ctrl = this.IndividialRelationFormGroup.get(data.relationDesc);
        ctrl['push'](newControl);
        this.setFocus(data.relationDesc + ctrl['controls'].findIndex(cctrl => cctrl.invalid));
    }
    public onDecr(data) {
        const ctrl = this.IndividialRelationFormGroup.get(data.relationDesc);
        ctrl['removeAt'](ctrl['controls'].length - 1);
        this.setFocus(data.relationDesc + ctrl['controls'].findIndex(cctrl => cctrl.invalid));
    }
    public showSuccess() {
        this.toastr.successToastr('The quote has been mailed to your id', ' ', { showCloseButton: true });
    }
    public showToast(position: any = 'top-right') {
        this.toastr.infoToastr('Email Quote', 'EQ', {
            position: position
        });
    }
    private setFocus(id) {
        setTimeout(() => {
            (document.getElementById(id) || { focus: () => { } }).focus();
        });
    }
    private setFocusandRefresh(id) {
        setTimeout(() => {
            (document.getElementById(id) || { focus: () => { } }).focus();
        });
    }
    public doubleDigit(input) {
        this.IndividialRelationFormGroup.get(input).setValue(
            convertToDoubleDigit(this.IndividialRelationFormGroup.get(input).value));
    }
    public BuyNow() {
        this.PrepareBuyNowPayload(this.ReponsePlanDetails, 'buynow');
        this.markTaskComplete(this.BuynowPlans, null);
    }
    public onCheck(relation: string) {
        const value = this.IndividialRelationFormGroup.value;
        const count =
            ['Self', 'Spouse', 'Mother', 'Father'].reduce((accum, val) => accum + (value[val] === null ? 0 : 1), 0) +
            ['Son', 'Daughter'].reduce((accum, val) => accum + (value[val].length), 0);
        let proceed = 6 > count;
        const formCtrl = this.IndividialRelationFormGroup.get(relation);
        if (['Son', 'Daughter'].includes(relation)) {
            if (!this.IndividialRelationFormGroup.get(relation)['controls'].length) {
                const childCount = ['Son', 'Daughter'].reduce((accum, val) => accum + (value[val].length), 0);
                if (proceed)
                    proceed = 4 > childCount;
                if (!proceed) { return; }
                this.onIncr({ relationDesc: relation }, null);
                return;
            }
            Array(this.IndividialRelationFormGroup.get(relation)['controls'].length).fill(null)
                .forEach(_ => this.onDecr({ relationDesc: relation }));
            return;
        }
        if (formCtrl.value === null && !proceed) { return; }
        formCtrl.setValue(formCtrl.value !== null ? null : '');
        setTimeout(() => {
            if (formCtrl.value !== null) {
                document.getElementById(relation).focus();
                formCtrl.setValidators([Validators.required, RangeValidator(ageRanges.entry.adult.min, ageRanges.entry.adult.max)]);
            } else {
                formCtrl.clearValidators();
            }
            formCtrl.updateValueAndValidity();
            const toBeFocused = this.InsuredData.find(ind => this.IndividialRelationFormGroup.get(ind.relationDesc).invalid);
            if (toBeFocused) {
                this.setFocus(toBeFocused.relationDesc);
            }
        });
    }
    /*Changing Insurance Preminum Data On Slider Change*/
    public OnSliderStart($event) {
        this.stepCalculation(this.SelectedValueOnSlider);
        const availablePlans = this.GetrecommendedPlans.sumAssuredList;
        for (const plan of availablePlans) {
            const sumAssuredToCompare = this.formatter.ConvertNumberToAmountExtraPlus(plan.sumAssured);
            if (sumAssuredToCompare === this.SelectedValueOnSlider && this.GetQuoteFormGroup.controls['eiaAccountFlag'].value === 'Y') {
                this.TotalPremium = plan.totalGrossPremium;
                this.AgreegatedeductibleAmount = plan.agreegatedDed;
                this.prepareSelectedPlanDetails(plan);
                break;
            } else if (sumAssuredToCompare === this.SelectedValueOnSlider &&
                this.GetQuoteFormGroup.controls['eiaAccountFlag'].value === 'N') {
                this.TotalPremium = plan.grossPremium;
                this.AgreegatedeductibleAmount = plan.agreegatedDed;
                this.prepareSelectedPlanDetails(plan);
                break;
            }
        }
    }
    public ChangePremium($event) {
        const availablePlans = this.GetrecommendedPlans.sumAssuredList;
        for (const plan of availablePlans) {
            const sumAssuredToCompare = this.formatter.ConvertNumberToAmountExtraPlus(plan.sumAssured);
            if (sumAssuredToCompare === this.SelectedValueOnSlider && $event.target.value === 'Y') {
                this.TotalPremium = plan.totalGrossPremium;
                this.AgreegatedeductibleAmount = plan.agreegatedDed;
                this.SelectedValueOnSlider = sumAssuredToCompare;
                this.AirAmbulanceSelectedValue = $event.target.value;
                this.prepareSelectedPlanDetails(plan);
                break;
            } else if (sumAssuredToCompare === this.SelectedValueOnSlider && $event.target.value === 'N') {
                this.TotalPremium = plan.grossPremium;
                this.AgreegatedeductibleAmount = plan.agreegatedDed;
                this.SelectedValueOnSlider = sumAssuredToCompare;
                this.AirAmbulanceSelectedValue = $event.target.value;
                this.prepareSelectedPlanDetails(plan);
                break;
            }
        }
    }
    public ModifyPlan() {
        this.PreparePayloadForModifiedPlan(this.ReponsePlanDetails, '');
        this.markTaskComplete(this.ModifiedBuynowPlans, 'BuyPlan');
    }
    // email quote process call
    public emailQuote() {
        this.PrepareBuyNowPayload(this.ReponsePlanDetails, 'emailquote');
        this.BuynowPlans.proposerDetails.email = this.EmailFormGroup.controls['email'].value;
        this.markTaskComplete(this.BuynowPlans, 'EmailQuote');
        this.HideChildModal('email-quote');
        this.showSuccess();
    }
    public space(input) {
        if (input !== null)
            addSpaceToDigit(input);
    }
    private buildGetQuoteForm() {
        this.GetQuoteFormGroup = this._formBuilder.group({
            eiaAccountFlag: [false, [Validators.required]]
        });
    }
    private buildEmailQuoteGroup() {
        this.EmailFormGroup = this._formBuilder.group({
            email: ['', [Validators.required]]
        });
    }
    private buildGetQuoteSliderFormGroup() {
        this.GetQuoteSliderFormGroup = this._formBuilder.group({
            getQuoteSlider: [this.SelectedValueOnSlider, '']
        });
    }
    private setInsuredForText() {
        if (this.GetInsuredDetails) {
            const rels = this.GetInsuredDetails.filter(v => !v.insuredDeleted)
                .reduce((accum, e) => { accum[e.relationship] = (accum[e.relationship] || 0) + 1; return accum; }, {});
            this.InsuredForText = Object.keys(rels)
                .map(r => (rels[r] > 1 ? ` ${r} (${rels[r]}) ` : r)).join(', ').toLocaleLowerCase();
        }
    }
    public setIndividualFormGroup() {
        if (this.GetInsuredDetails) {
            const insuredDetails = this.GetInsuredDetails;
            const rangeValidator = RangeValidator(ageRanges.entry.adult.min, ageRanges.entry.adult.max);
            const childRangeValidator = RangeValidator(ageRanges.entry.child.min, ageRanges.entry.child.max);
            const d = insuredDetails.filter(ins => !['SON', 'DAUGHTER'].includes(ins.relationship))
                .reduce((accum, r) => {
                    accum[r.relationship] = r.age;
                    return accum;
                }, {});
            d['SON'] = insuredDetails.filter(ins => ins.relationship === 'SON')
                .map(ins => ([ins.age, Validators.compose([Validators.required,
                    childRangeValidator])]));

            d['DAUGHTER'] = insuredDetails.filter(ins => ins.relationship === 'DAUGHTER')
                .map(ins => ([ins.age, Validators.compose([Validators.required,
                    childRangeValidator])]));
            const basic = ['Self', 'Spouse', 'Father', 'Mother'].reduce((accum, r) => {
                accum[r] = [d[r.toUpperCase()], Validators.compose(d[r.toUpperCase()] ? [Validators.required, rangeValidator] : [])];
                return accum;
            }, {});
            const children = ['Son', 'Daughter'].reduce((accum, r) => {
                accum[r] = this._formBuilder.array(d[r.toUpperCase()]);
                return accum;
            }, {});
            this.IndividialRelationFormGroup = this._formBuilder.group({ ...basic, ...children });
        }
    }
    // Building Individual Form Group for Insured Popup
    private buildFamilyFormGroup() {
        this.FamilyRelationFormGroup = this._formBuilder.group({
            relationship: ['', Validators.compose([Validators.required])],
            noOfSons: [''],
            noOfDaughters: ['']
        });
    }
    /*Initialize Popup*/
    private initContentPopup() {
        this.ContentPopup = {
            Id: 'content-modal',
            Title: 'IFSC Code finder',
            Config: <CustomModalOptions>{ show: false, closeOption: true }
        };
        this.AggregatePopup = {
            Id: 'Agg-content-modal',
            Title: 'Aggregate Deductible',
            Config: <CustomModalOptions>{ show: false, closeOption: true }
        };
        this.AirAmbPopup = {
            Id: 'AirAm-content-modal',
            Title: 'Air Ambulance',
            Config: <CustomModalOptions>{ show: false, closeOption: true }
        };
        console.log('this.config.closeOption:', this.ContentPopup.Config.closeOption);
    }
    /* Getting Popup Instances Based on Id */
    private getModalDirectiveInstanceBasedOnId(popupId: string): any {
        return this.PopupComponent.filter((item: PopupComponent, index: number) => {
            return item.id === popupId;
        })[0].modalControl;
    }
    // Please dont change anything in this function . It will break the flow
    private getTaskDetails(cb?) {
        this._activitiHandler.GetTaskDetails().subscribe((
            mtResponse: ActivitiModel.MTResponse<any>
        ) => {
            const responsePayload = mtResponse;
            if (!mtResponse.errorBean) {
                (cb || (() => { }))();
                this.GetInsuredDetails = responsePayload.payload.insuredDetails;
                this.setInsuredForText();
                this.setIndividualFormGroup();
                if (!mtResponse.payload.errorDetails.length) {
                    this.GetProductFeatures = responsePayload.payload.productFeatures;
                    this.ReponsePlanDetails = responsePayload.payload;
                    this.GetrecommendedPlans = this.ReponsePlanDetails.recommendedPlans;
                    this.editFlag = responsePayload.payload.modifyPlan;
                    this.ErrorMessage = null;
                    this.IsGetQuoteFailed = false;
                    if (!this.IsEnabled) {
                        this.tickArray = [];
                        this.tickArraywithL = [];
                        this.tickPositionArray = [];
                        this.SelectedValueOnSlider = null;
                        this.setSlider();
                        this.setDefaultValue();
                        this.IsEnabled = true;
                    }
                } else {
                    this.ErrorMessage = mtResponse.payload.errorDetails[0].description;
                    this.IsGetQuoteFailed = true;
                }
            }
        },
            error => {
                console.error('ERROR::', error);
            }
        );
        this.setIndividualFormGroup();
    }
    // Mark Task As Complete
    private markTaskComplete(data, taskName: string, isLoader?: boolean, cb?: Function) {
        this.ErrorMessage = null;
        this._activitiHandler.MarkTaskAsCompleted(data, taskName, true).subscribe((resp: Model.MTResponse<any>) => {
            const mtResponse: Model.MTResponse<any> = resp;
            if (!mtResponse.errorBean) {
                (cb || (() => { }))();
                this._routerService.RouteToNextTask(mtResponse.nextTaskKey);
            }
            else if (mtResponse.errorBean) { //[0].errorCode === 'TINS-9977'
                this.PriceTampering = "Something went wrong. Please try after sometime"
            }
        });
    }
    private setSlider() {
        this.getMinMaxValueForSlider();
    }
    private getMinMaxValueForSlider() {
        const availablePlans = this.GetrecommendedPlans.sumAssuredList.sort();
        let min = availablePlans[0].sumAssured;
        let max = availablePlans[0].sumAssured;
        for (let i = 0, len = availablePlans.length; i < len; i++) {
            const v = availablePlans[i].sumAssured;
            min = (v < min) ? v : min;
            max = (v > max) ? v : max;
            this.tickArray.push(this.formatter.ConvertNumberToAmountExtraPlus(v));
            this.tickArraywithL.push(this.formatter.ConvertNumberToAmountExtraPlusL(v));
        }
        this.ticksPositionsCalculation(this.tickArray.length);
        this.minSliderValue = this.formatter.ConvertNumberToAmountExtraPlus(min);
        this.maxSliderValue = this.formatter.ConvertNumberToAmountExtraPlus(max);
    }
    private setDefaultValue() {
        const availablePlans = this.GetrecommendedPlans.sumAssuredList;
        for (const plan of availablePlans) {
            if (plan.selected === 'Y') {
                if (plan.riders[0].selected === 'N')
                    this.TotalPremium = plan.grossPremium;
                else
                    this.TotalPremium = plan.totalGrossPremium;
                this.defaultValue = this.formatter.ConvertNumberToAmountExtraPlus(plan.sumAssured);
                this.GetQuoteFormGroup.patchValue({ 'eiaAccountFlag': plan.riders[0].selected });
                this.AgreegatedeductibleAmount = plan.agreegatedDed;
                this.SelectedValueOnSlider = this.defaultValue;
                this.prepareSelectedPlanDetails(plan);
                break;
            }
        }
        this.stepCalculation(this.SelectedValueOnSlider);
    }
    //Calculation to set value on slider to ticks position if user selcted value other available plans
    private stepCalculation(sliderValues: any) {
        let indexOfDefaultValue;
        let positionType;
        let previousValue = 0;
        let count: number = 1;
        previousValue = +this._cookieHandler.GetCookie('PreviousValue');
        if (previousValue === null)
            this._cookieHandler.SetCookie('PreviousValue', this.SelectedValueOnSlider);
        if (previousValue < sliderValues)
            positionType = 'INCREASE'
        else if (previousValue > sliderValues)
            positionType = 'DECREASE'
        switch (positionType) {
            case 'INCREASE':
                indexOfDefaultValue = this.tickArray.indexOf(sliderValues);
                if (indexOfDefaultValue === -1) {
                    while (this.tickArray.indexOf(this.SelectedValueOnSlider) < 1) {
                        this.SelectedValueOnSlider = this.SelectedValueOnSlider + count
                    }
                    this._cookieHandler.SetCookie('PreviousValue', this.SelectedValueOnSlider);
                }
                break;
            case 'DECREASE':
                indexOfDefaultValue = this.tickArray.indexOf(sliderValues);
                if (indexOfDefaultValue === -1) {
                    while (this.tickArray.indexOf(this.SelectedValueOnSlider) < 1 && this.tickArray.indexOf(this.SelectedValueOnSlider) !== 0) {
                        this.SelectedValueOnSlider = this.SelectedValueOnSlider - 1;
                    }
                    this._cookieHandler.SetCookie('PreviousValue', this.SelectedValueOnSlider);
                }
                break;
        }
    }
    private PrepareBuyNowPayload(responsePayload: any, action: string) {
        const payload = {
            businessType: 1,
            userAction: action,
            channelType: 'web',
            insuringFor: responsePayload.insuringFor,
            selectedPlanDetails: {
                planCode: responsePayload.recommendedPlans.planCode,
                planDetails: this.planDetails
            },
            utmParams: {
                utmSource: 'WEBSITE_PRODUCT_PAGE',
                utmMedium: null,
                utmCampaign: null,
                utmContent: null,
                utmTerm: null
            },
            proposerDetails: responsePayload.proposerDetails,
            insuredDetails: this.GetInsuredDetails
        };
        this.BuynowPlans = payload;
    }
    private ticksPositionsCalculation(tickArrayLength: number) {
        this.tickPositionArray.push(0);
        let updatedPosition = 0;
        const calculateSecondPosition = Math.round(100 / (tickArrayLength - 1));
        console.log(calculateSecondPosition);
        for (let i = 0, len = tickArrayLength - 2; i < len; i++) {
            updatedPosition = updatedPosition + calculateSecondPosition;
            this.tickPositionArray.push(updatedPosition);
        }
        this.tickPositionArray.push(100);
    }
    private prepareSelectedPlanDetails(plan: any) {
        const planDetails = {
            selected: 'Y',
            sumAssured: plan.sumAssured,
            agreegatedDed: plan.agreegatedDed,
            policyTerm: plan.policyTerm,
            netPremium: plan.netPremium,
            gst: plan.gst,
            grossPremium: plan.grossPremium,
            totalNetPremium: plan.totalNetPremium,
            totalGrossPremium: plan.totalGrossPremium,
            totalGST: plan.totalGST,
            riders: [
                {
                    code: plan.riders[0].code,
                    grossPremium: plan.riders[0].grossPremium,
                    gst: plan.riders[0].gst,
                    netPremium: plan.riders[0].netPremium,
                    selected: this.AirAmbulanceSelectedValue !== undefined ?
                        this.AirAmbulanceSelectedValue : this.GetQuoteFormGroup.controls['eiaAccountFlag'].value,
                    sumAssured: plan.riders[0].sumAssured
                }
            ]
        };
        this.planDetails = planDetails;
    }
    private PreparePayloadForModifiedPlan(responsePayload: any, action: string) {
        const payload = {
            planCode: responsePayload.recommendedPlans.planCode,
            sumAssuredList: [this.planDetails]
        };
        this.ModifiedBuynowPlans = payload;
    }
}
