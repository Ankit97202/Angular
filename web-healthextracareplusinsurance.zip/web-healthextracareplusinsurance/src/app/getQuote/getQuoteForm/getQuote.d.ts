declare module GetQuoteModel {
    export interface InputPayloadGetQuote{
        planCode: string;
        recommendedPlans: RecommendedPlans;
        productFeatures: ProductFeatures[];
    }
    export interface ProductFeatures {
        featuredesc: string;
        featurevalue: string;
        helptext: string;
        featurerank: number;
    }
    export interface FilterCriteria {
        sumAssuredAmount: string;
        AgreegatedeductibleAmount: string;
        policyTerm: string;
        netPremium: string;
        gst: string;
        grossPremium: string;
        totalPremium: string;
        riders: Riders[];
    }
    export interface Riders {
        sumAssured:number;
        selected: string;
        netPremium: number;
        gst: number;
        grossPremium: number;
        code: string;
    }
    export interface InsuranceDetails {
        planCode: string;
        insuringFor: number;
        businessType: string;
    }
    export interface InsuredDetails {
        relationship: string;
        age: string;
        height: string;
        weight: string;
        relationshipWithProposar: string;
        name: string;
    }
    export interface RecommendedPlans{
        sumAssuredList :SumAssuredList[];
    }
    export interface SumAssuredList {
        selected: string;
        sumAssured: number;
        agreegatedDed: number;
        policyTerm:number;
        netPremium:number;
        gst:number;
        grossPremium:number;
        totalNetPremium:number;
        totalGrossPremium:number;
        totalGST:number;
        riders: Riders[];
        }
     export interface BuynowPlans {
        businessType: number;
        userAction: string;
        channelType: string;
        insuringFor: number;
        selectedPlanDetails: SelectedPlanDetails;
        utmParams: UTMParams;
        proposerDetails: ProposerDetails;
        insuredDetails: InsuredDetails;
    }
   export interface SelectedPlanDetails {
        planCode: string;
        planDetails: SumAssuredList;
    }
   export interface ProposerDetails {
        firstName: string ;
        lastName: string;
        mobileNumber: number;
        gender: string;
        email?: string;
    }
   export interface UTMParams {
        utmSource: string;
        utmMedium?: string;
        utmCampaign?: string;
        utmContent?: string;
        utmTerm?: string;
    }
}
