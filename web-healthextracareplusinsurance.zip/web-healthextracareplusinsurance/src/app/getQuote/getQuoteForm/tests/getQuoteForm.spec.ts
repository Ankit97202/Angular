import { FormBuilder } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { TestBed, inject } from '@angular/core/testing';
import { of, Observable } from 'rxjs';
import { HttpResponse, HttpClient, HttpHandler } from '@angular/common/http';
import { Formatter } from 'src/app/common/services/formatter';
import { SharedService } from 'src/app/common/services/sharedService';
import { AnalyticsService } from 'src/app/common/services/device.analytics.service';
import { CookieHandlerService } from 'src/app/common/services/cookieHandler.service';
import { RouteContextProvider } from 'src/app/common/services/routeContextProvider.service';
import { HttpInterceptor } from 'src/app/common/services/httpInterceptor.service';
import { CookieService } from 'ngx-cookie-service';
import { debug } from 'util';
import { RouteHandlerService } from 'src/app/common/services/routeHandler.service';
import { FormValidator } from 'src/app/common/services/formValidator.service';
import { ActivitiHandlerService } from 'src/app/common/services/activitiHandler.service';
import { ConfigService } from 'src/app/common/services/config.service';
import { PersoanlDetailsService } from 'src/app/applicationModule/personalDetails/personalDetailsForm/personalDetails.service';
import { ToastrManager } from 'ng6-toastr-notifications';
import { ToastrOptions } from 'ng6-toastr-notifications/lib/toastr.options';
import { GetQuoteFormComponent } from '../getQuoteForm.component';
import { AppModule } from './../../../app.module';
const mockMartTaskdata: HttpResponse<any> = new HttpResponse({
    body: {
        "payload":null,
        "userInput":null,
        "status":"SUCCESS",
        "errorBean":null,
        "nextTaskKey":"healthExtraCareBuyNow",
        "progressInfo":null,
        "routesInfo":null
     }
  });
const mockData: HttpResponse<any> = new HttpResponse({
    body: {
        "payload":{
            "productFeatures":[
               {
                  "featuredesc":"Insure your Family members for upto Rs.",
                  "featurevalue":"Rs. 50,00,000",
                  "helptext":"A limit of coverage amount you and your family members are covered",
                  "featurerank":1
               },
               {
                  "featuredesc":"Maternity Benefit upto Rs.",
                  "featurevalue":"Upto sum assured opted",
                  "helptext":"We will pay the Medical Expenses for the delivery of a baby or expenses related to medically recommended and lawful termination of pregnancy",
                  "featurerank":2
               },
               {
                  "featuredesc":"ICU",
                  "featurevalue":"Actual hospital Expenses",
                  "helptext":null,
                  "featurerank":3
               },
               {
                  "featuredesc":"Room rent",
                  "featurevalue":"Included in medical expense",
                  "helptext":null,
                  "featurerank":4
               },
               {
                  "featuredesc":"Post Hospitalisation",
                  "featurevalue":"Expenses Incurred after 90 days of discharge",
                  "helptext":"Medical Expenses incurred during the 90 days immediately after You  were discharged post Hospitalisation",
                  "featurerank":5
               },
               {
                  "featuredesc":"Pre Hospitalisation",
                  "featurevalue":"Expenses Incurred during last 60 days before hospitalisation",
                  "helptext":"Medical Expenses incurred during the 60 days immediately before your hospitalisation",
                  "featurerank":6
               },
               {
                  "featuredesc":"Ambulance",
                  "featurevalue":"Rs. 3000/ per valid claim",
                  "helptext":"Ambulance offered by a healthcare or ambulance service provider for transferring You to the nearest Hospital ",
                  "featurerank":7
               },
               {
                  "featuredesc":"Day Care Procedures",
                  "featurevalue":"Yes",
                  "helptext":"We will pay you the medical expenses as listed in brochure under In-patient Hospitalisation Treatment Cover for Day care procedures / Surgeries ",
                  "featurerank":8
               },
               {
                  "featuredesc":"Free Annual Health Check-Up",
                  "featurevalue":"Upto Rs. 1000 for 1 member \nUpto Rs. 2000 for more than 1 member",
                  "helptext":"At the end of block of every continuous period of 3 years during which You have held Our Health Guard policy, You are eligible for a free Preventive Health checkup. ",
                  "featurerank":9
               },
               {
                  "featuredesc":"Organ Donor Expenses",
                  "featurevalue":"Actual Expenses Incurred",
                  "helptext":"We will pay expenses towards organ donor's treatment for harvesting of the donated organ",
                  "featurerank":10
               },
               {
                  "featuredesc":"Air Ambulance Cover ",
                  "featurevalue":"Actual Expenses Incurred",
                  "helptext":null,
                  "featurerank":11
               }
            ],
            "modifyPlan":false,
            "premiumRevised":"N",
            "planDesc":"Family Health Extra Care Plus",
            "oldGrossPremium":5577,
            "insuringFor":"3",
            "recommendedPlans":{
               "planCode":"FHECP",
               "sumAssuredList":[
                  {
                     "selected":"N",
                     "sumAssured":300000,
                     "agreegatedDed":200000,
                     "policyTerm":1,
                     "netPremium":3832,
                     "gst":689.76,
                     "grossPremium":4522,
                     "totalNetPremium":3955,
                     "totalGrossPremium":4667,
                     "totalGST":711.9,
                     "insuringFor":null,
                     "insuringForDesc":null,
                     "riders":[
                        {
                           "sumAssured":200000,
                           "selected":"Y",
                           "netPremium":123,
                           "gst":22.14,
                           "grossPremium":145,
                           "code":"FAMB"
                        }
                     ]
                  },
                  {
                     "selected":"N",
                     "sumAssured":500000,
                     "agreegatedDed":300000,
                     "policyTerm":1,
                     "netPremium":2542,
                     "gst":457.56,
                     "grossPremium":3000,
                     "totalNetPremium":2849,
                     "totalGrossPremium":3362,
                     "totalGST":512.82,
                     "insuringFor":null,
                     "insuringForDesc":null,
                     "riders":[
                        {
                           "sumAssured":500000,
                           "selected":"Y",
                           "netPremium":307,
                           "gst":55.26,
                           "grossPremium":362,
                           "code":"FAMB"
                        }
                     ]
                  },
                  {
                     "selected":"N",
                     "sumAssured":1000000,
                     "agreegatedDed":500000,
                     "policyTerm":1,
                     "netPremium":2923,
                     "gst":526.14,
                     "grossPremium":3449,
                     "totalNetPremium":3230,
                     "totalGrossPremium":3811,
                     "totalGST":581.4,
                     "insuringFor":null,
                     "insuringForDesc":null,
                     "riders":[
                        {
                           "sumAssured":500000,
                           "selected":"Y",
                           "netPremium":307,
                           "gst":55.26,
                           "grossPremium":362,
                           "code":"FAMB"
                        }
                     ]
                  },
                  {
                     "selected":"Y",
                     "sumAssured":1500000,
                     "agreegatedDed":500000,
                     "policyTerm":1,
                     "netPremium":4111,
                     "gst":739.98,
                     "grossPremium":4851,
                     "totalNetPremium":4726,
                     "totalGrossPremium":5577,
                     "totalGST":850.68,
                     "insuringFor":null,
                     "insuringForDesc":null,
                     "riders":[
                        {
                           "sumAssured":1000000,
                           "selected":"Y",
                           "netPremium":615,
                           "gst":110.7,
                           "grossPremium":726,
                           "code":"FAMB"
                        }
                     ]
                  },
                  {
                     "selected":"N",
                     "sumAssured":2000000,
                     "agreegatedDed":500000,
                     "policyTerm":1,
                     "netPremium":5105,
                     "gst":918.9,
                     "grossPremium":6024,
                     "totalNetPremium":5720,
                     "totalGrossPremium":6750,
                     "totalGST":1029.6,
                     "insuringFor":null,
                     "insuringForDesc":null,
                     "riders":[
                        {
                           "sumAssured":1000000,
                           "selected":"Y",
                           "netPremium":615,
                           "gst":110.7,
                           "grossPremium":726,
                           "code":"FAMB"
                        }
                     ]
                  },
                  {
                     "selected":"N",
                     "sumAssured":2500000,
                     "agreegatedDed":1000000,
                     "policyTerm":1,
                     "netPremium":4098,
                     "gst":737.64,
                     "grossPremium":4836,
                     "totalNetPremium":4713,
                     "totalGrossPremium":5561,
                     "totalGST":848.34,
                     "insuringFor":null,
                     "insuringForDesc":null,
                     "riders":[
                        {
                           "sumAssured":1000000,
                           "selected":"Y",
                           "netPremium":615,
                           "gst":110.7,
                           "grossPremium":726,
                           "code":"FAMB"
                        }
                     ]
                  },
                  {
                     "selected":"N",
                     "sumAssured":5000000,
                     "agreegatedDed":1000000,
                     "policyTerm":1,
                     "netPremium":760,
                     "gst":136.8,
                     "grossPremium":897,
                     "totalNetPremium":1375,
                     "totalGrossPremium":1623,
                     "totalGST":247.5,
                     "insuringFor":null,
                     "insuringForDesc":null,
                     "riders":[
                        {
                           "sumAssured":1000000,
                           "selected":"Y",
                           "netPremium":615,
                           "gst":110.7,
                           "grossPremium":726,
                           "code":"FAMB"
                        }
                     ]
                  }
               ]
            },
            "proposerDetails":{
               "gender":"M",
               "dob":"1992-06-16",
               "mobileNumber":"9923232323",
               "age":26,
               "email":"qas@gmail.com"
            },
            "insuredDetails":[
               {
                  "age":26,
                  "relationship":"SPOUSE",
                  "dob":null,
                  "no":41862,
                  "firstName":"dfdf",
                  "middleName":null,
                  "lastName":"dfd",
                  "genderCode":"F",
                  "genderDesc":"Female",
                  "height":"165",
                  "weight":"55",
                  "bmi":null,
                  "insuredDeleted":false
               },
               {
                  "age":26,
                  "relationship":"SELF",
                  "dob":null,
                  "no":41863,
                  "firstName":null,
                  "middleName":null,
                  "lastName":null,
                  "genderCode":"M",
                  "genderDesc":"Male",
                  "height":"165",
                  "weight":"55",
                  "bmi":null,
                  "insuredDeleted":false
               }
            ],
            "applicationId":"188377",
            "errorDetails":[

            ]
         },
         "userInput":null,
         "status":"SUCCESS",
         "errorBean":null,
         "nextTaskKey":"healthExtraCareBuyNow",
         "progressInfo":{
            "payload":[
               {
                  "name":"Get Started",
                  "value":0,
                  "active":true
               },
               {
                  "name":"Verify Me",
                  "value":0,
                  "active":false
               },
               {
                  "name":"Close The Deal",
                  "value":0,
                  "active":false
               }
            ],
            "status":"SUCCESS",
            "errorBean":null
         },
         "routesInfo":{
            "mainRoute":"getQuoteForm",
            "subRoute":""
         }
    }
});
const mockvalidatePersonalEmail: HttpResponse<any> = new HttpResponse({
   body: {
      "payload":{"statusFlag":true},"status":"SUCCESS","errorBean":null
   }});
class MockActivitiHandlerService {
    public MarkTaskAsCompleted() {
      return of(mockMartTaskdata.body);
    }
    public GetTaskDetails() {
      return of(mockData.body);
    }
  }
  class MockPersoanlDetailsService {
   public ValidatePersonalEmailID() {
     return of(mockvalidatePersonalEmail.body);
   }
 }
 let mockToastr = {
   successToastr: () => {
   // hide
   },
   infoToastr: () => {
   // show
   }
   };
describe('GetQuoteForm Component', () => {
    // provide our implementations or mocks to the dependency injector
    beforeEach(() => {
      TestBed.configureTestingModule({
        imports: [RouterTestingModule, AppModule],
        providers: [
          GetQuoteFormComponent,
          HttpInterceptor,
          Formatter,
          FormBuilder,
          RouteHandlerService,
          FormValidator,
          SharedService,
          AnalyticsService,
          RouteContextProvider,
          CookieHandlerService,
          CookieService,
          HttpClient,
          HttpHandler,
          ToastrManager,
          {
            provide: ActivitiHandlerService,
            useClass: MockActivitiHandlerService
          },
          {
            provide: PersoanlDetailsService,
            useClass: MockPersoanlDetailsService
          },
        ]
      });
    });
    it('Testing ngOnInit', inject(
      [GetQuoteFormComponent],
      (testComponent: GetQuoteFormComponent) => {
        testComponent.ngOnInit();
      }
    ));
    it('Testing BuyNow', inject(
      [GetQuoteFormComponent],
      (testComponent: GetQuoteFormComponent) => {
        testComponent.ngOnInit();
        testComponent.BuyNow();
      }
    ));
it('Testing showSuccess', inject(
   [GetQuoteFormComponent, ToastrManager],
   (testComponent: GetQuoteFormComponent) => {
   testComponent.ngOnInit();
   const toastr = mockToastr;
   testComponent.showSuccess();
   }
   ));
   it('Testing showToast', inject(
   [GetQuoteFormComponent, ToastrManager],
   (testComponent: GetQuoteFormComponent) => {
   testComponent.ngOnInit();
   const toastr = mockToastr;
   testComponent.showToast();
   }
   ));
    it('Testing ModifyPlan', inject(
      [GetQuoteFormComponent],
      (testComponent: GetQuoteFormComponent) => {
        testComponent.ngOnInit();
        testComponent.ModifyPlan();
      }
    ));
    it('Testing setIndividualFormGroup', inject(
      [GetQuoteFormComponent],
      (testComponent: GetQuoteFormComponent) => {
        testComponent.ngOnInit();
        testComponent.setIndividualFormGroup();
      }
    ));
    it('Testing ChangePremium', inject(
      [GetQuoteFormComponent],
      (testComponent: GetQuoteFormComponent) => {
        testComponent.ngOnInit();
        let event = {
         target: {
         value: 'N'
       }
      }
        testComponent.ChangePremium(event);
      }
    ));
    it('Testing OnSliderStart', inject(
      [GetQuoteFormComponent],
      (testComponent: GetQuoteFormComponent) => {
        testComponent.ngOnInit();
        let event = {
         target: {
         value: '20'
       }
      }
        testComponent.OnSliderStart(event);
      }
    ));
  });
