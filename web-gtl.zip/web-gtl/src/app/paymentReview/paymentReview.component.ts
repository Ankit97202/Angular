import { SessionHandlerService } from './../common/services/sessionHandler.service';
import { Component, OnInit } from '@angular/core';
import { ActivitiHandlerService } from '../common/services/activitiHandler.service';
import { RouteHandlerService } from '../common/services/routeHandler.service';
import { RouteContextProvider } from '../common/services/routeContextProvider.service';
import { HttpInterceptor } from './../common/services/httpInterceptor.service';
import { PaymentStatusService } from './../paymentReview/paymentStatus.service';
import { environment } from '../../environments/environment';
import { CommonConstants } from './../common/utilities/commonConstants';
import { PaymentService } from './../payment/payment.service';
import { ConfigService } from './../common/services/config.service';
@Component({
    templateUrl: './paymentReview.template.html',
    styleUrls: ['./paymentReview.style.css'],
    providers: [RouteHandlerService, PaymentStatusService, PaymentService]
})
export class PaymentReviewComponent implements OnInit {
    public ShowLoader: boolean = false;
    public ShowBackLoader: boolean = false;
    public PaymentDetails = null;
    public PaymentIdReceived: boolean = false;
    public MainLoadingText: string = "Stay with us. We're almost done...";
    private _requestId: string;
    private _policyRef: string = null;
    private _paymentStatus: string = null;
    private _retryPaymentStatus: string = null;
    public ButtonName = 'PAY NOW';
    public BagicPaymentURL: any;
    public grossPremium;
    private _orderId: string;
    // Constructor
    constructor(
        private _activityHandler: ActivitiHandlerService,
        private _routerService: RouteHandlerService,
        private _routeContextProvider: RouteContextProvider,
        private _httpInterceptor: HttpInterceptor,
        private paymentStatusService: PaymentStatusService,
        private _paymentService: PaymentService,
        private _sessionService: SessionHandlerService
    ) { }
    // On Init
    public ngOnInit() {
        this.getQueryParams();
    }
    // On Next
    public Next() {
        this.ShowLoader = true;
        this.getHealthRequestId();
    }
    // On Back
    public Back() {
        this.ShowBackLoader = true;
        this.markTaskComplete(null, 'Back');
    }
    private redirectToPaymentGateway() {
        this.BagicPaymentURL = environment['paymentGatewayUrl'];
        let paymentUrl = this.BagicPaymentURL;
        if (this._requestId) {
            paymentUrl = paymentUrl.replace('{0}', this._requestId);
        }
        this.PaymentIdReceived = true;
        window.open(paymentUrl, '_self');
    }
    private getHealthRequestId() {
        const hlRequestUrl = ConfigService.getInstance().getConfigObject().APIURL
            .getHealthRequestId;
        const data = {
            applicationId: this.PaymentDetails.applicationId
        };
        this._httpInterceptor
            .Post(hlRequestUrl, data, true)
            .subscribe((resp: Model.MTResponse<any>) => {
                const mtResponse: Model.MTResponse<any> = resp;
                if (!mtResponse.errorBean) {
                    if (mtResponse.payload) {
                        this._requestId = mtResponse.payload.productRequestId;
                    }
                    this.redirectToPaymentGateway();
                }
            });
    }
    // Getting All Query Params
    private getQueryParams() {
        this._paymentStatus = this._routeContextProvider.GetQueryParams(
            'p_pay_status'
        );
        this._policyRef = this._routeContextProvider.GetQueryParams('policyref');
        this._requestId = this._routeContextProvider.GetQueryParams('requestId');
        if (this._paymentStatus && this._policyRef) {
            const payload = {
                policyNo:
                    this._policyRef !== 'null' && this._policyRef
                        ? this._policyRef
                        : null,
                transactionStatus: this._paymentStatus,
                transactionId: this._requestId, //Transaction Id
                applicationId: this._sessionService.GetSession(
                    CommonConstants.CookieKeys.LoanApplicationId
                ) //Transaction Id,
            };
            this.PaymentIdReceived = true;
            this.markTaskComplete(payload, null);
            if (this._paymentStatus === 'N') this.getTaskDetails();
        } else {
            this.getTaskDetails();
        }
    }
    // Get Task Details
    private getTaskDetails() {
        this._activityHandler.GetTaskDetails().subscribe(
            (resp: Model.MTResponse<any>) => {
                let mtResponse: Model.MTResponse<any> = resp;
                if (!mtResponse.errorBean) {
                    this.PaymentDetails = mtResponse.payload;
                    this._requestId = mtResponse.payload.requestId;
                    this.grossPremium = this.PaymentDetails.recommendedPlans.sumAssuredList.find(s => s.selected === 'Y').totalGrossPremium;
                    this.fetchPaymentStatus(mtResponse.payload);
                }
            },
            error => {
                console.error('ERROR::', error);
            }
        );
    }
    // Mark Task Complete Call
    private markTaskComplete(data, actionName: string) {
        this._activityHandler
            .MarkTaskAsCompleted(data, actionName, true)
            .subscribe((resp: Model.MTResponse<any>) => {
                let mtResponse: Model.MTResponse<any> = resp;
                this.ShowBackLoader = false;
                this.ShowLoader = false;
                if (!mtResponse.errorBean) {
                    this._routerService.RouteToNextTask(mtResponse.nextTaskKey);
                }
            });
    }
    private fetchPaymentStatus(data: any) {
        this.paymentStatusService
            .FetchPaymentStatus(data)
            .subscribe((resp: Model.MTResponse<any>) => {
                let mtPaymentStatusResponse: Model.MTResponse<any> = resp;
                if (mtPaymentStatusResponse.payload !== null) {
                    if (!resp.payload) return;
                    this._retryPaymentStatus =
                        mtPaymentStatusResponse.payload.paymentStatus;
                    if (
                        this._retryPaymentStatus === 'Pending' ||
                        this._retryPaymentStatus === 'Failed'
                    ) {
                        this.ButtonName = 'RETRY PAYMENT';
                        this.PaymentIdReceived = false;
                        this._routerService.RouteToNextTask('healthextracarepaymentpreview');
                    } else if (this._retryPaymentStatus === 'Success') {
                        this.markTaskComplete(null, 'PaymentSuccess');
                    } else {
                        this.ButtonName = 'PAY NOW';
                    }
                }
            });
    }
}
