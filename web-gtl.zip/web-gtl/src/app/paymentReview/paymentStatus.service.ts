import { Http, Response } from '@angular/http';
import { HttpInterceptor } from './../common/services/httpInterceptor.service';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { ConfigService } from './../common/services/config.service';
@Injectable()
export class PaymentStatusService {
    constructor(private _httpInterceptor: HttpInterceptor) { }
    public FetchPaymentStatus(data: any) {
        let url = ConfigService.getInstance().getConfigObject().APIURL.getPaymentStatus;
            return this._httpInterceptor.Post(url,data, true);
    }
}
