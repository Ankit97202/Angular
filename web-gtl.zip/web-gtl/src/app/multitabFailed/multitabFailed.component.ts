import { Component, OnInit, Input } from '@angular/core';
import { SharedService } from './../common/services/sharedService';
import { CommonConstants } from './../common/utilities/commonConstants';
import { RouteContextProvider } from './../common/services/routeContextProvider.service';
import { ActivitiHandlerService } from '../common/services/activitiHandler.service';
import { RouteHandlerService } from '../common/services/routeHandler.service';
import { SessionHandlerService } from '../common/services/sessionHandler.service';

@Component({
  templateUrl: './multitabFailed.template.html',
  styleUrls: ['./multitabFailed.style.css']
})
export class MultitabFailedComponent implements OnInit {
  private isbrowserBackPressed: boolean;

  constructor(
    private _sharedService: SharedService,
    private _routeContextProvider: RouteContextProvider,
    private _sessionHandler: SessionHandlerService
  ) { }

  public ngOnInit() {
    // browser back button changes
    this._sessionHandler.FlushAll();
    this.isbrowserBackPressed = this._sharedService.getData('brwoserback');
    if (this.isbrowserBackPressed) {
      this._routeContextProvider.NavigateToView([
        CommonConstants.Routes.MultitabFailed
      ]);
    }
  }
  public ExploreMore() {
    window.open('https://www.bajajfinservmarkets.in', '_self');
}
}
