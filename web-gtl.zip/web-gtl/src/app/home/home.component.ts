import { SessionHandlerService } from './../common/services/sessionHandler.service';
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpResponse } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { ConfigService } from './../common/services/config.service';
import { CommonConstants } from './../common/utilities/commonConstants';
import { CookieHandlerService } from './../common/services/cookieHandler.service';
import { HomeService } from './home.service';
import { RouteContextProvider } from './../common/services/routeContextProvider.service';
import { RouteHandlerService } from './../common/services/routeHandler.service';
import { SharedService } from './../common/services/sharedService';
import { ActivitiHandlerService } from './../common/services/activitiHandler.service';
import { Formatter } from './../common/services/formatter';
import { EmitterService } from './../common/services/emitter.service';
@Component({
    selector: 'app-home',
    template: '',
    styleUrls: ['./home.style.css'],
    providers: [HomeService, HttpModule]
})
export class HomeComponent implements OnInit {
    private _UTMDataObject: any;
    public RedirectionRequired: Boolean = true;
    private applicationidFromURL: string;
    private applicationIDFromCookie: string;
    public errorMessge: string;
    constructor(
        private _homeService: HomeService,
        private _routeContextProvider: RouteContextProvider,
        private _cookieHandler: CookieHandlerService,
        private _sharedService: SharedService,
        private _http: HttpModule,
        private _activatedRoute: ActivatedRoute,
        private router: Router,
        private _routerService: RouteHandlerService,
        private _formatter: Formatter,
        private _activitiHandler: ActivitiHandlerService,
        private _sessionHandlerService: SessionHandlerService,
        private _emitterService: EmitterService
    ) { }
    public ngOnInit(): void {
      // multiple tab condition
      this.applicationidFromURL = this._routeContextProvider.GetQueryParams(CommonConstants.QueryParamsKeys.ApplicationId);
      this.applicationIDFromCookie =
      this._cookieHandler.GetCookie(CommonConstants.CookieKeys.LoanApplicationId, this.applicationidFromURL);
      if (this.applicationidFromURL === this.applicationIDFromCookie &&
          (this.applicationidFromURL) && (this.applicationIDFromCookie)) {
          console.log('sorry...');
          this.errorMessge = 'Application is already opened in another tab, Please close it and continue';
          this._routeContextProvider.NavigateToView(
                  [CommonConstants.Routes.MultitabFailed]);
      } else {
        this.setMobileValues();
        this._sharedService.setData(CommonConstants.QueryParamsKeys.appUtmRefCode,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.appUtmRefCode));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.appUtmSource,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.appUtmSource));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.appUtmMedium,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.appUtmMedium));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.appUtmCampaign,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.appUtmCampaign));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.appUtmTerm,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.appUtmTerm));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.appUtmContent,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.appUtmContent));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.BFLBranch,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.BFLBranch));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.GCLID,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.GCLID));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.ApplicantId,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.ApplicantId));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.ApplicationId,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.ApplicationId));
        this._sharedService.setData(CommonConstants.QueryParamsKeys.ApplicationApplicantId,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.ApplicationApplicantId));
        // this.utmSourceStamping();
        this.storeDetailsToCookies();
        this.authenticateSystem();
      }
    }
    // this checks if user should be ab tested or not?
    private initProcess(callback: Function) {
        this.startActivitiWithApplicationCreate(
            CommonConstants.LOAN_PRODUCT_CODES.GTL_Insurance,
            CommonConstants.LOAN_PRODUCT_CATEGORY_CODES.GTL_Insurance,
            (mtResponse: ActivitiModel.MTResponse<any>) => {
                callback(mtResponse);
            });
    }
    private startActivitiWithApplicationCreate(
        loanProduct: string,
        productCategoryCode: string,
        onSuccessCallback: Function,
        calculatorProductType?: number,
        isLocationProvided?: boolean) {
        const startActivitiRequest: any = {
            activitiName: 'startFlow',
            payload: this.getApplicationCreateRequest(
                loanProduct, productCategoryCode, calculatorProductType, isLocationProvided)
        };
        console.log(startActivitiRequest);
        this.startActiviti(startActivitiRequest, onSuccessCallback);
    }
    private startActiviti(request: any, onSuccessCallback: Function) {
        this._activitiHandler.StartActiviti(request, true)
            .subscribe((response: ActivitiModel.MTResponse<any>) => {
                console.log('Raw Activiti working now');
                const data = response;
                if (!data.errorBean) {
                    this._sessionHandlerService.SetSession(CommonConstants.CookieKeys.ProcessInstanceDetails,
                        data.payload.processInstanceDetails);
                    onSuccessCallback(data);
                }
            },
                (Error) => {
                    console.log(Error);
                });
    }
    // need to check the following values when we deploy this
    private getApplicationCreateRequest(
        LoanProduct: string,
        ProductCategoryCode: string,
        CalculatorProductType?: number,
        IsLocationProvided?: boolean) {
        const mediumFromWeb: string =
            this._sharedService.getData(CommonConstants.QueryParamsKeys.appUtmMedium).toString();
        const medium = 'Webengage_repeat_visitor_finance_homepage_PL_apply_online_link';
        return {
            appJourneyStamp: 'journeyStamp',
            appSource: 'Browser',
            appStatus: 0,
            bflBranch: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.BFLBranch)) || '320',
            productCategoryCode: ProductCategoryCode,
            insuranceApplications: {
                insProduct: CommonConstants.LOAN_PRODUCT_CODES.GTL_Insurance
            },
            appUtmRefCode: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.appUtmRefCode)) || '',
            appUtmSource: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.appUtmSource)) || 'Organic',
            appUtmMedium: mediumFromWeb || medium,
            appUtmCampaign: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.appUtmCampaign)) || '',
            appUtmTerm: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.appUtmTerm)) || '',
            appUtmContent: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.appUtmContent)) || '',
            gclId: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.GCLID))
                || 'EAIaIQobChMIsZGIyZn01AIV1IdoCh19HAKqEAAYASAAEgKWjfD_BwE',
            applicantId: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.ApplicantId)) || '',
            applicationId: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.ApplicationId)) || '',
            appApplicantId: this.checkUtmSources(this._sharedService.getData(
                CommonConstants.QueryParamsKeys.ApplicationApplicantId)) || ''
        };
    }
    private checkUtmSources(utmObj) {
        if (Object.keys(utmObj).length !== 0) {
            return utmObj;
        } else {
            return false;
        }
    }
    public authenticateSystem(): void {
        this._sessionHandlerService.SetSession(CommonConstants.CookieKeys.JourneyType, '');
        const authToken = this._sessionHandlerService.GetSession(CommonConstants.CookieKeys.JWToken);
        const guardToken = this._sessionHandlerService.GetSession(CommonConstants.CookieKeys.GuardToken);
        if (!authToken && !guardToken) {
        const userClientId = this._homeService.GetClientIdForUser();
        this.setSecretKeyForClientId(userClientId);
        }
    }
    private setSecretKeyForClientId(clientId: string): void {
        this._homeService.GetSecretKeyForBasedOnClientId(clientId).subscribe((responseData: ActivitiModel.MTResponse<any>) => {
            if (!responseData.errorBean) {
                this._sessionHandlerService
                    .SetSession(CommonConstants.CookieKeys.ClientId, clientId);
                this._sessionHandlerService
                    .SetSession(CommonConstants.CookieKeys.SecretKey,
                        responseData.payload.secretKey);
                this.setSystemAuthToken(responseData.payload.secretKey, clientId);
            }
        });
    }
    private setSystemAuthToken(secretKey: string, clientId: string): void {
        this._homeService.GetSystemAuthToken({
            secretKey,
            clientId
        }).subscribe((responseData: ActivitiModel.MTResponse<any>) => {
            if (!responseData.errorBean) {
                const tokenObj = responseData.payload.tokens[0];
                console.log('tokens::', tokenObj);
                this._sessionHandlerService.SetSession(CommonConstants.CookieKeys.JWToken, tokenObj.token);
                this._sessionHandlerService.SetSession(CommonConstants.CookieKeys.GuardKey, tokenObj.guardKey);
                this._sessionHandlerService.SetSession(CommonConstants.CookieKeys.GuardToken, this._formatter
                    .ConvertGuradKeyToGuardToken(tokenObj.guardKey));
                this.initProcess((mtResponse) => {
                    this._activitiHandler.MarkTaskAsCompleted(null, 'Manual', true)
                        .subscribe((resp) => {
                            mtResponse = resp;
                            if (!mtResponse.errorBean) {
                                this._routerService.RouteToNextTask(mtResponse.nextTaskKey);
                            } else {
                                console.log('Error Occured on ', mtResponse.errorBean);
                            }
                        },
                            (error) => {
                                console.log(error);
                            });
                });
            }
        });
    }
    private storeDetailsToCookies() {
      const appId = this._sharedService.getData(CommonConstants.QueryParamsKeys.ApplicationId);
      if( appId){
        this._sessionHandlerService.SetSession(CommonConstants.CookieKeys.LoanApplicationId, appId);
        this._cookieHandler.SetCookie(CommonConstants.CookieKeys.LoanApplicationId, appId, appId);
        }
        this._sessionHandlerService.SetSession(CommonConstants.CookieKeys.LoanApplicationKey,
          this._sharedService.getData(CommonConstants.QueryParamsKeys.ApplicationApplicantId));
    }
    private setMobileValues() {
        this._emitterService.Get(CommonConstants.EmitterEventTypes.MobileAppCheck)
            .emit(this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.IsMobile));
        // Set Mobile cookie
        this._sessionHandlerService.SetSession(CommonConstants.CookieKeys.MobileState,
            this._routeContextProvider.GetQueryParams
                (CommonConstants.QueryParamsKeys.IsMobile));
    }
    // private utmSourceStamping() {
    //     const src_90 = this._routeContextProvider.GetQueryParams('src_90');
    //     const src_60 = this._routeContextProvider.GetQueryParams('src_60');
    //     const src_30 = this._routeContextProvider.GetQueryParams('src_30');
    //     const pid = this._routeContextProvider.GetQueryParams('pid');
    //     const UtmType = src_90 ? 'src_90' : src_60 ? 'src_60' : src_30 ? 'src_30' : pid ? 'pid' : 'utm';
    //     this._sharedService.setData('UTM', src_90 || src_60 || src_30 || pid);
    //     let UTM = this._sharedService.getData('UTM');
    //     if (UtmType !== 'utm' && UTM) {
    //         UTM = UTM.split(':');
    //         if (UTM.length === 1) { UTM.length = []; }
    //         const sourcing = {
    //             'utmSource': UTM.length ? (UtmType === 'pid' ? UTM[0] : UTM[1]) : 'Organic_markets',
    //             'utmMedium': UTM.length ? (UtmType === 'pid' ? UTM[1] : UTM[2]) : null,
    //             'utmCampaign': UTM.length ? UTM[3] : null,
    //             'utmContent': UTM.length === 6 ? UTM[4] : null,
    //             'utmTerm': UTM.length === 6 ? UTM[5] : null,
    //         };
    //         this._sharedService.setData(CommonConstants.QueryParamsKeys.appUtmSource, sourcing.utmSource);
    //         this._sharedService.setData(CommonConstants.QueryParamsKeys.appUtmMedium, sourcing.utmMedium);
    //         this._sharedService.setData(CommonConstants.QueryParamsKeys.appUtmCampaign, sourcing.utmCampaign);
    //         this._sharedService.setData(CommonConstants.QueryParamsKeys.appUtmTerm, sourcing.utmTerm);
    //         this._sharedService.setData(CommonConstants.QueryParamsKeys.appUtmContent, sourcing.utmContent);
    //     }
    // }
}
