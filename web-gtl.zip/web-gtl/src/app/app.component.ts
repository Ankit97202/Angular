import { SharedService } from './common/services/sharedService';
import { RouteHandlerService } from './common/services/routeHandler.service';
import { SessionHandlerService } from './common/services/sessionHandler.service';
import { Component, OnInit, ChangeDetectorRef, AfterViewInit, AfterViewChecked, OnDestroy } from '@angular/core';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { CommonConstants } from './common/utilities/commonConstants';
import { environment } from '../environments/environment';
import { CookieHandlerService } from 'src/app/common/services/cookieHandler.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements AfterViewChecked, OnInit, OnDestroy {
  title = 'app';
  // Bajaj Logo goes here
  public bajajclassLogo = 'assets/img/bfs-logo-mod.png';
  public angularclassLogo = 'assets/img/angularclass-avatar.png';
  public name = 'This is test page';
  public url = 'some URL';
  public HasError: boolean;
  public IsLoadingTask = false;
  constructor(
    private cdRef: ChangeDetectorRef,
    private _cookieHandlerService: CookieHandlerService,
    private _sessionHandler: SessionHandlerService,
    private _sharedservice: SharedService,
    private _routerService: RouteHandlerService
  ) {}
  public ngAfterViewChecked() {
    this.cdRef.detectChanges();
  }
  public ngOnInit() {
    let appId = this._sessionHandler.GetSession(CommonConstants.CookieKeys.LoanApplicationId);
    appId = appId ? this._cookieHandlerService.GetCookie(CommonConstants.CookieKeys.LoanApplicationId, appId) : null;
    if (window.name !== '') {
      const LoanApplicationId = window.name;
      this._cookieHandlerService.SetCookie(CommonConstants.CookieKeys.LoanApplicationId, LoanApplicationId, LoanApplicationId);
    } else if (window.name === '' && appId) {
      window.name = '';
      this._routerService.RouteToNextTask('multitabfailed');
    }
    this.addAnalyticsScript();
  }
  public ngOnDestroy() {
    let LoanApplicationId = this._sessionHandler.GetSession(CommonConstants.CookieKeys.LoanApplicationId);
    if (!LoanApplicationId) {
      LoanApplicationId = window.name;
    }
    if (LoanApplicationId) {
      window.name = '';
      this._cookieHandlerService.DeleteCookies([CommonConstants.CookieKeys.LoanApplicationId], LoanApplicationId);
    }
  }
  private addAnalyticsScript() {
    const path = environment['AnalyticsLink'];
    const scriptTag = document.createElement('script');
    scriptTag.setAttribute('src', path);
    scriptTag.setAttribute('async', '');
    document.head.appendChild(scriptTag);
  }
}
