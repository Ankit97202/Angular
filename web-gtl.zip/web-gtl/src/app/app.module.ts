import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, APP_INITIALIZER, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AppInitializeService } from './common/services/appInitialize.service';
import { ROUTES } from './app.routes';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { SharedModule } from './common/utilities/shared/shared.module';
import { CookieService } from 'ngx-cookie-service';
import { ResumeApplicationComponent } from './resumeApplication/resumeApplication.component';
import { Ng2CompleterModule } from 'ng2-completer';
import { FormsModule } from '@angular/forms';
import { ExistingCustomerComponent } from './existingCustomer/existingCustomer.component';
import { CircleProgressbarComponent } from './circleProgressbar/circleProgressbar.component';
import { ApplicationModule } from './applicationModule/application.module';
import { CustomerLoginComponent } from './customerLogin/customerLogin.component';
import { GetQuoteFormComponent } from './getQuote/getQuoteForm/getQuoteForm.component';
import { Ng5SliderModule } from 'ng5-slider';
import { NgxBootstrapSliderModule } from 'ngx-bootstrap-slider';
import { ToastrModule } from 'ng6-toastr-notifications';
import { MultitabFailedComponent } from 'src/app/multitabFailed/multitabFailed.component';
import { OfferAddComponent } from 'src/app/offerAdd/offerAdd.component';
export function init_app(appInitService: AppInitializeService) {
  return () => appInitService.initializeApp();
}
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    HeaderComponent,
    FooterComponent,
    ResumeApplicationComponent,
    ExistingCustomerComponent,
    CircleProgressbarComponent,
    CustomerLoginComponent,
    GetQuoteFormComponent,
    MultitabFailedComponent,
    OfferAddComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    Ng2CompleterModule,
    FormsModule,
    RouterModule.forRoot(ROUTES, { useHash: true }),
    SharedModule.forRoot(),
    ApplicationModule,
    Ng5SliderModule,
    NgxBootstrapSliderModule,
    ToastrModule.forRoot(),
  ],
  providers: [
    AppInitializeService,
    CookieService
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  bootstrap: [AppComponent]
})
export class AppModule { }
