import { SpacePipe } from './../common/utilities/pipes/SpacePipe.pipe';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';
import * as ModuleComponent from './index';
import { ConfigResolve } from './../common/services/config.resolve.service';
import { CommonConstants } from './../common/utilities/commonConstants';
import { SharedModule } from './../common/utilities/shared/shared.module';
import { RatingModule } from 'ngx-bootstrap';
@NgModule({
  declarations: [
    ModuleComponent.ReviewApplicationComponent,
    SpacePipe
  ],
  imports: [
    // import Angular's modules
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    SharedModule,
    RatingModule.forRoot(),
    RouterModule.forChild([
      {
        path: CommonConstants.Routes.Application.ReviewApplication,
        component: ModuleComponent.ReviewApplicationComponent,
        resolve: { config: ConfigResolve }
      }
    ])
  ],
  providers: [
    // expose our Services and Providers into Angular's dependency injection
  ],
  exports: [
    SpacePipe
  ]
})
export class ApplicationModule {}
