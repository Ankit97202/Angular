import { SessionHandlerService } from './../../common/services/sessionHandler.service';
import { SpacePipe } from './../../common/utilities/pipes/SpacePipe.pipe';
import { environment } from './../../../environments/environment';
import { HttpInterceptor } from './../../common/services/httpInterceptor.service';
import { ConfigService } from './../../common/services/config.service';
import { FormValidator } from './../../common/services/formValidator.service';
import { NomineeDetailsService } from './../nomineeDetails/nomineeDetails.service';
import { FooterComponent } from '../../footer/footer.component';
import {HomeComponent} from '../../home/home.component';
import { Component, OnInit, ViewChildren, QueryList, OnChanges, Output, EventEmitter, AfterContentChecked } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivitiHandlerService } from '../../common/services/activitiHandler.service';
import { CommonConstants } from '../../common/utilities/commonConstants';
import { RouteHandlerService } from '../../common/services/routeHandler.service';
import { Formatter } from '../../common/services/formatter';
import { AppSummaryContent } from './content';
import { PopupComponent } from './../../common/utilities/popup/popup.component';
import { SharedService } from './../../common/services/sharedService';
import { FormControl } from '@angular/forms';
import { EmailService } from '../../common/services/email.service';
const Content_Types = {
  TnC: 'Terms & Conditions',
  disclaimer: 'Disclaimer'
};
@Component({
  providers:[HomeComponent ],
  templateUrl: './reviewApplication.template.html',
  styleUrls: ['./reviewApplication.style.css']
})
export class ReviewApplicationComponent implements OnInit, AfterContentChecked {
  @ViewChildren(PopupComponent) public PopupComponent: QueryList<any>;
  public TermsFormGroup: FormGroup;
  public IsValid: boolean;
  customClass = 'customClass';
  public isFirstOpen = true;
  public IsLaISPh = true;
  public conditions: boolean;
  public ContentPopup;
  public Config = { show: false, backdrop: 'static' };
  public CurrentContent: Array<string>;
  public IsLaActive: boolean;
  public genderDesPh: string;
  public genderDesLa: string;
  public NoOfRiders: number;
  public ReviewApplicationBiUrl: string;
  public areYouNRIPh: string;
  public areYouNRILa: string;
  public formattedPHDOB: string;
  public formattedLADOB: string;
  public ParticipantPhOccupation: string;
  public ParticipantLaOccupation: string;
  public PlanSummaryObject: ActivitiModel.PlanDetails;
  public PhAddressDetails: ReviewApplicationModel.AddressDetails[];
  public LaAddressDetails: ReviewApplicationModel.AddressDetails[];
  public showLoader = false;
  public SelectedPlanDetails: ReviewApplicationModel.SelectedPlanDetails;
  public addCritical: ReviewApplicationModel.addCritical;
  public OfferFlag: ReviewApplicationModel.OfferFlag;
  public ProposerDetails: Model.ProposerDetails;
  public NomineeDetails: ReviewApplicationModel.NomineeDetails;
  public SummaryResp: any;
  public InsuredForDesc: string;
  public ShowHelpText = false;
  public NomineeRelationship: any[];
  public PersonalDetailsFormGroup: FormGroup;
  public NomineeDetailsFormGroup: FormGroup;
  public grossPremium;
  public ButtonName = 'PAY NOW';
  public PaymentDetails = null;
  private _requestId: string;
  public BagicPaymentURL: any;
  public PaymentIdReceived = false;
  public RetryPaymentStatus;
  public ModifiedPayNow: any;
  public PaymentObj: ReviewApplicationModel.PaymentObject;
  public Email: any;
  private _emailId: string;
  public tncAcceptedFlag: boolean;
  public payFlag = false;
  public PayloadCritical: any;
  public ShowNoDataLoaderLoader: boolean= true;
  public ReviewAppDetails: ReviewApplicationModel.ReviewApplicationDetails;
  // Private Variables
  private _inputPayload: ReviewApplicationModel.ReviewApplicationInputPayload;
  private _outputPayload = <ReviewApplicationModel.ReviewApplicationOutputPayload>{};
  public oldEmail :string;
  emailLength: any;
  constructor(
    private _formBuilder: FormBuilder,
    public FormValidators: FormValidator,
    private _activitiHandler: ActivitiHandlerService,
    private _sessionHandlerService: SessionHandlerService,
    private _sharedService: SharedService,
    private _formatter: Formatter,
    private _routerService: RouteHandlerService,
    private _httpInterceptor: HttpInterceptor,
    private _nomineeDetailsService: NomineeDetailsService,
    private _emailService: EmailService,
    private homeComponent: HomeComponent
  ) {}
  public ngOnInit() {
    this.buildTermsFormGroup();
    this.buildFormGroup();
    this.fetchNomineeRelationship();
    this.getDetails();
    this.initContentPopup();
  }
  public ngAfterContentChecked() {
    if(this.PersonalDetailsFormGroup.controls['emailID'].value !==null)
     this.emailLength = this.PersonalDetailsFormGroup.controls['emailID'].value.length;
    // this.PersonalDetailsFormGroup.controls['emailID'].valueChanges.subscribe(() => {
    //   const emailID = this.PersonalDetailsFormGroup.controls['emailID'].value;
    //   document.getElementById('emailID').setAttribute('style', 'font-size:' + (emailID.length > 18 ? 'small-font' : '1.4rem'));
    // })
  }
  public setEmail(email) {
    this._emailService.setEmail({textVal: email});
  }
  public ModifyDetails(taskKey: string) {
    this.Email = this.PersonalDetailsFormGroup.controls['emailID'].value;
    this.setEmail(this.Email);
    this.PayloadCritical = this.PrepareCriticalIllnessPayload(this.SummaryResp);
    this.markTaskComplete(this.PayloadCritical, 'Modify');
  }
  private PrepareCriticalIllnessPayload(resp) {
    const payload = {
      proposerDetails: resp.proposerDetails,
      rider: [
        { }
      ]
    };
    return payload;
  }
  // Show Modal Popup
  public ShowChildModal(id: string, contentType?: string): void {
    if (contentType) {
      this.initContentPopup();
      this.ContentPopup.Title = Content_Types[contentType];
      this.CurrentContent = AppSummaryContent.Terms_Conditions_Content;
    }
    this.getModalDirectiveInstanceBasedOnId(id).show();
  }
  // Hide Modal Popup
  public HideChildModal(id: string): void {
    this.tncAcceptedFlag = true;
    this.payNowValidate();
    this.TermsFormGroup.controls['conditions'].setValue(true);
    this.getModalDirectiveInstanceBasedOnId(id).hide();
  }
  // Validate Space of Field
  public ValidateSpace($event) {
    if ($event.keyCode === 32) {
      return false;
    } else {
      return this.FormValidators.IsAlphabet($event);
    }
  }
  // Next Button Click
  public Next(formValue: FormData) {
    const payload = {
      tncAcceptedFlag: formValue['conditions'],
    };
    this.markTaskComplete(payload, '');
  }
  // Back Button Click
  public Back() {
    this.markTaskComplete(null, 'Back');
  }
  // Set lastname conditonally true
  public onInputEntry(nominee) {
    if (nominee.trim().includes(' ') === true) {
      this.payNowValidate();
    } else {
      this.payFlag = false;
    }
  }
  public onSelect() {
    this.payNowValidate();
  }
  // Set Terms & Conditions Form Controls Value
  public AgreeTerms(controlName: boolean, formValue: FormData) {
    this.tncAcceptedFlag = controlName;
    this.payNowValidate();
  }
  // Building Nominee Form Group
  private buildFormGroup() {
    const mustHaveLastName = (control: FormControl) => {
      return !control.value.trim() || control.value.trim().includes(' ')
        ? null
        : { lastNameMandatory: true };
    };
    this.PersonalDetailsFormGroup = this._formBuilder.group({
      emailID: ['', Validators.compose([Validators.required])]
    });
    this.PersonalDetailsFormGroup.valueChanges.subscribe(() => {
      this.IsValid = this.PersonalDetailsFormGroup.valid;
      this.PaymentObj.emailId = this.PersonalDetailsFormGroup.controls['emailID'].value;
      this.ProposerDetails.applicationApplicantId = this.ProposerDetails.applicationApplicants.length !== 0 ?
                                                    this.ProposerDetails.applicationApplicants[0].applicationApplicantId : null;
      this.payNowValidate();
    });
    this.NomineeDetailsFormGroup = this._formBuilder.group({
      nomineeName: ['', [ Validators.required, mustHaveLastName]],
      relationship: ['', Validators.compose([Validators.required])]
    });
    this.NomineeDetailsFormGroup.valueChanges.subscribe(() => {
      this.IsValid = this.NomineeDetailsFormGroup.valid;
    });
  }
  /*Initialize Popup*/
  private initContentPopup() {
    this.ContentPopup = {
      Id: 'content-modal',
      Title: '',
      Config: <CustomModalOptions>{ show: false, closeOption: true }
    };
    console.log(
      'this.config.closeOption:',
      this.ContentPopup.Config.closeOption
    );
  }
  /* Getting Popup Instances Based on Id */
  private getModalDirectiveInstanceBasedOnId(popupId: string): any {
    return this.PopupComponent.filter((item: PopupComponent, index: number) => {
      return item.id === popupId;
    })[0].modalControl;
  }
  // Setting TnC Data To the Form Group
  private setUserInput(userInput: ReviewApplicationModel.ReviewApplicationOutputPayload) {
    if (userInput.tncAcceptedFlag !== undefined)
    {
     this.conditions = userInput.tncAcceptedFlag;
     this.tncAcceptedFlag = userInput.tncAcceptedFlag;
    }
    const name = [
      this.NomineeDetails.firstName,
      this.NomineeDetails.lastName
    ]
          .join(' ')
      .trim();
    this.NomineeDetailsFormGroup.controls['nomineeName'].setValue(name);
    this.NomineeDetailsFormGroup.controls['relationship'].setValue(this.NomineeDetails.relationship);
    this.PersonalDetailsFormGroup.controls['emailID'].setValue(this.ProposerDetails.emailDetails !== null  ?
                                                                this.ProposerDetails.emailDetails[0].emailAddress : null);
     this.payNowValidate();
  }
  private createPayload(){
    const nomineeName = this.NomineeDetailsFormGroup.controls['nomineeName'].value;
    const nomineeFormDetails = {
      relationship: this.NomineeDetailsFormGroup.controls['relationship'].value,
      firstName: this._formatter.GetName('first', nomineeName),
      middleName: this._formatter.GetName('middle', nomineeName),
      lastName: this._formatter.GetName('last', nomineeName),
    }
    this.ProposerDetails.emailDetails = [this.getEmailDetails()];
    this.ReviewAppDetails = {
      nomineeDetails: nomineeFormDetails,
      tncAcceptedFlag: this.tncAcceptedFlag,
      proposerDetails : this.ProposerDetails,
      oldEmail: this.oldEmail !== undefined ||  this.oldEmail !==null  ? this.oldEmail  :this.PersonalDetailsFormGroup.controls['emailID'].value,
      newEmail: this.PersonalDetailsFormGroup.controls['emailID'].value
    };
  }
  // Get relation details of nominee when page loads
  private fetchNomineeRelationship() {
    this._nomineeDetailsService.FetchNomineeRelationships().subscribe((response) => {
        if (!response.errorBean) {
          this.NomineeRelationship = response.payload;
        }
      });
  }
  // Getting Email details
  private getEmailDetails(): ActivitiModel.EmailDetails {
    const emailId = this.PersonalDetailsFormGroup.controls['emailID'].value || this._emailId;
    const emailDetails: ActivitiModel.EmailDetails = {
        key: 0,
        emailAddress: emailId,
        isVerified: 0,
        idPriority: 1,
        type: CommonConstants.APPLICANT_EMAIL_TYPES.Personal_1,
        applicantKey: 0
    };
    return emailDetails;
}
  // Get the details of page when page loads
  private getDetails() {
    this.showLoader = true;
    this._activitiHandler.GetTaskDetails().subscribe((resp: ActivitiModel.MTResponse<any>) =>
    {
        if (!resp.errorBean) {
          this.ShowNoDataLoaderLoader =false;
          this.showLoader = false;
          this.ProposerDetails = resp.payload.proposerDetails;
          this.oldEmail = resp.payload.proposerDetails.emailDetails !==null ? resp.payload.proposerDetails.emailDetails[0].emailAddress :null;
          this.SelectedPlanDetails = resp.payload.selectedPlanDetails;
          this.NomineeDetails = resp.payload.nomineeDetails;
          this.OfferFlag = resp.payload.offerFlag;
          this.SummaryResp = resp.payload;
          let journeyType = CommonConstants.DEFAULT_EMPTY_STRING;
          journeyType = this._sessionHandlerService.GetSession(CommonConstants.CookieKeys.JourneyType);
        if (journeyType === CommonConstants.DEFAULT_EMPTY_STRING) {
          if (resp.payload.newTokens) {  // TODO add resume condition
            this.setUserAuthToken(resp.payload);
          }
        }
          const name = [
            this.NomineeDetails.firstName,
            this.NomineeDetails.lastName
          ];
          this.PaymentObj = {
            amount: this.SelectedPlanDetails.plan.totalGrossPremium,
            mobileNumber: resp.payload.proposerDetails.phoneNumberDetails[0].number,
            emailId: resp.payload.proposerDetails.emailDetails !== null ?
                     resp.payload.proposerDetails.emailDetails[0].emailAddress : this.PersonalDetailsFormGroup.controls['emailID'].value
          };
          if (resp.userInput) {
            this.setUserInput(resp.userInput);
          } else if(resp.payload){
            this.setUserInput(resp.payload);
          }
        }
      }
    );
  }
  // Build Terms & Conditions form Group
  private buildTermsFormGroup() {
    this.TermsFormGroup = this._formBuilder.group({
      conditions: ['', Validators.compose([Validators.required])],
    });
  }
  // Mark Task As Completed Activiti Call
  private markTaskComplete(
    data: ReviewApplicationModel.ReviewApplicationOutputPayload,
    taskName: string
  ) {
    this.showLoader = true;
    this._activitiHandler
      .MarkTaskAsCompleted(data, taskName)
      .subscribe((mtResponse: ActivitiModel.MTResponse<any>) => {
        this.showLoader = false;
        if (!mtResponse.errorBean) {
          this._routerService.RouteToNextTask(mtResponse.nextTaskKey);
        }
      });
  }
  private setUserAuthToken(responseData: any) {
    if (responseData) {
      this._sessionHandlerService.SetSession(
        CommonConstants.CookieKeys.JWToken,
        responseData.newTokens.tokens[0].token
      );
      this._sessionHandlerService.SetSession(
        CommonConstants.CookieKeys.GuardKey,
        responseData.newTokens.tokens[0].guardKey
      );
      this._sessionHandlerService.SetSession(
        CommonConstants.CookieKeys.GuardToken,
        this._formatter.ConvertGuradKeyToGuardToken(
          responseData.newTokens.tokens[0].guardKey
        )
      );
    }
  }
  private payNowValidate() {
    if (this.tncAcceptedFlag === true && (this.NomineeDetailsFormGroup.controls['nomineeName'].value.trim().includes(' ')) === true
    && this.NomineeDetailsFormGroup.controls['relationship'].value !== null
    && this.PersonalDetailsFormGroup.controls['emailID'].invalid === false) {
      this.payFlag = true;
    } else {
      this.payFlag = false;
    }
    this.createPayload();
  }
}
