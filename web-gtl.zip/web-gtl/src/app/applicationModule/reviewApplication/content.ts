export class AppSummaryContent {
  // tslint:disable-next-line:max-line-length
  public static Terms_Conditions_Content = ['I/We hereby declare on behalf of proposer and on behalf of all persons proposed to be insured that the above statements, declaration, warranties and or particulars given by me are true and complete in all respects to the best of my knowledge and belief. I/We am/are authorized to propose on behalf of these other persons.',
      // tslint:disable-next-line:max-line-length
      'I understand that the information provided by me will form the basis for of the insurance policy and is subject to the Board approved underwriting policy of the Company',
      // tslint:disable-next-line:max-line-length
      'I/we have understood that the statements and particulars given in this proposal form and this declaration shall be held to be promissory and shall be the basis of the insurance contract between me/us and the Bajaj Allianz Life Insurance Company Ltd [Company] and the Insured Beneficiary/Group Member and that, if it is found that any of the statements or particulars in this proposal form or other documents are incorrect, untrue, suppressed any information or provided misleading/false information in any respect on any material/ immaterial facts/particulars, to the grant of a cover or otherwise, the Company shall have no liability under the insurance contract or the policy document thereunder, apart from Company\'s right to cancel my/our policy and the premium paid by me/us shall be forfeited by the Company.',
      // tslint:disable-next-line:max-line-length
      'I/we also do hereby agree and undertake to immediately inform the Company any changes in this proposal form/documents/ risk proposed for insurance after the submission of this proposal form.',
      // tslint:disable-next-line:max-line-length
      'I/we do hereby agree to accept the Standard Terms and Conditions and form of the policy issued by Company in such cases. I/We hereby authorize company that all Standard Terms & Conditions of policy can be displayed in the website of company that enables access by me/us if I/We want to know the terms and conditions of policy displayed on website.',
      // tslint:disable-next-line:max-line-length
      'The Policy will be valid only for one year and will be renewable annually.',
      // tslint:disable-next-line:max-line-length
      'There is no Maturity/Surrender benefit under the scheme.',
      // tslint:disable-next-line:max-line-length
      'If the quote has been finalised, an acceptance from the Master Policy Holder would be required via E-Mail or on a Hard copy and the same should be forwarded along with the duly filled and signed proposal form & scheme rules.',
      // tslint:disable-next-line:max-line-length
      'At the time of finalization of the quote, the Nominee details would be required.',
      // tslint:disable-next-line:max-line-length
      'Rates are subject to change in case of any changes in the member statistics received from the Bajaj Finserv Direct Limited, or in case of adverse claims experience.',
      // tslint:disable-next-line:max-line-length
      'At the time of renewal of the Master Policy, rates would be finalised only after reviewing the previous claims experience of the group.',
      // tslint:disable-next-line:max-line-length
      'New joinees would be considered as additions. Deletion of members during the term of the policy will not be considered. In case the member pays the premium, the member cover shall be provided for one year from the date of commencement of risk of the member else the premium shall be charged proportionately from the date of commencement of risk of the member up to the next policy anniversary.',
      // tslint:disable-next-line:max-line-length
      'This quote is valid for 1 month from the date of issuance of the quote.',
      // tslint:disable-next-line:max-line-length
      'Bajaj Allianz Life Insurance Company Limited has considered the claims statistics as furnished by the Master Policy Holder / the intermediary/ reported to us till date. Please note that the quote would not be valid in case the furnished claims statistics is found to be incorrect or for some of the claims intimation has not been submitted to us till date.',
      // tslint:disable-next-line:max-line-length
      'In case the member is diagnosed as suffering from any of the specified 11 critical illnesses after the waiting period of 90 days, then the chosen Rider Sum Assured will be paid. The diagnosis of the Critical Illness needs to be confirmed by a registered Medical Practitioner appointed by the Company and must be supported by acceptable clinical, radiological, histological and laboratory evidence. The Company should be informed of the critical illness within 30 days of diagnosis of the Critical Illness. No subsequent death benefit will be paid for the member after the payment of the rider benefit, subject to Rider SA not exceeding the SA corresponding to the 100% of the premium under the Base Plan for each life.',
      // tslint:disable-next-line:max-line-length
      'Minimum Age at entry for the ACI rider benefit is 18 Years and Maximum Age at entry is 65 Years.',
      // tslint:disable-next-line:max-line-length
      'The insurer shall be liable to pay death benefit subject to written notice within 180 days of the death of the member.',
      // tslint:disable-next-line:max-line-length
      'There is no exit clause applicable in Group Term Life Insurance.  Customer can opt for free look cancellation within 15 days on receipt of certificate of insurance.',
      // tslint:disable-next-line:max-line-length
      'No Risk to be assumed unless premium is received in advance.'
  ];
}
