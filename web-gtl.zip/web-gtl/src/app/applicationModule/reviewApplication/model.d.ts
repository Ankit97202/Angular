declare module ReviewApplicationModel {
    export interface ReviewApplicationInputPayload {
        GTLPlanDetailsResponse : ReviewApplicationModel.PlanDetailsResponse;
        GTLAddressRequest : ReviewApplicationModel.GTLAddressRequest;
        phAgeChanged?: boolean;
        laAgeChanged?: boolean;
        newTokens?: any;
    }
    export interface ReviewApplicationOutputPayload {
        disclaimerFlag?: boolean;
        tncAcceptedFlag?: boolean;
        applicationId?: string;
        phAgeChanged?: boolean;
        laAgeChanged?: boolean;
        addCritical?: addCritical[];
    }
    export interface BiDetails{
        policyDocumentUrl: string;
    }
    export interface addCritical {
      rider: {
        code: string;
      }[];
    }
    export interface PlanDetailsResponse {
        selectedPlanDetails: ActivitiModel.PlanDetails;
    }
    export interface GTLAddressRequest{
        lifeAssured : ReviewApplicationModel.ParticipantAddressDetails;
        proposer : ReviewApplicationModel.ParticipantAddressDetails;
    }
    export interface ParticipantAddressDetails{
        age? : string;
        gender? : string;
        address : ReviewApplicationModel.AddressDetails[];
    }
    export interface ReviewApplicationDetails{
        tncAcceptedFlag?: boolean;
        nomineeDetails?: nomineeDetails;
        proposerDetails?: any;
        oldEmail: string,
        newEmail: string
    }
    export interface nomineeDetails {
        firstName?: string;
        middleName?: string;
        lastName?: string;
        relationship?: string;
        dob?: string;
    }
    export interface AddressDetails {
        addressLine1: string;
        addressLine2: string;
        areaLocalityName: string;
        city: string;
        cityCode: string;
        flatNumber: string;
        houseNumber: string;
        pinCode: string;
        state: string;
        stateCode: string;
        street: string;
        type: string;
    }
    export interface ProposerDetails {
        age? : string;
        dob? : string;
        firstName? : string;
        lastName? : string;
        middleName?: string;
        gender?: string;
        genderDesc?: string;
        mobileNumber? : string;
        maritalStatusdesc?: string;
        email?: string;
        passportNumber?: string;
        aadhaarCardNumber?: string;
        pan?: string;
        occupationtype?: string;
        occupationDesc?: string;
        income?: string;
        mailingAddress?: AddressDetails;
        permanentAddress?: string;
        pinCode?: string;
      }
      export interface NomineeDetails {
        firstName?: string;
        middleName?: string;
        lastName?: string;
        dateOfBirth?: string;
        relationship: string;
      }
      export interface SelectedPlanDetails {
        oldGrossPremium: number;
        plan: Plan;
      }
      export interface OfferFlag {
        offerFlag?: boolean;
      }
      export interface Plan {
        sumAssured?: number;
        planCode?: string;
        variantCode?: string;
        netPremium?: number;
        gst?: number;
        grossPremium?: number;
        zone?: string;
        policyTerm?: number;
        displayName?: string;
        rider?: Rider[];
        totalGrossPremium: number;
      }
      export interface Rider {
        code?: string,
      grossPremium?: number,
      gst?: number,
      maxSA?: number,
      minSA?: number,
      netPremium?: number,
      sumAssured?: number,
      }
      export interface PaymentObject {
        mobileNumber?: string;
        emailId?: string;
        payNowFlag?: boolean;
        applicationId?: number;
        orderId?: string;
        paymentId?: string;
        mobilenumber?:string;
        personalEmailId?: string;
        amount?:number;
    }
    export interface MTResponse<T> {
        payload: T;
        status: string;
        nextTaskKey?: string;
        routesInfo?: routesInfo;
        progressInfo: ProgressStateResponse;
        errorBean: [{ errorCode: string, errorMessage: string }];
        userInput?: any;
        errorDetails:[{ code: string; description: string }];
    }
    export interface routesInfo {
        mainRoute: string;
        subRoute: string;
    }
    export interface ProgressStateResponse {
        payload: ProgressStateInfo[];
        status: string;
        nextTaskKey?: string;
        errorBean: [{ errorCode: string, errorMessage: string }];
    }
    export interface ProgressStateInfo {
        name: string;
        active: boolean;
        value: number;
    }
}
