declare module Model {
    export interface PersonalDetailsInputPayload {
        processInstanceDetails?: string;
        applicantKey?: string;
        applicationApplicantId?: string;
        applicationId?: string;
        isLaEqualsPh?: boolean;
        healthPlanDetails: Model.HealthPlanDetails;
        proposerDetails?: ActivitiModel.ParticipantDetails;
        insuredDetails: InsuredDetails[];
        newTokens?: any;
        insuringFor?: number;
        GTLPaymentMethod: string;
        insuredCount?:number;
    }
    export interface PersonalDetailsOutputPayload {
        proposerDetails: Model.InsuredDetails;
        insuredDetails: InsuredDetails[];
    }
    export interface PersonalDetailsEmitterModel {
        participantDetails: Model.InsuredDetails,
        isFormValid: boolean;
    }
    export interface InsuredDetails {
      relationship?: string;
      age?: number;
      no?: number;
      firstName?: string;
      middleName?: string;
      lastName?: string;
      genderCode?: string;
      genederCode?: string;
      genderDesc?: string;
      emailDetails?: any[];
      phoneNumberDetails?: any[];
      panNumber?: string;
      presentInIndiaFlag?: string;
      indianPassportFlag?: string;
      maritalStatusDesc?: string;
      maritalStatusCode?: string;
      employmentDetails?: any;
      netSalary?: string;
      mailingAddress?: AddressDetails;
      addressDetails?: AddressDetails;
      apltHeight?: any;
      apltWeight?: number;
      pinCode?: string;
      gender?: string;
      dob?: string;
      dateOfBirth?: string;
  }
  export interface AddressDetails {
    addressLine1: string;
    addressLine2: string;
    areaLocalityName: string;
    city: string;
    cityCode: string;
    flatNumber: string;
    houseNumber: string;
    pinCode: string;
    state: string;
    stateCode: string;
    street: string;
    type: string;
  }
  export interface SelectedPlanDetails {
    sumAssured?: number;
    planCode?: string;
    variantCode?: string;
    displayName?: string;
    netPremium?: number;
    gst?: number;
    grossPremium?: number;
    policyTerm?: number;
    defaultPolicyTerm?: number;
    zone?: string;
    insuringFor?: number;
}
  export interface HealthPlanDetails {
    insuredCount?: number;
    insuredDetails: InsuredDetails[];
    proposerDetails: InsuredDetails;
    selectedPlanDetails: SelectedPlanDetails;
}
}
