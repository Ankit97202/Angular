import { Injectable } from '@angular/core';
import { ConfigService } from '../../common/services/config.service';
import { HttpInterceptor } from '../../common/services/httpInterceptor.service';
import { Observable } from 'rxjs/internal/Observable';
@Injectable({
    providedIn: 'root'
})
export class NomineeDetailsService {
    constructor(private _httpInterceptor: HttpInterceptor) { }
    public FetchNomineeRelationships(): Observable<ActivitiModel.MTResponse<any>> {
        const url = ConfigService.getInstance()
            .getConfigObject().APIURL.getNomineeRelationshipLookupService;
        return this._httpInterceptor.Get(url, true);
    }
    public FetchAppointeeRelationships(): Observable<ActivitiModel.MTResponse<any>> {
        const url = ConfigService.getInstance()
            .getConfigObject().APIURL.getApointeeRelationshipLookupService;
        return this._httpInterceptor.Get(url, true);
    }
}
