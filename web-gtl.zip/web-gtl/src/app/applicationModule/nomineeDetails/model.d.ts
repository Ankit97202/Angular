declare module Model {
  export interface NomineeDetailsInputPayload {
    selectedPlanDetails: Model.SelectedPlanDetails;
    nomineeDetails: Model.NomineeDetails;
  }
  export interface NomineeDetailsOutputPayload {
    nomineeDetails: Model.NomineeDetails;
    selectedPlanDetails: Model.SelectedPlanDetails;
  }
  export interface NomineeDetails {
    firstName?: string;
    middleName?: string;
    lastName?: string;
    dateOfBirth?: string;
    relationship: string;
  }
  export interface ProposerDetails {
    age: string;
    dob: string;
    firstName: string;
    lastName: string;
    middleName: string;
    gender: string;
    genderDesc: string;
    phoneNumberDetails: PhoneNumberDetails[];
    maritalStatusdesc: string;
    emailDetails?: EmailDetails[];
    passportNumber: string;
    aadhaarCardNumber: string;
    pan: string;
    occupationtype: string;
    occupationDesc: string;
    income: string;
    mailingAddress: string;
    permanentAddress: string;
    pinCode: string;
    applicationApplicantId?: number;
    applicationApplicants?: ApplicationApplicants[];
  }
  export interface ApplicationApplicants {
    applicationApplicantId?: number;
    applicationId?: number;
    residentialTypeCode?: any;
    residentialTypeDesc?: any;

  }
  export interface EmailDetails{
    emailAddress?: string;
  }
  export interface PhoneNumberDetails{
    number: string;
  }
}
