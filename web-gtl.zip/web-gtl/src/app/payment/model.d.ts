declare module Model {
    export interface PaymentDetails {
        orderId: string;
        balicRefNumber: string;
        paymentSuccessFlag?: boolean;
        paymentId?: string;
        premiumDetail:any;
    }
    export interface PaymentOutputPayload {
        orderId?: string;
        paymentId?: string;
    }
    export interface PaymentObject {
        mobileNumber?: string;
        emailId?: string;
        payNowFlag?: boolean;
        applicationId?: number;
        orderId?: string;
        paymentId?: string;
        mobilenumber?:string;
        personalEmailId?: string;
        amount?:number;
        application ? :number;
    }
    export interface PaymentClosedPayload {
        applicationId: number;
        orderId: string;
        paymentId?: string;
        mobileNumber:string,
        emailId: string,
        amount:number
    }
}
