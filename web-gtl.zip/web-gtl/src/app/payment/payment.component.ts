import { SessionHandlerService } from './../common/services/sessionHandler.service';
import { Formatter } from './../common/services/formatter';
import { Component, Input, OnChanges, OnInit,ViewChildren,QueryList } from '@angular/core';
import { PaymentService } from './payment.service';
import { CommonConstants } from './../common/utilities/commonConstants';
import { ActivitiHandlerService } from './../common/services/activitiHandler.service';
import { RouteHandlerService } from './../common/services/routeHandler.service';
import { environment } from '../../environments/environment';
import { PaymentStatusService } from './../paymentReview/paymentStatus.service';
import { PopupComponent } from '../common/utilities/popup/popup.component';
declare var Razorpay: any;
const Old_Key = 'rzp_test_aDFuTkMrVvaeEx';
@Component({
    selector: 'app-payment-link',
    templateUrl: './payment.template.html',
    styleUrls: ['./payment.style.css'],
    providers: [PaymentService,PaymentStatusService]
})
export class PaymentComponent implements OnChanges, OnInit {
    @Input() public PaymentObject: Model.PaymentObject;
    @Input() public ReviewApplicationDetails: any;
    @Input() public ButtonName: string;
    @Input() public TncFlag: boolean;
    @Input() public PaymentFailObject: Model.PaymentClosedPayload;
    public Amount: number;
    // Private Variables
    private _paymentObject;
    private _orderId: string;
    private _bagicRefNum: string;
    private _mobileNumber: string;
    private _emailId: string;
    public PaymentClosed: boolean;
    public PaymentIdReceived = false;
    public MainLoadingText = 'Stay with us. We\'re almost done...';
    public ShowPaymentLoader: boolean;
    public PaymentReviewPopUpData;
    public OldPremium: number;
    public NewPremium: number;
    public IsPremiumChange: boolean;
    public IsReview :boolean = false;
    @ViewChildren(PopupComponent) public PopupComponent: QueryList<any>;
    // Constructor
    constructor(
        private _paymentService: PaymentService,
        private _sessionService: SessionHandlerService,
        private _activitiHandler: ActivitiHandlerService,
        private _routerService: RouteHandlerService,
        private paymentStatusService: PaymentStatusService,
        public _formatter: Formatter,
    ) { }
    // On Component Init
    public ngOnChanges() {
        this.addPaymentScript();
        this.setValues();
        this.initPaymentReviewModal();
    }
    public ngOnInit() {
      let data:any = {
        applicationId:this._sessionService.GetSession(CommonConstants.CookieKeys.LoanApplicationId),
        insProdType:'LI'
    }
     this.fetchPaymentStatus(data);
    }
    public PayByRazorPay(event) {
       if (this.PaymentFailObject) {
             this.getPaymentDetails();
       } else {
        this.markTaskComplete(this.ReviewApplicationDetails, 'Save');
       }
        this.PaymentIdReceived =true;
    }
    public btnReview() {
      this.IsReview =true;
      this.markTaskComplete(null, 'Review');
      this.getModalDirectiveInstanceBasedOnId(this.PaymentReviewPopUpData.Id).hide();
  }
  public Proceed(){
    this.getModalDirectiveInstanceBasedOnId(this.PaymentReviewPopUpData.Id).hide();
    const razorPayObj = new Razorpay(this._paymentObject);
    razorPayObj.open();
  }
     /*Initializee Renewal Popup*/
     private initPaymentReviewModal() {
      this.PaymentReviewPopUpData = {
          Id: 'nonrenewal-modal',
          Title: 'Review Premium Info',
          Config: <CustomModalOptions>{ show: false, closeOption: true, backdrop: 'static' }
      };
      console.log('this.config.closeOption:', this.PaymentReviewPopUpData.Config.closeOption);
  }
    // Setting Payment Input Object
    private setValues() {
        const paymentObject = this.PaymentObject !==undefined ? this.PaymentObject :this.PaymentFailObject;
        if (paymentObject) {
            this.Amount = paymentObject.amount;
            this._mobileNumber = paymentObject.mobileNumber;
            this._emailId = paymentObject.emailId;
        } else {
            console.error('ERROR:: No payment object received.');
        }
    }
    // Adding Razorpay JS to the file
    private addPaymentScript() {
        const path = 'https://checkout.razorpay.com/v1/checkout.js';
        const scriptTag = document.createElement('script');
        scriptTag.setAttribute('src', path);
        scriptTag.setAttribute('type', 'text/javascript');
        document.body.appendChild(scriptTag);
    }
    // Creating Payment Object
    private createPaymentObject() {
        this._paymentObject = {
            key: environment['PaymentKey'],
            amount: (this.Amount * 100), // 2000 paise = INR 20
            name: 'Bajaj Finserv Direct Ltd',
            description: 'Insurance Premium',
            image: null,
            handler: (response) => {
                console.log(response);
                const payload: Model.PaymentOutputPayload = {
                    orderId: this._orderId,
                    paymentId: response.razorpay_payment_id
                };
                this.PaymentIdReceived = false;
                this.markTaskComplete(payload, '');
            },
            prefill: {
                contact: this._mobileNumber,
                email: this._emailId
            },
            notes:{
              APPLICATIONNO: this._bagicRefNum,
          },
            modal: {
                escape: false,
                ondismiss: (response) => {
                    const payload: Model.PaymentObject = {
                        applicationId: null,
                        orderId: this._orderId,
                        paymentId: null,
                        mobilenumber: this._mobileNumber,
                        personalEmailId: this._emailId,
                        amount: this.Amount
                    };
                    this.PaymentClosed = true;
                    this.markTaskComplete(payload, 'paymentClosed');
                }
            },
            order_id: this._orderId,
            theme: {
                color: '#034263'
            }
        };
    }
    private getPaymentDetails() {
        const appId = this._sessionService.GetSession(CommonConstants.CookieKeys.LoanApplicationId);
        this.setValues();
        if (appId) {
            if(!this.IsReview ){
            this._paymentService.GetPaymentDetails(appId).subscribe((mtResponse: ActivitiModel.MTResponse<Model.PaymentDetails>) => {
                if (!mtResponse.errorBean) {
                    this._orderId = mtResponse.payload.orderId;
                    this._bagicRefNum = mtResponse.payload.balicRefNumber;
                    this.createPaymentObject();
                    if(mtResponse.payload.premiumDetail){
                      this.IsPremiumChange = mtResponse.payload.premiumDetail !== null ? true : false;
                      this.OldPremium = mtResponse.payload.premiumDetail.oldPremium;
                      this.NewPremium = mtResponse.payload.premiumDetail.newPremium;
                      this.PaymentIdReceived = false;
                      this.getModalDirectiveInstanceBasedOnId(this.PaymentReviewPopUpData.Id).show();
                    }
                    else{
                      const razorPayObj = new Razorpay(this._paymentObject);
                      razorPayObj.open();
                    }
                } else
                  this.PaymentIdReceived =false;
            });}
        } else {
            console.error('ERROR::Unable to find application Id.');
        }
    }
    private markTaskComplete(data: any, actionName: string) {
        this._activitiHandler.MarkTaskAsCompleted(data, actionName).subscribe((mtResponse: ActivitiModel.MTResponse<any>) => {
            if (!mtResponse.errorBean) {
                if (mtResponse.nextTaskKey === 'gtlDetailsPage') {
                this.getPaymentDetails();
                this.PaymentIdReceived = true;
                } else {
                this._routerService.RouteToNextTask(mtResponse.nextTaskKey, null, null, true);
                }
            }
            if(this.IsReview){
              location.reload();}
        });
    }
    private fetchPaymentStatus(data: any) {
        this.paymentStatusService
            .FetchPaymentStatus(data)
            .subscribe((resp: Model.MTResponse<any>) => {
                let mtPaymentStatusResponse: Model.MTResponse<any> = resp;
                if (mtPaymentStatusResponse.payload !== null) {
                    if (mtPaymentStatusResponse.payload.paymentStatus === 'Success') {
                        this.markTaskComplete(null, 'PaymentSuccess');
                        this.ShowPaymentLoader = true;
                   }
                }
            });
    }
     /* Getting Popup Instances Based on Id */
     private getModalDirectiveInstanceBasedOnId(popupId: string): any {
      return this.PopupComponent.filter((item: PopupComponent, index: number) => {
          return item.id === popupId;
      })[0].modalControl;
  }
}
