import { ConfigService } from './../common/services/config.service';
import { HttpInterceptor } from '../common/services/httpInterceptor.service';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
@Injectable({
    providedIn: 'root'
})
export class PaymentService {
    constructor(
        private _httpInterceptor: HttpInterceptor
    ) { }
    public GetPaymentDetails(applicationId: string,data? :any): Observable<ActivitiModel.MTResponse<any>> {
        let url = ConfigService.getInstance().getConfigObject().APIURL.getPaymentDetails;
        url = url.replace('{applicationId}', applicationId);
        return this._httpInterceptor.Post(url, true);
    }
}
