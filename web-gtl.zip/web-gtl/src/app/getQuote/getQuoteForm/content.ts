export class CriticalIllnessContent {
  public static Critical_Content = ['Cancer of specified severity',
    'First heart attack – of specified severity',
    'Open chest CABG',
    'Kidney failure requiring regular dialysis',
    'Stroke resulting in permanent symptoms',
    'Major organ/ bone marrow transplant',
    'Permanent paralysis of limbs',
    'Multiple sclerosis with persisting symptoms',
    'Aortic surgery',
    'Primary pulmonary hypertension',
    'Alzheimer’s disease'
  ];
}
