declare module GetQuoteModel {
    export interface InputPayloadGetQuote{
        planCode: string;
        recommendedPlans: RecommendedPlans;
        productFeatures: ProductFeatures[];
        groupTermLifeOutput: GroupTermLifeOutput[];
    }
    export interface ProductFeatures {
        featuredesc: string;
        featurevalue: string;
        helptext: string;
        featurerank: number;
    }
    export interface FilterCriteria {
        sumAssuredAmount: string;
        AgreegatedeductibleAmount: string;
        policyTerm: string;
        netPremium: string;
        gst: string;
        grossPremium: string;
        totalPremium: string;
    }
    export interface Rider {
      code?: string,
      grossPremium?: number,
      gst?: number,
      maxSA?: number,
      minSA?: number,
      netPremium?: number,
      sumAssured?: number,
    }
    export interface InsuranceDetails {
        planCode: string;
        insuringFor: number;
    }
    export interface InsuredDetails {
      relationship: string;
      firstName: string;
      lastName: string;
      age: number;
    }
    export interface RecommendedPlans{
        sumAssuredList :SumAssuredList[];
    }
    export interface SumAssuredList {
        selected: string;
        sumAssured: number;
        agreegatedDed: number;
        policyTerm:number;
        netPremium:number;
        gst:number;
        grossPremium:number;
        totalNetPremium:number;
        totalGrossPremium:number;
        totalGST:number;
        rider: Rider[];
        }
     export interface BuynowPlans {
       proposerDetails: ProposerDetails;
       selectedPlanDetails: SelectedPlanDetails;
     }
     export interface EmailQuotePlans {
      businessType: string;
      userAction: string;
      channelType: string;
      selectedPlanDetails: SelectedPlanDetails;
      utmParams: UTMParams;
      proposerDetails: PersonalDetails;
      insuredDetails?: InsuredDetails[];
     }
    export interface PersonalDetails {
        mobileNumber?: string;
        gender?: string;
        email: string;
        dob?: string;
        age?: number;
    }
    export interface GroupTermLifeOutput {
        applicationId?: string;
        plan: Plan;
        premiumRevised?: string;
        oldGrossPremium?: number;
        errorDetails: any;
        action: boolean;
    }
   export interface SelectedPlanDetails {
        plan: Plan;
        oldGrossPremium: string;
    }
    export interface Plan {
        sumAssured?: number;
        planCode?: string;
        variantCode?: string;
        netPremium?: number;
        gst?: number;
        grossPremium?: number;
        zone?: string;
        policyTerm?: number;
        displayName?: string;
        premiumPayingTerm?: string;
        code?: string;
        minSA?: number;
        maxSA?: number;
        rider: Rider[];
        totalGrossPremium: number;
      }
   export interface ProposerDetails {
        firstName?: string ;
        lastName?: string;
        mobileNumber?: string;
        gender?: string;
        emailDetails?: EmailDetails[];
        dob?: string;
        age?: number;
    }
    export interface EmailDetails{
      key?: number;
      emailAddress?: string;
      isVerified?: number;
      idPriority?: number;
      type?: string;
      applicantKey?: number;
  }
   export interface UTMParams {
        utmSource: string;
        utmMedium?: string;
        utmCampaign?: string;
        utmContent?: string;
        utmTerm?: string;
    }
    export interface calculatePremPlan {
        lifeAssured: {
            age: number;
            gender: string;
            dob: string;
        };
        applicationId: any;
        plan: {
            sumAssured: number;
            code: any;
            variantCode: any;
            policyTerm: any;
            premiumPayingTerm: any;
            rider?: Rider[];
        };
        oldGrossPremium: any;
        hlavailable: any;
    }
}
