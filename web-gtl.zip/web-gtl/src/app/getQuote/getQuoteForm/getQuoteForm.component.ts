import { Component, Input, EventEmitter, OnChanges, Output, OnInit, QueryList, ViewChildren, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, ValidatorFn } from '@angular/forms';
import { FormValidator } from '../../common/services/formValidator.service';
import { Formatter } from '../../common/services/formatter';
import { CommonConstants } from 'src/app/common/utilities/commonConstants';
import { PopupComponent } from '../../common/utilities/popup/popup.component';
import { convertToDoubleDigit } from '../../common/utilities/pipes/DoubleDigit.pipe';
import { ActivitiHandlerService } from '../../common/services/activitiHandler.service';
import { CookieHandlerService } from '../../common/services/cookieHandler.service';
import { RouteHandlerService } from '../../common/services/routeHandler.service';
import { NullTemplateVisitor } from '@angular/compiler';
import { SELECTOR } from 'ngx-bootstrap/modal/modal-options.class';
import { ToastrManager } from 'ng6-toastr-notifications';
import { addSpaceToDigit } from './../../common/utilities/pipes/SpacePipe.pipe';
import { GetQuoteFormService } from './getQuoteForm.service';
import { EmailService } from '../../common/services/email.service';
import { SharedService } from 'src/app/common/services/sharedService';
import { CriticalIllnessContent } from './content';
function RangeValidator(min: Number, max: Number): ValidatorFn {
    return (control: FormControl): { [key: string]: any } => {
        const input = Number(control.value);
        return (input > max || input < min) ?
            {
                'RangeError': `Age should be between ${min < 1 ? (Number(min) * 12 + ' Months')
                    : (min + ' Years')} and ${max} Years`
            } : null;
    };
}
const ageRanges = {
    entry: {
        adult: { min: 18, max: 80 },
        child: { min: 0, max: 25 }
    },
    renewable: {
        adult: { min: 18, max: 100 },
        child: { min: 0.25, max: 35 }
    }
};
const Content_Types = {
  TnC: 'Terms & Conditions',
  disclaimer: 'Disclaimer'
};
@Component({
    selector: 'app-get-quote-form',
    templateUrl: './getQuoteForm.template.html',
    styleUrls: ['./getQuoteForm.style.css'],
})
export class GetQuoteFormComponent implements OnInit {
    value = 0;
    public numbers = [1, 2, 3, 4];
    isOpened: boolean;
    editFlag: boolean;
    public editContent: boolean;
    @ViewChildren(PopupComponent) public PopupComponent: QueryList<any>;
    public ContentPopup;
    public AggregatePopup;
    public AirAmbPopup;
    public GetQuoteFormGroup: FormGroup;
    public IndividialRelationFormGroup: FormGroup;
    public FamilyRelationFormGroup: FormGroup;
    public InsuredData = [{ relationDesc: 'Self' },
    { relationDesc: 'Spouse' },
    { relationDesc: 'Father' },
    { relationDesc: 'Mother' },
    { relationDesc: 'Son' },
    { relationDesc: 'Daughter' }];
    public InsuredForText: string;
    public Config = { show: false, backdrop: 'static' };
    public GetInsuranceDetails: any;
    public GetInsuredDetails: any;
    public GetrecommendedPlans: GetQuoteModel.RecommendedPlans;
    public GetProductFeatures: GetQuoteModel.ProductFeatures[];
    public BuynowPlans: GetQuoteModel.BuynowPlans;
    public ProposerDetails: GetQuoteModel.ProposerDetails;
    public SelectedPlanDetails: GetQuoteModel.SelectedPlanDetails;
    public groupTermLifeOutput: GetQuoteModel.GroupTermLifeOutput;
    public ModifiedBuynowPlans: any;
    public IsEnabled = false;
    public calcPremiumFlag = false;
    public planCode: any;
    public defaultValue;
    public termInsurancePremium: any;
    public riderPremium: any;
    public riderMinSA: any;
    public riderMaxSA: any;
    public totalPremium: any;
    public SelectedValueOnSlider: number;
    public SliderStep: number;
    public EmailFormGroup: FormGroup;
    public SumAssuredFormGroup: FormGroup;
    public ReponsePlanDetails: any;
    public GetQuoteSliderFormGroup: FormGroup;
    public planDetails: any;
    public ErrorMessage: string = CommonConstants.DEFAULT_EMPTY_STRING;
    public IsGetQuoteFailed = false;
    public maxSA: any;
    public minSA: any;
    public sumAssureRequiredFlag: boolean;
    public notInRange: boolean;
    public EmailQuotePlans: GetQuoteModel.EmailQuotePlans;
    public ShowLoader = false;
    public CriticalContent: Array<string>;
    CalculateResp: Model.MTResponse<any>;
    email: any;
    age: number;
    gst: any;
    netPremium: any;
    sumAssuredChangeFlag: boolean;
    sumAssuredObj: { amount: number; mobileNumber: any; emailId: any; };
    min_input: number;
    max_input: number;
    riderMin_Input: number;
    riderMax_Input: number;
    validateSumAssured: any;
    riderSumAssured: number;
    sumAssuredValid = true;
    riderSumAssuredValid = true;
    calculatePremPlan: GetQuoteModel.calculatePremPlan;
    public domainInvalid = true;
    // Constructor
    constructor(
        public FormValidators: FormValidator,
        public toastr: ToastrManager,
        public FormatterObj: Formatter,
        public Formatters: Formatter,
        public _getQuoteFormService: GetQuoteFormService,
        public formatter: Formatter,
        private _formBuilder: FormBuilder,
        private _activitiHandler: ActivitiHandlerService,
        private _cookieHandler: CookieHandlerService,
        private _routerService: RouteHandlerService,
        private _emailService: EmailService,
        private _sharedService: SharedService
    ) {
        this.isOpened = true;
    }
    public onSelect() {
        if (this.isOpened) {
            this.isOpened = false;
        } else {
            this.isOpened = true;
        }
    }
    // On Component Init
    public ngOnInit() {
      this.getEmails();
      this.buildGetQuoteForm();
        this.buildFamilyFormGroup();
        this.buildEmailQuoteGroup();
        this.getTaskDetails();
        this.buildSumAssuredFormGroup();
    }
    public getEmails() {
      this._emailService.getEmail().subscribe(value => {
          this.email = value['textVal'];
      });
    }
    // Show Modal Popup
    public ShowChildModal(id: string, contentType?: string): void {
        if (contentType) {
            this.initContentPopup();
            this.ContentPopup.Title = Content_Types[contentType];
            this.CriticalContent = CriticalIllnessContent.Critical_Content;
        }
        this.getModalDirectiveInstanceBasedOnId(id).show();
    }
    private _mergeInsuredData(data, preData = {}) {
        return { ...data, ...preData };
    }
    public UpdateInsuredFor(id: string) {
        const val = this.IndividialRelationFormGroup.value;
        let insuredDetails = this.GetInsuredDetails;
        const children = { Son: 0, Daughter: 0 };
        insuredDetails = insuredDetails.map((ind) => {
            const relation = ind.relationship.charAt(0) + ind.relationship.slice(1).toLowerCase();
            const age = Array.isArray(val[relation]) ? val[relation][children[relation]++] : val[relation];
            ind.age = (age !== null ? age : ind.age);
            ind.insuredDeleted = (age === null || age === undefined);
            Array.isArray(val[relation]) ? delete val[relation][children[relation] - 1] : delete val[relation];
            return ind;
        });
        for (const relation in val) {
            if (val[relation]) {
                if (Array.isArray(val[relation])) {
                    insuredDetails.push(
                        ...val[relation]
                            .filter(v => !!v)
                            .map((ind, index) => ({
                                relationship: relation.toUpperCase(), age: val[relation][index],
                                dob: null, no: null, insuredDeleted: false
                            }))
                    );
                } else {
                    insuredDetails.push({
                        relationship: relation.toUpperCase(), age: val[relation],
                        dob: null, no: null, insuredDeleted: false
                    });
                }
            }
        }
        this.GetInsuredDetails = insuredDetails.map(ind => ({ ...ind, age: Number(ind.age) }));
        this.markTaskComplete({
            insuredDetails: this.GetInsuredDetails
        }, 'editMemebers', false, () => {
            this.getTaskDetails();
        });
        this.IsEnabled = false;
        this.HideChildModal(id);
    }
    // Hide Modal Popup
    public HideChildModal(id: string): void {
        this.getModalDirectiveInstanceBasedOnId(id).hide();
    }
    public onIncr(data, age) {
        const newControl = new FormControl(age, Validators.compose([Validators.required,
        RangeValidator(ageRanges.entry.child.min, ageRanges.entry.child.max)]));
        const ctrl = this.IndividialRelationFormGroup.get(data.relationDesc);
        ctrl['push'](newControl);
        this.setFocus(data.relationDesc + ctrl['controls'].findIndex(cctrl => cctrl.invalid));
    }
    public onDecr(data) {
        const ctrl = this.IndividialRelationFormGroup.get(data.relationDesc);
        ctrl['removeAt'](ctrl['controls'].length - 1);
        this.setFocus(data.relationDesc + ctrl['controls'].findIndex(cctrl => cctrl.invalid));
    }
    public showSuccess() {
        this.toastr.successToastr('The quote has been mailed to your id', ' ', { showCloseButton: true });
    }
    public showToast(position: any = 'top-right') {
        this.toastr.infoToastr('Email Quote', 'EQ', {
            position: position
        });
    }
    // validate Personal Email ID domain
    public validatePersonalEmail($event: any) {
    this.domainInvalid = false;
    this._getQuoteFormService.ValidatePersonalEmailID($event.target.value).subscribe((response) => {
      const Response: ActivitiModel.MTResponse<any> = response;
      if (Response.errorBean == null && Response.payload.statusFlag) {
        this.domainInvalid = true;
        this.EmailFormGroup.controls['email'].setErrors(null);
        console.log('Response from validate personal emailID: ' + response.payload);
      } else {
        this.domainInvalid = false;
        this.EmailFormGroup.controls['email'].setErrors({domain: 'invalid'});
        console.log('error in validate Personal Email ID service');
      }
    });
  }
    // Setting sumassured data Data To the Form Group
    private setUserInput(userInput) {
     this.SumAssuredFormGroup.controls['sumAssure']
     .setValue(this.formatter.ToCurrency(userInput.groupTermLifeOutput.plan.sumAssured.toString()));
     this.maxSA = this.formatter.ConvertNumberToAmountExtraPlusL(userInput.groupTermLifeOutput.plan.maxSA);
     this.max_input = userInput.groupTermLifeOutput.plan.maxSA;
     this.minSA = this.formatter.ConvertNumberToAmountExtraPlusL(userInput.groupTermLifeOutput.plan.minSA);
     this.min_input = userInput.groupTermLifeOutput.plan.minSA;
     this.termInsurancePremium = userInput.groupTermLifeOutput.plan.grossPremium;
     this.gst = userInput.groupTermLifeOutput.plan.gst;
     this.netPremium = userInput.groupTermLifeOutput.plan.netPremium;
     // Setting rider data Data To the Form Group
     this.SumAssuredFormGroup.controls['criticalillness']
      .setValue(this.formatter.ToCurrency(userInput.groupTermLifeOutput.plan.rider[0].sumAssured.toString()));
     this.riderMinSA = this.formatter.ConvertNumberToAmountExtraPlusL(userInput.groupTermLifeOutput.plan.rider[0].minSA);
     this.riderMin_Input = userInput.groupTermLifeOutput.plan.rider[0].minSA;
     this.riderMaxSA = this.formatter.ConvertNumberToAmountExtraPlusL(userInput.groupTermLifeOutput.plan.rider[0].maxSA);
     this.riderMax_Input = userInput.groupTermLifeOutput.plan.rider[0].maxSA;
     this.riderPremium = userInput.groupTermLifeOutput.plan.rider[0].grossPremium;
     this.age = this.FormValidators.CalculateAge(new Date(userInput.proposerDetails.dateOfBirth))[0];
     this.totalPremium = this.termInsurancePremium + this.riderPremium;
   }
    private setFocus(id) {
        setTimeout(() => {
            (document.getElementById(id) || { focus: () => { } }).focus();
        });
    }
    private setFocusandRefresh(id) {
        setTimeout(() => {
            (document.getElementById(id) || { focus: () => { } }).focus();
        });
    }
    public doubleDigit(input) {
        this.IndividialRelationFormGroup.get(input).setValue(
            convertToDoubleDigit(this.IndividialRelationFormGroup.get(input).value));
    }
    public BuyNow() {
        // TODO: pass bre response to process call - Snigdha
        this.PrepareBuyNowPayload(this.ReponsePlanDetails, 'buynow');
        this.BuynowPlans.proposerDetails.emailDetails !== null ?
        (this.BuynowPlans.proposerDetails.emailDetails[0].emailAddress = this.EmailFormGroup.controls['email'].value) :
        (this.BuynowPlans.proposerDetails.emailDetails = null);
        this.markTaskComplete(this.BuynowPlans, 'buynow');
    }
    public CalcPremium() {
        this.calcPremiumFlag = true;
        this.sumAssuredChangeFlag = false;
        this.PreparecalculatePlanPayload(this.ReponsePlanDetails, '');
        this.calculatePremium(this.calculatePremPlan);
    }
    public onCheck(relation: string) {
        const value = this.IndividialRelationFormGroup.value;
        const count =
            ['Self', 'Spouse', 'Mother', 'Father'].reduce((accum, val) => accum + (value[val] === null ? 0 : 1), 0) +
            ['Son', 'Daughter'].reduce((accum, val) => accum + (value[val].length), 0);
        let proceed = 6 > count;
        const formCtrl = this.IndividialRelationFormGroup.get(relation);
        if (['Son', 'Daughter'].includes(relation)) {
            if (!this.IndividialRelationFormGroup.get(relation)['controls'].length) {
                const childCount = ['Son', 'Daughter'].reduce((accum, val) => accum + (value[val].length), 0);
                if (proceed) {
                    proceed = 4 > childCount;
                }
                if (!proceed) { return; }
                this.onIncr({ relationDesc: relation }, null);
                return;
            }
            Array(this.IndividialRelationFormGroup.get(relation)['controls'].length).fill(null)
                .forEach(_ => this.onDecr({ relationDesc: relation }));
            return;
        }
        if (formCtrl.value === null && !proceed) { return; }
        formCtrl.setValue(formCtrl.value !== null ? null : '');
        setTimeout(() => {
            if (formCtrl.value !== null) {
                document.getElementById(relation).focus();
                formCtrl.setValidators([Validators.required, RangeValidator(ageRanges.entry.adult.min, ageRanges.entry.adult.max)]);
            } else {
                formCtrl.clearValidators();
            }
            formCtrl.updateValueAndValidity();
            const toBeFocused = this.InsuredData.find(ind => this.IndividialRelationFormGroup.get(ind.relationDesc).invalid);
            if (toBeFocused) {
                this.setFocus(toBeFocused.relationDesc);
            }
        });
    }
    public ModifyPlan() {
        this.PreparePayloadForModifiedPlan(this.ReponsePlanDetails, '');
        this.markTaskComplete(this.ModifiedBuynowPlans, 'BuyPlan');
    }
    // email quote process call
    public emailQuote() {
        this.PrepareEmailQuotePaylaod(this.ReponsePlanDetails, 'emailquote');
        this.markTaskComplete(this.EmailQuotePlans, 'EmailQuote');
        this.HideChildModal('email-quote');
        this.showSuccess();
    }
    public space(input) {
        if (input !== null) {
            addSpaceToDigit(input);
        }
    }
    private buildGetQuoteForm() {
        this.GetQuoteFormGroup = this._formBuilder.group({
            eiaAccountFlag: [false, [Validators.required]]
        });
    }
    private buildSumAssuredFormGroup() {
        this.SumAssuredFormGroup = this._formBuilder.group({
            sumAssure: ['', []],
            criticalillness: ['', []],
        });
    }
    private buildGetQuoteSliderFormGroup() {
        this.GetQuoteSliderFormGroup = this._formBuilder.group({
            getQuoteSlider: [this.SelectedValueOnSlider, '']

        });
    }
    private setInsuredForText() {
        if (this.GetInsuredDetails) {
            const rels = this.GetInsuredDetails.filter(v => !v.insuredDeleted)
                .reduce((accum, e) => { accum[e.relationship] = (accum[e.relationship] || 0) + 1; return accum; }, {});
            this.InsuredForText = Object.keys(rels)
                .map(r => (rels[r] > 1 ? ` ${r} (${rels[r]}) ` : r)).join(', ').toLocaleLowerCase();
        }
    }
    private buildEmailQuoteGroup() {
        this.EmailFormGroup = this._formBuilder.group({
            email: [this.email, [Validators.required]]
        });
    }
    public setIndividualFormGroup() {
        if (this.GetInsuredDetails) {
            const insuredDetails = this.GetInsuredDetails;
            const rangeValidator = RangeValidator(ageRanges.entry.adult.min, ageRanges.entry.adult.max);
            const childRangeValidator = RangeValidator(ageRanges.entry.child.min, ageRanges.entry.child.max);
            const d = insuredDetails.filter(ins => !['SON', 'DAUGHTER'].includes(ins.relationship))
                .reduce((accum, r) => {
                    accum[r.relationship] = r.age;
                    return accum;
                }, {});
            d['SON'] = insuredDetails.filter(ins => ins.relationship === 'SON')
                .map(ins => ([ins.age, Validators.compose([Validators.required,
                    childRangeValidator])]));
            d['DAUGHTER'] = insuredDetails.filter(ins => ins.relationship === 'DAUGHTER')
                .map(ins => ([ins.age, Validators.compose([Validators.required,
                    childRangeValidator])]));
            const basic = ['Self', 'Spouse', 'Father', 'Mother'].reduce((accum, r) => {
                accum[r] = [d[r.toUpperCase()], Validators.compose(d[r.toUpperCase()] ? [Validators.required, rangeValidator] : [])];
                return accum;
            }, {});
            const children = ['Son', 'Daughter'].reduce((accum, r) => {
                accum[r] = this._formBuilder.array(d[r.toUpperCase()]);
                return accum;
            }, {});
            this.IndividialRelationFormGroup = this._formBuilder.group({ ...basic, ...children });
        }
    }
    // Building Individual Form Group for Insured Popup
    private buildFamilyFormGroup() {
        this.FamilyRelationFormGroup = this._formBuilder.group({
            relationship: ['', Validators.compose([Validators.required])],
            noOfSons: [''],
            noOfDaughters: ['']
        });
    }
    /*Initialize Popup*/
    private initContentPopup() {
        this.ContentPopup = {
            Id: 'content-modal',
            Title: 'IFSC Code finder',
            Config: <CustomModalOptions>{ show: false, closeOption: true }
        };
        console.log('this.config.closeOption:', this.ContentPopup.Config.closeOption);
    }
    /* Getting Popup Instances Based on Id */
    private getModalDirectiveInstanceBasedOnId(popupId: string): any {
        return this.PopupComponent.filter((item: PopupComponent, index: number) => {
            return item.id === popupId;
        })[0].modalControl;
    }
    // Please dont change anything in this function . It will break the flow
    private getTaskDetails() {
        this._activitiHandler.GetTaskDetails().subscribe((
            mtResponse: ActivitiModel.MTResponse<any>
        ) => {
            if (!mtResponse.errorBean) {
                this.groupTermLifeOutput = mtResponse.payload.groupTermLifeOutput;
                this.ProposerDetails = mtResponse.payload.proposerDetails;
                this.GetInsuredDetails = mtResponse.payload.insuredDetails;
                this.setInsuredForText();
                this.setIndividualFormGroup();
                if (!mtResponse.payload.groupTermLifeOutput.errorDetails.length) {
                     this.setUserInput(mtResponse.payload);
                    this.GetProductFeatures = mtResponse.payload.productFeatures;
                this.ReponsePlanDetails = mtResponse.payload;
                this.GetrecommendedPlans = this.ReponsePlanDetails.recommendedPlans;
                this.editFlag = mtResponse.payload.modifyPlan;
                this.ErrorMessage = null;
                this.IsGetQuoteFailed = false;
                if (!this.IsEnabled) {
                    this.IsEnabled = true;
                }
                } else {
                    this.ErrorMessage = mtResponse.payload.groupTermLifeOutput.errorDetails[0].description;
                    this.IsGetQuoteFailed = true;
                }
            }
        },
            error => {
                console.error('ERROR::', error);
            }
        );
        this.setIndividualFormGroup();
    }
    public ChangeModalSize(modalSize) {
        const element = document.querySelector('.modal-dialog');
        console.log('ele;;', element);
        element.classList.add(modalSize);
    }
    // Mark Task As Complete
    private markTaskComplete(data, taskName: string, isLoader?: boolean, cb?: Function) {
      this.ShowLoader = true;
        this._activitiHandler.MarkTaskAsCompleted(data, taskName, true).subscribe((resp: Model.MTResponse<any>) => {
          this.ShowLoader = false;
            const mtResponse: Model.MTResponse<any> = resp;
            if (!mtResponse.errorBean) {
                (cb || (() => { }))();
                this._routerService.RouteToNextTask(mtResponse.nextTaskKey);
            } else {
                this.ErrorMessage = null;
            }
        });
    }
    public sumAssuredChanged() {
        this.sumAssuredChangeFlag = true;
        this.IsGetQuoteFailed = false;
        this.validateSumAssured = this.formatter.ConvertCurrenyToUnit((this.SumAssuredFormGroup.controls['sumAssure'].value), 1);
        this.sumAssuredValid = ((this.validateSumAssured >= this.min_input) && (this.validateSumAssured <= this.max_input)) ? true : false;
        this.sumAssureRequiredFlag = this.SumAssuredFormGroup.controls['sumAssure'].value === '' ? null : false;
        this.riderSumAssured = this.formatter.ConvertCurrenyToUnit(this.SumAssuredFormGroup.controls['criticalillness'].value, 1);
        this.riderSumAssuredValid = ((this.riderSumAssured >= this.riderMin_Input)
                                    && (this.riderSumAssured <= this.riderMax_Input)) ||
                                     (this.riderSumAssured === 0) || (this.riderSumAssured === null) ? true : false;
        if (this.sumAssuredValid === false || this.SumAssuredFormGroup.controls['sumAssure'].value[0] === '0') {
          if (this.validateSumAssured > 0) {
            this.notInRange = true;
          } else if (this.validateSumAssured === 0) {
            if (this.SumAssuredFormGroup.controls['sumAssure'].value === '') {
              this.notInRange = false;
              this.sumAssureRequiredFlag = true;
            } else {
              this.notInRange = true;
            }
          } else {
            this.notInRange = false;
          }
        } else {
          this.notInRange = false;
        }
    }
    private PrepareEmailQuotePaylaod(responsePayload: any, action: string) {
      const buynowPayLoad = this.CalculateResp !== undefined ? this.CalculateResp.payload :responsePayload;
        const payload = {
          businessType: '1',
          userAction: 'emailquote',
          channelType: 'Web',
          selectedPlanDetails: {
            plan: {
              sumAssured:
                buynowPayLoad.groupTermLifeOutput.plan.sumAssured,
              code: buynowPayLoad.groupTermLifeOutput.plan.code,
              variantCode:
                buynowPayLoad.groupTermLifeOutput.plan.variantCode,
              netPremium:
                buynowPayLoad.groupTermLifeOutput.plan.netPremium,
              gst: buynowPayLoad.groupTermLifeOutput.plan.gst,
              grossPremium:
                buynowPayLoad.groupTermLifeOutput.plan.grossPremium,
              policyTerm:
                buynowPayLoad.groupTermLifeOutput.plan.policyTerm,
              premiumPayingTerm:
                buynowPayLoad.groupTermLifeOutput.plan
                  .premiumPayingTerm,
              rider:
                this.SumAssuredFormGroup.controls['criticalillness']
                  .value !== '0' &&
                this.SumAssuredFormGroup.controls['criticalillness']
                  .value !== ''
                  ? this.PrepareRiderPayload(buynowPayLoad)
                  : [],
              totalGrossPremium:
                buynowPayLoad.groupTermLifeOutput.plan.totalGrossPremium
            },
            oldGrossPremium:
              responsePayload.groupTermLifeOutput.oldGrossPremium
          },
          utmParams: {
            utmSource: 'WEBSITE_PRODUCT_PAGE',
            utmMedium: null,
            utmCampaign: null,
            utmContent: null,
            utmTerm: null
          },
          proposerDetails: {
            mobileNumber: responsePayload.proposerDetails.phoneNumberDetails[0].number,
            gender: responsePayload.proposerDetails.genederCode,
            email: this.EmailFormGroup.controls['email'].value,
            dob: responsePayload.proposerDetails.dateOfBirth,
            age: this.age
          },
          insuredDetails: []
        };
        this.EmailQuotePlans = payload;
    }
    private PrepareBuyNowPayload(responsePayload: any, action: string) {
      const buynowPayLoad = this.CalculateResp !== undefined ? this.CalculateResp.payload :responsePayload;
        const payload = {
          proposerDetails: responsePayload.proposerDetails,
          selectedPlanDetails: {
            plan: {
              sumAssured: buynowPayLoad.groupTermLifeOutput.plan.sumAssured,
              code: buynowPayLoad.groupTermLifeOutput.plan.code,
              variantCode: buynowPayLoad.groupTermLifeOutput.plan.variantCode,
              netPremium: buynowPayLoad.groupTermLifeOutput.plan.netPremium,
              gst: buynowPayLoad.groupTermLifeOutput.plan.gst,
              grossPremium: buynowPayLoad.groupTermLifeOutput.plan.grossPremium,
              policyTerm: buynowPayLoad.groupTermLifeOutput.plan.policyTerm,
              premiumPayingTerm: buynowPayLoad.groupTermLifeOutput.plan.premiumPayingTerm,
              rider:  (this.SumAssuredFormGroup.controls['criticalillness'].value !== "0") &&
               (this.SumAssuredFormGroup.controls['criticalillness'].value !== "") ?
                      this.PrepareRiderPayload(buynowPayLoad) : [],
              totalGrossPremium: buynowPayLoad.groupTermLifeOutput.plan.totalGrossPremium
            },
            oldGrossPremium:
              responsePayload.groupTermLifeOutput.oldGrossPremium
          }
        };
        this.BuynowPlans = payload;
    }
    private PrepareRiderPayload(CalculateResp:any){
     const riders= [{
        code: CalculateResp.groupTermLifeOutput.plan.rider[0].code,
        grossPremium: CalculateResp.groupTermLifeOutput.plan.rider[0].grossPremium,
        gst: CalculateResp.groupTermLifeOutput.plan.rider[0].gst,
        maxSA: CalculateResp.groupTermLifeOutput.plan.rider[0].maxSA,
        minSA: CalculateResp.groupTermLifeOutput.plan.rider[0].minSA,
        netPremium: CalculateResp.groupTermLifeOutput.plan.rider[0].netPremium,
        sumAssured: CalculateResp.groupTermLifeOutput.plan.rider[0].sumAssured
      }]
      return riders;
    }
    private PreparecalculatePlanPayload(responsePayload: any, action: string) {
        const payload = {
            lifeAssured: {
                age: this.age,
                gender: responsePayload.proposerDetails.genederCode,
                dob: responsePayload.proposerDetails.dateOfBirth
            },
            applicationId: responsePayload.groupTermLifeOutput.applicationId,
            plan: {
                sumAssured: this.formatter.ConvertCurrenyToUnit((this.SumAssuredFormGroup.controls['sumAssure'].value), 1),
                code: responsePayload.groupTermLifeOutput.plan.code,
                variantCode: responsePayload.groupTermLifeOutput.plan.variantCode,
                policyTerm: responsePayload.groupTermLifeOutput.plan.policyTerm,
                premiumPayingTerm: responsePayload.groupTermLifeOutput.plan.premiumPayingTerm,
                rider:
                this.formatter.ConvertCurrenyToUnit((this.SumAssuredFormGroup.controls['criticalillness'].value), 1) === 0 ? [] :
                 [{
                  code: 'GTLACI',
                  sumAssured: this.formatter.ConvertCurrenyToUnit((this.SumAssuredFormGroup.controls['criticalillness'].value), 1),
                  selected: this.SumAssuredFormGroup.controls['criticalillness'].value ? 'Y' : 'N'
                }]
            },
            oldGrossPremium: responsePayload.groupTermLifeOutput.oldGrossPremium,
            hlavailable: responsePayload.hlavailable
        };
        this.calculatePremPlan = payload;
    }
    private PreparePayloadForModifiedPlan(responsePayload: any, action: string) {
        const payload = {
            planCode: responsePayload.recommendedPlans.planCode,
            sumAssuredList: [this.planDetails]
        };
        this.ModifiedBuynowPlans = payload;
    }
    private calculatePremium(data) {
      this.ShowLoader = true;
        this._getQuoteFormService.FetchCalculatePremium(data).subscribe((resp: Model.MTResponse<any>) => {
          this.ShowLoader = false;
          if(!resp.errorBean){
            if(resp.payload.groupTermLifeOutput.errorDetails.length === 0) {
            this.ErrorMessage = null;
            const mtResponse = resp;
            this.CalculateResp = resp;
            this.termInsurancePremium = this.CalculateResp.payload.groupTermLifeOutput.plan.grossPremium;
            this.riderPremium = this.CalculateResp.payload.groupTermLifeOutput.plan.rider[0] ? mtResponse.payload.groupTermLifeOutput.plan.rider[0].grossPremium : 0;
            this.totalPremium = this.CalculateResp.payload.groupTermLifeOutput.plan.totalGrossPremium;
            } else {
              this.ErrorMessage = resp.payload.groupTermLifeOutput.errorDetails[0].description;
              this.IsGetQuoteFailed = true;
            }
          }
           else {
            this.ErrorMessage = resp.errorBean[0].errorMessage;
            this.IsGetQuoteFailed = true;
           }
        });
    }
}
