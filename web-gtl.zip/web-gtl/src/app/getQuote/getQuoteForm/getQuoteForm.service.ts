import { Injectable } from '@angular/core';
import { ConfigService } from '../../common/services/config.service';
import { HttpInterceptor } from '../../common/services/httpInterceptor.service';
import { Observable } from 'rxjs/internal/Observable';
import { CookieHandlerService } from 'src/app/common/services/cookieHandler.service';
import { CommonConstants } from 'src/app/common/utilities/commonConstants';
@Injectable({
    providedIn: 'root'
})
export class GetQuoteFormService {
    constructor(private _httpInterceptor: HttpInterceptor,
                private _cookieHandler: CookieHandlerService) { }
    public FetchCalculatePremium( requestData: any): Observable<ActivitiModel.MTResponse<any>> {
        return this._httpInterceptor.Post(ConfigService.getInstance().getConfigObject().APIURL.calculatePremium, requestData) ;
    }
    public ValidatePersonalEmailID(emailID: string): Observable<ActivitiModel.MTResponse<any>> {
        let url = ConfigService.getInstance()
            .getConfigObject().APIURL.validatePersonalEmailID;
        url = url.replace('{0}', emailID);
        return this._httpInterceptor.Get(url, true);
    }
}
