import { SessionHandlerService } from './../common/services/sessionHandler.service';
import { Component, OnInit, Output } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { ActivitiHandlerService } from './../common/services/activitiHandler.service';
import { CookieHandlerService } from './../common/services/cookieHandler.service';
import { CommonConstants } from './../common/utilities/commonConstants';
import { SharedService } from './../common/services/sharedService';
import { Formatter } from './../common/services/formatter';
import { AnalyticsService } from './../common/services/device.analytics.service';
import { RouteHandlerService } from './../common/services/routeHandler.service';
import { HttpInterceptor } from './../common/services/httpInterceptor.service';
import { ConfigService } from './../common/services/config.service';
@Component({
    templateUrl: './existingCustomer.template.html',
    styleUrls: ['./existingCustomer.style.css']
})
export class ExistingCustomerComponent implements OnInit {
    public SelectApplication: FormGroup;
    public ApplicationList: any;
    public UserName: string;
    public AppSelectionOptions: any;
    public LoanTypes = [];
    public DetailsPayload;
    public ShowLoader: boolean;
    public LoanProducts: any = {};
    public SelectedApplication: string = null;
    public SelectedProcessId: string;
    public SelectedLoanTypeDetails: any = {};
    public ProductEndUseForm: FormGroup;
    public LoanTypeVisibilityFlag: boolean;
    public SelectedEmiDate: string;
    public isFlexiHybridLoanOnLoad: boolean;
    public displayPage: boolean;
    @Output() public loanApplicationKey;
    constructor(
        private _activitiHandler: ActivitiHandlerService,
        public _cookieHandler: CookieHandlerService,
        private _formBuilder: FormBuilder,
        private _formatter: Formatter,
        private _httpInterceptor: HttpInterceptor,
        private _routerService: RouteHandlerService,
        private sharedService: SharedService,
        private _analyticsService: AnalyticsService,
        private _sessionService: SessionHandlerService
    ) { }
    public ngOnInit() {
        this.buildFormProductGroup();
        const uName = this._cookieHandler.GetCookie(
            CommonConstants.CookieKeys.UserName) || CommonConstants.DEFAULT_EMPTY_STRING;
        this.UserName = atob(uName);
        this.getApplicationList();
    }
    public OnSubmit(formValue: FormData) {
        if(this.ApplicationList[0].processId !==null){
        const prdCode = this.sharedService.getData(CommonConstants.QueryParamsKeys.Productcode)
            || CommonConstants.LOAN_PRODUCT_CODES.GTL_Insurance;
        const payload = this.setUtmParamsToPayload(prdCode,
            CommonConstants.LOAN_PRODUCT_CATEGORY_CODES.GTL_Insurance,
            (mtResponse: ActivitiModel.MTResponse<any>) => {
                // blank
            });
            this.taskComplete(payload,'terminate', () => {
              this.setCookies(formValue);
                this.resumeApplication();
          });}
          else{//for time being remove below code
            this._cookieHandler.DeleteCookies([
                CommonConstants.CookieKeys.LoanApplicationId,
                CommonConstants.CookieKeys.LoanApplicationKey]);
            let appKey: string;
            let loanApplicationKey: string;
            this.ApplicationList.forEach((obj) => {
                if (obj.processId === formValue['productName']) {
                    appKey = obj.applicationKey.toString();
                    loanApplicationKey = obj.applicationKey.toString();
                }
            });
            this._cookieHandler.SetCookie(CommonConstants.CookieKeys.LoanApplicationId, appKey);
            this._cookieHandler.SetCookie(CommonConstants.CookieKeys.LoanApplicationKey,
                loanApplicationKey);                           
            this._cookieHandler.SetCookie(CommonConstants.CookieKeys.JourneyType, 'Resume');
            console.log(this._cookieHandler.GetCookie(
                CommonConstants.CookieKeys.LoanApplicationKey));
            const startWorkFlowpayload= {
                 productCategoryCode: CommonConstants.LOAN_PRODUCT_CATEGORY_CODES.GTL_Insurance,
                 insuranceApplications: {
                 insProduct: CommonConstants.LOAN_PRODUCT_CODES.GTL_Insurance
                 },
                 applicantId: this.ApplicationList[0].applicantkey,
                 applicationId: this.ApplicationList[0].applicationKey,
                 appApplicantId: this.ApplicationList[0].applicationApplicantId
                 }
              this.taskRouteComplete(startWorkFlowpayload,'ContinueNew');
           }
    }
    public GoBack() {
        this._activitiHandler.MarkTaskAsCompleted(null, 'Back', true).subscribe((mtResponse: ActivitiModel.MTResponse<any>) => {
            if (!mtResponse.errorBean) {
                this.sharedService.setData(
                    CommonConstants.SharedServiceDataKeys.IsNewApplication, false);
                this._routerService.RouteToNextTask(mtResponse.nextTaskKey);
            }
        });
    }
    public OnAppSelection($event: any) {
        this.SelectedProcessId = $event[0].processId;
        this.setProcessId();
    }
    private setProcessId() {
        this.SelectApplication.controls['productName'].setValue(this.SelectedProcessId);
    }
    private setCookies(formValue: FormData) {
        this._sessionService.DeleteSession([
            CommonConstants.CookieKeys.LoanApplicationId,
            CommonConstants.CookieKeys.LoanApplicationKey]);
        let appKey: string;
        let loanApplicationKey: string;
        this.ApplicationList.forEach((obj) => {
            if (obj.processId === formValue['productName']) {
                appKey = obj.applicationKey.toString();
                loanApplicationKey = obj.applicationKey.toString();
            }
        });
        this._sessionService.SetSession(CommonConstants.CookieKeys.LoanApplicationId, appKey);
        this._sessionService.SetSession(CommonConstants.CookieKeys.LoanApplicationKey,
            loanApplicationKey);
        this._sessionService.SetSession(CommonConstants.CookieKeys.ProcessInstanceDetails,
            formValue['productName']);
        this._sessionService.SetSession(CommonConstants.CookieKeys.JourneyType, 'Resume');
        console.log(this._sessionService.GetSession(
            CommonConstants.CookieKeys.LoanApplicationKey));
    }
    private findAppKey(proID: string) {
        this._sessionService.DeleteSession([CommonConstants.CookieKeys.LoanApplicationId]);
        let obj: any;
        for (obj in this.ApplicationList) {
            if (obj.processId === proID) {
                this._sessionService.SetSession(CommonConstants.CookieKeys.LoanApplicationKey,
                    obj.applicationKey);
            }
        }
    }
    private getApplicationList() {
        this._activitiHandler.GetTaskDetails('resume').subscribe((mtResponse: ActivitiModel.MTResponse<any>) => {
            if (!mtResponse.errorBean) {
                this.ApplicationList = mtResponse.payload.application; // mtResponse.payload.application;
                const appId = this.ApplicationList[0].applicationKey;
                const sessionId = this._sessionService.GetSession(CommonConstants.CookieKeys.LoanApplicationId);
                if (appId != sessionId) {
                    const appIdFromCookie = + this._cookieHandler.GetCookie(CommonConstants.CookieKeys.LoanApplicationId, appId);
                    this._cookieHandler.DeleteCookies([CommonConstants.CookieKeys.LoanApplicationId], sessionId);
                    if ((appId === appIdFromCookie) && appId && appIdFromCookie) {
                        this._routerService.RouteToNextTask('multitabfailed');
                        return;
                    }
                    this._sessionService.SetSession(CommonConstants.CookieKeys.LoanApplicationId, appId);
                    // this.sharedService.setData(CommonConstants.CookieKeys.LoanApplicationId, appId);
                    this._cookieHandler.SetCookie(CommonConstants.CookieKeys.LoanApplicationId, appId, appId);
                }
                this.setApplicationOptionsList(this.ApplicationList);
                this.setUserAuthToken(mtResponse.payload);
                if (this.ApplicationList.length === 1) {
                    this.SelectedProcessId = this.ApplicationList[0].processId;
                    this.setProcessId();
                }
             }
        });
    }
    // Setting Application List Selection List Object
    private setApplicationOptionsList(loanTypes) {
        this.AppSelectionOptions = {
            itemHighlightSelector: '.product-row',
            itemSelector: '.product-row',
            isMultiSelect: false,
            isSelectionToggleAllowed: false,
            DataProvider: loanTypes
        };
    }
    // this is the place where user from customer portal will go to direct appliaction.
    private findAndredirectToResumeApp() {
        const getProceessIDForResume = this._cookieHandler.GetCookie('SS_1_APP_PRO_ID');
        this.findAppKey(getProceessIDForResume);
        if (getProceessIDForResume != null) {
            this._sessionService.SetSession (
                CommonConstants.CookieKeys.ProcessInstanceDetails, getProceessIDForResume);
            this.resumeApplication();
        }
    }
    private buildFormProductGroup(): void {
        this.SelectApplication = this._formBuilder.group({
            productName: ['', Validators.compose([Validators.required])],
            ulKey: ['']
        });
    }
    private taskComplete(data,actionName, callback?) {
      this._activitiHandler.MarkTaskAsCompleted(data,actionName).subscribe((mtresponse: ActivitiModel.MTResponse<any>) => {
          if (!mtresponse.errorBean) {
              console.log(mtresponse.payload, 'payload marktask complete');
              if (callback) {
                  callback();
              }
          }
      });
  }
    private resumeApplication() {
        this._activitiHandler.GetTaskDetails().subscribe((mtresponse: ActivitiModel.MTResponse<any>) => {
            if (!mtresponse.errorBean) {
                this._routerService.RouteToNextTask(mtresponse.nextTaskKey);
            }
        });
    }
    private checkMannualRouting(payload: any) {
        this.sharedService.setData('quesObj', payload);
    }
    private setUserAuthToken(responseData: any) {
        console.log(responseData);
        if (responseData && responseData.newTokens &&
            responseData.newTokens.tokens && responseData.newTokens.tokens.length) {
            this._sessionService.SetSession(CommonConstants.CookieKeys.JWToken,
                responseData.newTokens.tokens[0].token);
            this._sessionService.
                SetSession(CommonConstants.CookieKeys.GuardKey,
                    responseData.newTokens.tokens[0].guardKey);
            this._sessionService.SetSession(CommonConstants.CookieKeys.GuardToken,
                this._formatter
                    .ConvertGuradKeyToGuardToken(
                        responseData.newTokens.tokens[0].guardKey));
        }
    }
    private setUtmParamsToPayload(
        loanProduct: string,
        productCategoryCode: string,
        onSuccessCallback: Function,
        calculatorProductType?: number,
        isLocationProvided?: boolean
    ): any {
        const payload = this.getApplicationCreateRequest(
            loanProduct, productCategoryCode, calculatorProductType, isLocationProvided);
        return payload;
    }
    private getApplicationCreateRequest(
        LoanProduct: string,
        ProductCategoryCode: string,
        CalculatorProductType?: number,
        IsLocationProvided?: boolean) {
        let mediumFromWeb = this.sharedService.getData(CommonConstants.QueryParamsKeys
            .appUtmMedium);
        const medium = 'Webengage_repeat_visitor_finance_homepage_PL_apply_online_link';
        if (mediumFromWeb !== '' && typeof (mediumFromWeb) !== 'object') {
            mediumFromWeb = this.CheckUtmMediumForDevice(
                this.sharedService.getData(CommonConstants.QueryParamsKeys
                    .appUtmMedium).toString());
        } else if (mediumFromWeb !== '') {
            mediumFromWeb = this.CheckUtmMediumForDevice(medium);
        } else {
            mediumFromWeb = this.CheckUtmMediumForDevice(mediumFromWeb);
        }
        return {
            appJourneyStamp: 'journeyStamp',
            appSource: 'Browser',
            appStatus: 0,
            bflBranch: this.checkUtmSources(this.sharedService.getData(
                CommonConstants.QueryParamsKeys.BFLBranch)) || '320',
            productCategoryCode: ProductCategoryCode,
            loanApplications: { loanProduct: LoanProduct },
            calculatorProductType: CalculatorProductType,
            islocationProvided: IsLocationProvided,
            appUtmRefCode: this.checkUtmSources(this.sharedService.getData(
                CommonConstants.QueryParamsKeys.appUtmRefCode)) || '',
            appUtmSource: this.checkUtmSources(this.sharedService.getData(
                CommonConstants.QueryParamsKeys.appUtmSource)) || 'Organic',
            appUtmMedium: mediumFromWeb || medium,
            appUtmCampaign: this.checkUtmSources(this.sharedService.getData(
                CommonConstants.QueryParamsKeys.appUtmCampaign)) || '',
            appUtmTerm: this.checkUtmSources(this.sharedService.getData(
                CommonConstants.QueryParamsKeys.appUtmTerm)) || '',
            appUtmContent: this.checkUtmSources(this.sharedService.getData(
                CommonConstants.QueryParamsKeys.appUtmContent)) || '',
            gclId: this.checkUtmSources(this.sharedService.getData(
                CommonConstants.QueryParamsKeys.GCLID))
                || 'EAIaIQobChMIsZGIyZn01AIV1IdoCh19HAKqEAAYASAAEgKWjfD_BwE'
        };
    }
    private CheckUtmMediumForDevice(value: string) {
        const deviceDetails: DeviceDetails = this._analyticsService.GetDeviceDetails();
        if (deviceDetails.mobile) {
            value = value.concat('_mobile');
        }
        return value;
    }
    private checkUtmSources(utmObj) {
        if (Object.keys(utmObj).length !== 0) {
            return utmObj;
        } else {
            return false;
        }
    }

    private taskRouteComplete(data,actionName, callback?) {
        this._activitiHandler.MarkTaskAsCompleted(data,actionName).subscribe((mtresponse: ActivitiModel.MTResponse<any>) => {
            if (!mtresponse.errorBean) {
                console.log(mtresponse.payload, 'payload marktask complete');
                this._routerService.RouteToNextTask(mtresponse.nextTaskKey);
            }
        });
    }
}
