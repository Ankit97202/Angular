declare interface DeviceDetails {
    screen: string;
    browser: string;
    browserVersion: string;
    browserMajorVersion: number;
    mobile: boolean;
    os: string;
    osVersion: string;
    cookies: boolean;
}