declare interface GeoLocationDetails {
    city: string;
    cityId: string;
    state: string;
    stateId: string;
    stateShortName: string;
    country: string;
    countryId: string;
    pinCode: string;
    pinId: string;
    latitude: number;
    longitude: number;
    formattedAddress: string;
}