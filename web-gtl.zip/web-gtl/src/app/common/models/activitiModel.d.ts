declare module ActivitiModel {
    export interface ActivitiRequest {
        activitiName?: string;
        action?: string;
        processId: string;
        routesInfo?: RoutesInfoList;
        payload?: any;
    }
    export interface ActivitiResponse extends MTResponse<any> {
        nextTaskKey: string;
    }
    export interface RoutesInfoList {
        mainRoute: string;
        subRoute: string;
    }
    export interface MTResponse<T> {
        payload?: T;
        nextTaskKey?: string;
        routesInfo?: RoutesInfo;
        progressInfo?: ProgressStateResponse;
        errorBean?: [{ errorCode: string; errorMessage: string }];
        userInput?: any;
        errorDetails:[{ code: string; description: string }];
    }
    export interface ProgressStateResponse {
        payload: ProgressStateInfo[];
        status: string;
        nextTaskKey?: string;
        errorBean: [{ errorCode: string; errorMessage: string }];
    }
    export interface RoutesInfo {
        mainRoute: string;
        subRoute: string;
    }
    export interface ProgressStateInfo {
        name: string;
        active: boolean;
        value: number;
    }
    export interface PlanDetails {
        planCode: string;
        variantCode: string;
        netPremium: number;
        sumAssured: number;
        frequencyCode: string;
        premiumPayingTerm: number;
        policyTerm: number;
        portfolioStrategyCode: string;
        fundFlag: boolean;
        funds: FundDetails[];
        riders: RiderDetails[];
    }
    export interface FundDetails {
        fundCode: string;
        allocation: string;
        selected: boolean;
        returnTerm: number;
        returnPercentage: number;
    }
    export interface RiderDetails {
        riderCode: string;
        selected: boolean;
        sumAssured: number;
    }
    export interface ParticipantDetails {
        applicantKey?:string;
        firstName: string;
        middleName?: string;
        lastName?: string;
        dateOfBirth: string;
        genederCode: string;
        genderDesc: string;
        phoneNumberDetails?: PhoneNumberDetails[];
        emailDetails?: EmailDetails[];
        maritalStatusCode?: string;
        maidenName: string;
        nri: string;
        panNumber?: string;
        aadhaarNumber?: string;
        countryOfBirth?: string;
        countryOfResidence?: string;
        countryOfBirthName?: string;
        countryOfResidenceName?: string;
        motherName: string;
        fatherName: string;
        occupationDesc: string;
        age: any;
        isAgeChanged: boolean;
        apltWeight?: number;
        apltHeight?: number;
    }
    export interface PhoneNumberDetails {
        key: number;
        areaCode: string;
        countryCode: string;
        isDNDActive: string;
        isPreferred: number;
        isVerified: number;
        number: string;
        applicantKey: number;
        type: string;
    }
    export interface EmailDetails{
        key: number;
        emailAddress: string;
        isVerified: number;
        idPriority: number;
        type: string;
        applicantKey: number;
    }
    export interface AddressDetails {
        flatNumber?: string;
        houseNumber?: string;
        street?: string;
        type: string;
        line1?: string;
        line2?: string;
        cityId?: number;
        cityCode?: string;
        city: string;
        stateId?: number;
        state: string;
        stateCode?: string;
        countryId?: number;
        country: string;
        countryCode?: string;
        pinId: number;
        pinCode: string;
        locality?: string;
        localityKey?: number;
        areaLocalityName?: string;
        addSource: string;
        appSource: string;
        occupancyType?: string;
        occupancyName?: string;
        addressLine1?: string;
        addressLine2?: string;
    }
    export interface AddressDetailsModel{
        key : number;
        applicantKey : number;
        flatNumber : string;
        houseNumber : string;
        street : string ;
        type :  string ;
        line1 : string ;
        line2 : string ;
        cityId : number;
        city : string ;
        cityCode : number ;
        stateId : number;
        state : string ;
        stateCode :  string ;
        countryId : number;
        country :  string ;
        countryCode :  string ;
        pinId : number;
        pinCode :  number ;
        locality : string ;
        localityKey : string;
        areaLocalityName : string;
        addSource : string;
        appSource : string;
        occupancyType : string;
        occupancyName : string;
        pinOglFlag : string;
        pinNegativeAreaFlag : string;
        addressDeSelectedFlag : string;
    }
    export interface UploadData {
        Title: string;
        SubtTitleForFrontPage: string;
        SubtTitleForBackPage: string;
        EAadharPageImageUrl: string;
        FrontPageImageUrl: string;
        BackPageImageUrl: string;
        PDFFileIcon: string;
        UploadSuccessMessage: string;
        UploadFailureMessage: string;
        UploadInstructionTitle: string;
        UploadDescription: string;
        PageName: string;
        UploadSize: number;
        SupportedFormat: string;
        UploadInstructonSubTitle: string;
        EAadharTitle: string;
    }
}
declare interface IProvider<T> {
    Get: (key: string) => T;
}
