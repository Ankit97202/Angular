import { CommonConstants } from './../utilities/commonConstants';
import { CookieHandlerService } from './../services/cookieHandler.service';
import { Directive, HostListener } from '@angular/core';
import { SharedService } from './../services/sharedService';
import { SessionHandlerService } from '../services/sessionHandler.service';
@Directive({
    selector: '[appReloadEvent]',
})
export class ReloadDirective {
    constructor(
        private _sharedservice: SharedService,
        private _cookieHandler: CookieHandlerService,
        private _sessionHandler: SessionHandlerService
    ) { }
    @HostListener('window:beforeunload') onWindowUnload() {
        const LoanApplicationId = this._sessionHandler.GetSession(CommonConstants.CookieKeys.LoanApplicationId);
        const applicationIDFromCookie = this._cookieHandler.GetCookie(CommonConstants.CookieKeys.LoanApplicationId,
            LoanApplicationId) || null;
        if (LoanApplicationId && applicationIDFromCookie) {
            this._cookieHandler.DeleteCookies([CommonConstants.CookieKeys.LoanApplicationId], LoanApplicationId);
        }
        if (LoanApplicationId && typeof (LoanApplicationId) !== 'object') {
            window.name = LoanApplicationId;
        }
    }
    @HostListener('window:hashchange') onhashchange() {
        this._sharedservice.setData('brwoserback', true);
    }
    @HostListener('document:deviceready') ondeviceready() {
        this._sharedservice.setData('brwoserback', true);
    }
    @HostListener('window:popstate', ['$event'])
    popstate(event) {
        console.log(event);
        window.history.go(0);
    }
}
