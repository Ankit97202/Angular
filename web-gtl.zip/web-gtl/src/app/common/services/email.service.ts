import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BehaviorSubject} from 'rxjs/BehaviorSubject';
@Injectable({ providedIn: 'root' })
export class EmailService {
    private behave  = new BehaviorSubject<Object>({textVal: ''});
    constructor( ) { }
    setEmail(behave: Object) {
        this.behave.next(behave);
    }
    getEmail():  Observable<any> {
        return this.behave.asObservable();
    }
}
