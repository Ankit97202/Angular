import { Headers, Http, RequestOptions, Response } from '@angular/http';
import { CommonConstants } from './../utilities/commonConstants';
import { ConfigService } from '../services/config.service';
import { HttpInterceptor } from './../services/httpInterceptor.service';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { RouteContextProvider } from './../services/routeContextProvider.service';
import { Router } from '@angular/router';
import { SessionHandlerService } from './sessionHandler.service';
@Injectable({
    providedIn: 'root'
})
export class ActivitiHandlerService {
    constructor(
        private _httpInterceptor: HttpInterceptor,
        private _sessionHandlerService: SessionHandlerService,
        private _router: Router) {

    }
    public StartActiviti(data: any, isLoader?: boolean): Observable<ActivitiModel.MTResponse<any>> {
        return this._httpInterceptor.Post(
            ConfigService.getInstance().getConfigObject()
                .APIURL.startApplicationActiviti, data, isLoader);
    }
    public MarkTaskAsCompleted(
        requestData: any,
        taskName?: string,
        isLoader?: boolean,
        loadermsg?: string
    ): Observable<ActivitiModel.MTResponse<any>> {
        // this is typicaly for custom loader text.
        // ConfigService.getInstance().setTitle(loadermsg);
        return this._httpInterceptor.Post(ConfigService.getInstance()
            .getConfigObject().APIURL.completeActivitiTask,
            this.getCompleteTaskRequest(requestData, taskName), isLoader);
    }
    public GetTaskDetails(
        taskName?: string,
        isLoader?: boolean,
        loadermsg?: string
    ): Observable<ActivitiModel.MTResponse<any>> {
        // this is typicaly for custom loader text.
        // ConfigService.getInstance().setTitle(loadermsg);
        return this._httpInterceptor.Post(ConfigService.getInstance()
            .getConfigObject().APIURL.getActivitiTaskDetails,
            this.getTaskDetailsRequest(taskName), isLoader);
    }
    private getCompleteTaskRequest(requestData: any, taskName: string): ActivitiModel.ActivitiRequest {
        return <ActivitiModel.ActivitiRequest> {
            activitiName: 'complete',
            action: taskName,
              processId: this._sessionHandlerService.GetSession(
                CommonConstants.CookieKeys.ProcessInstanceDetails),
            payload: requestData
        };
    }
    private getTaskDetailsRequest(taskName?: string): ActivitiModel.ActivitiRequest {
        const currentRoute = this._router.url.split(CommonConstants.URL_SEPARATOR);
        return <ActivitiModel.ActivitiRequest> {
            processId: this._sessionHandlerService.GetSession(CommonConstants
                .CookieKeys.ProcessInstanceDetails),
            action: taskName,
            routesInfo: {
                mainRoute: currentRoute[1],
                subRoute: currentRoute[2] || CommonConstants.DEFAULT_EMPTY_STRING
            }
        };
    }
}
