import { EventEmitter, Injectable } from '@angular/core';
@Injectable({
    providedIn: 'root'
})
export class EmitterService {
    // Event Dictionary
    private _emitters: { [id: string]: EventEmitter<any> } = {};
    // Set a new event in the store with a given id
    // as key
    public Get(id: string): EventEmitter<any> {
        if (!this._emitters[id]) {
            this._emitters[id] = new EventEmitter();
        }
        return this._emitters[id];
    }
}
