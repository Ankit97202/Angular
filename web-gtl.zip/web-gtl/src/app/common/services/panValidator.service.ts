import { Headers, Http, RequestOptions } from '@angular/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { CommonConstants } from '../../common/utilities/commonConstants';
import { HttpInterceptor } from '../../common/services/httpInterceptor.service';
import { ConfigService } from '../../common/services/config.service';
import { SessionHandlerService } from './sessionHandler.service';
import { EmitterService } from './emitter.service';
@Injectable()
export class PanValidatorService {
    constructor(
        private _httpInterceptor: HttpInterceptor,
        private _emitterService: EmitterService,
        private _sessionHandlerService: SessionHandlerService
    ) { }
    public validatePan(panNumber: string, isRequired: boolean = false): Observable<Boolean> {
        const url = ConfigService.getInstance().getConfigObject()
            .APIURL.validatePan;
        if (!isRequired && !panNumber) {
            return of(true);
        }
        const appKey = this._sessionHandlerService.GetSession(CommonConstants.CookieKeys.LoanApplicationKey);
        return this._httpInterceptor.Post(url, { panNumber: panNumber, appApltKey: appKey })
            .map(res =>
                (res.errorBean) ? true : res.payload.panValidationSuccessful
            );
    }
}
