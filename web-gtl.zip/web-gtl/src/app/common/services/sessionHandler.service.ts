import { Injectable } from '@angular/core';
@Injectable({
    providedIn: 'root'
})
export class SessionHandlerService {
    constructor(
    ) { }
    public SetSession(key: string, value: any): void {
        sessionStorage.setItem(key, value);
    }
    public GetSession(key: string): string {
        const data = sessionStorage.getItem(key);
        return data ? data : '';
    }
    public DeleteSession(keys: string[]): void {
        keys.forEach((key: string, index: number) => {
            sessionStorage.removeItem(key);
        });
    }
    public FlushAll(): void {
        sessionStorage.clear();
    }
}
