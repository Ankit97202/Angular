import { CommonConstants } from './../utilities/commonConstants';
import { Injectable } from '@angular/core';
@Injectable()
export class UploadComponentProvider implements IProvider<ActivitiModel.UploadData> {
    private _uploadTypeToDataMapping: { [key: string]: ActivitiModel.UploadData } = {};
    constructor() {
        this.initializeUploadTypeMapping();
    }
    public Get(key: string): ActivitiModel.UploadData {
        return this._uploadTypeToDataMapping[key] || this.getDefaultData();
    }
    private initializeUploadTypeMapping() {
        this._uploadTypeToDataMapping[CommonConstants.UploadType.Aadhar] = {
            Title: 'Upload your Aadhaar card',
            SubtTitleForFrontPage: 'Browse to attach the front side of Aadhaar card',
            SubtTitleForBackPage: 'Browse to attach the back side of Aadhaar card',
            EAadharPageImageUrl: 'assets/img/svg/aadhaar_front.svg',
            FrontPageImageUrl: 'assets/img/svg/aadhaar_front.svg',
            BackPageImageUrl: 'assets/img/svg/aadhaar_back.svg',
            PDFFileIcon: 'assets/img/svg/pdf.svg',
            UploadSuccessMessage: 'Kudos! Upload Successful',
            UploadFailureMessage: 'Error processing your request, Please try again.',
            UploadInstructionTitle: 'Remember!',
            UploadInstructonSubTitle: 'It\'s mandatory to upload both ' +
            'front and back sides of your Aadhaar',
            UploadDescription: `<div>Make sure the following fields are clearly visible:<div>
                <ul>
                    <li> Aadhaar number </li>
                    <li>  QR Code</li>
                    <li>  Name </li>
                    <li>  Photograph </li>
                    <li>  Date of Birth </li>
                    <li>  Gender </li>
                    <li>  Address </li>
                </ul>
            `,
            PageName: 'Aadhaar',
            UploadSize: 2,
            SupportedFormat: '.jpeg, .jpg, .png',
            EAadharTitle: 'Browse to attach Aadhaar page'
        };
        this._uploadTypeToDataMapping[CommonConstants.UploadType.Passport] = {
            Title: 'Upload your Passport',
            SubtTitleForFrontPage: 'Browse to attach the first page of your Passport',
            SubtTitleForBackPage: 'Browse to attach the last page of your Passport',
            EAadharPageImageUrl: 'assets/img/svg/aadhaar_front.svg',
            FrontPageImageUrl: 'assets/img/svg/passport_front.svg',
            BackPageImageUrl: 'assets/img/svg/passport_back.svg',
            PDFFileIcon: 'assets/img/svg/pdf.svg',
            UploadSuccessMessage: 'Kudos! Upload Successful.',
            UploadFailureMessage: 'Error processing your request, Please try again.',
            UploadInstructionTitle: 'Remember!',
            UploadInstructonSubTitle: 'It\'s mandatory to upload both' +
            ' front and back sides of your Passport',
            UploadDescription: `<p>Make sure the following fields are clearly visible:
                <ul>
                    <li> Passport number </li>
                    <li>  Photograph </li>
                    <li>  Name </li>
                    <li>  Nationality </li>
                    <li>  Gender </li>
                    <li>  Date of Birth </li>
                    <li>  Place of Birth </li>
                    <li>  Place of Issue </li>
                    <li>  Date of Issue </li>
                    <li>  Date of Expiry </li>
                    <li>  Address </li>
                </ul>
            </p>
            `,
            PageName: 'Passport',
            UploadSize: 2,
            SupportedFormat: '.jpeg, .jpg, .png',
            EAadharTitle: 'Browse to attach Aadhaar page'
        };
        this._uploadTypeToDataMapping[CommonConstants.UploadType.DL] = {
            Title: 'Upload your Driving License',
            SubtTitleForFrontPage: 'Browse to attach the front side of Driving License',
            SubtTitleForBackPage: 'Browse to attach the back side of Driving License',
            EAadharPageImageUrl: 'assets/img/svg/aadhaar_front.svg',
            FrontPageImageUrl: 'assets/img/svg/drivinglicense_front.svg',
            BackPageImageUrl: 'assets/img/svg/PanCard-back.svg',
            PDFFileIcon: 'assets/img/svg/pdf.svg',
            UploadSuccessMessage: 'Kudos! Upload Successful',
            UploadFailureMessage: 'Error processing your request, Please try again.',
            UploadInstructionTitle: 'Remember!',
            UploadInstructonSubTitle: 'It\'s mandatory to upload' +
            'the front side of your Driving License',
            UploadDescription: `<div>Make sure the following fields are clearly visible:<div>
                <ul>
                    <li> Driving licence number </li>
                    <li>  Name </li>
                    <li>  Father’s name </li>
                    <li>  Photograph </li>
                    <li>  Address </li>
                    <li>  Date of birth </li>
                </ul>
            `,
            PageName: 'DL',
            UploadSize: 2,
            SupportedFormat: '.jpeg, .jpg, .png',
            EAadharTitle: 'Browse to attach Aadhaar page'
        };
        this._uploadTypeToDataMapping[CommonConstants.UploadType.Pan] = {
            Title: 'Upload your Pan',
            SubtTitleForFrontPage: 'Browse to attach the first page of your pan card',
            SubtTitleForBackPage: 'Browse to attach the last page of your pan card',
            EAadharPageImageUrl: 'assets/img/svg/aadhaar_front.svg',
            FrontPageImageUrl: 'assets/img/svg/PanCard-front.svg',
            BackPageImageUrl: 'assets/img/svg/PanCard-back.svg',
            PDFFileIcon: 'assets/img/svg/pdf.svg',
            UploadSuccessMessage: 'Kudos! Upload Successful',
            UploadFailureMessage: 'Error processing your request, Please try again.',
            UploadInstructionTitle: 'Remember!',
            UploadInstructonSubTitle: 'It\'s mandatory to ' +
            'the front side of your PAN',
            UploadDescription: `<p>Make sure the following fields are clearly visible:
                <ul>
                    <li>  Photograph </li>
                    <li>  Name </li>
                    <li>  Nationality </li>
                    <li>  Gender </li>
                    <li>  Date of Birth </li>
                    <li>  Place of Birth </li>
                    <li>  Place of Issue </li>
                    <li>  Date of Issue </li>
                    <li>  Date of Expiry </li>
                    <li>  Address </li>
                </ul>
            </p>
            `,
            PageName: 'Pan',
            UploadSize: 2,
            SupportedFormat: '.jpeg, .jpg, .png',
            EAadharTitle: 'Browse to attach Aadhaar page'
        };
    }
    private getDefaultData(): ActivitiModel.UploadData {
        return {
            Title: CommonConstants.DEFAULT_EMPTY_STRING,
            SubtTitleForFrontPage: CommonConstants.DEFAULT_EMPTY_STRING,
            SubtTitleForBackPage: CommonConstants.DEFAULT_EMPTY_STRING,
            EAadharPageImageUrl: CommonConstants.DEFAULT_EMPTY_STRING,
            FrontPageImageUrl: CommonConstants.DEFAULT_EMPTY_STRING,
            BackPageImageUrl: CommonConstants.DEFAULT_EMPTY_STRING,
            PDFFileIcon: CommonConstants.DEFAULT_EMPTY_STRING,
            UploadSuccessMessage: CommonConstants.DEFAULT_EMPTY_STRING,
            UploadFailureMessage: CommonConstants.DEFAULT_EMPTY_STRING,
            UploadInstructionTitle: CommonConstants.DEFAULT_EMPTY_STRING,
            UploadDescription: CommonConstants.DEFAULT_EMPTY_STRING,
            PageName: CommonConstants.DEFAULT_EMPTY_STRING,
            UploadSize: 2,
            SupportedFormat: CommonConstants.DEFAULT_EMPTY_STRING,
            UploadInstructonSubTitle: CommonConstants.DEFAULT_EMPTY_STRING,
            EAadharTitle: CommonConstants.DEFAULT_EMPTY_STRING
        };
    }
}
