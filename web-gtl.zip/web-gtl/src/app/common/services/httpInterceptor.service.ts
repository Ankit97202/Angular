import { Headers, RequestOptions, RequestOptionsArgs, Response } from '@angular/http';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Injectable, Input, Output } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { of } from 'rxjs/observable/of';
import { tap, catchError, retry } from 'rxjs/operators';
import { AnalyticsService } from './device.analytics.service';
import { CookieHandlerService } from './cookieHandler.service';
import { EmitterService } from './emitter.service';
import { CommonConstants } from './../utilities/commonConstants';
import { Formatter } from './formatter';
import { RouteContextProvider } from './routeContextProvider.service';
import { SessionHandlerService } from './sessionHandler.service';
@Injectable({
    providedIn: 'root'
})
export class HttpInterceptor {
    @Input() public listId: string;
    private _appCOID: string;
    private _constantID: string;
    private timeoutId: any;
    private newTime: Date = new Date();
    public static UUID(): string {
        if (typeof (window.crypto) !== 'undefined'
            && typeof (window.crypto.getRandomValues) !== 'undefined') {
            const buf: Uint16Array = new Uint16Array(8);
            window.crypto.getRandomValues(buf);
            return (this.pad4(buf[0]) + this.pad4(buf[1]) + ' ' + this.pad4(buf[2])
                + ' ' + this.pad4(buf[3]) + ' ' + this.pad4(buf[4]) + ' ' + this.pad4(buf[5])
                + this.pad4(buf[6]) + this.pad4(buf[7]));
        } else {
            return this.random4() + this.random4() + ' '
                + this.random4() + ' ' + this.random4() + ' ' +
                this.random4() + ' ' + this.random4() + this.random4() + this.random4();
        }
    }
    private static pad4(num: number): string {
        let ret: string = num.toString(16);
        while (ret.length < 4) {
            ret = '0' + ret;
        }
        return ret;
    }
    private static random4(): string {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }
    constructor(
        private _http: HttpClient,
        private _analyticsService: AnalyticsService,
        private _cookieHandler: CookieHandlerService,
        private _formatter: Formatter,
        private _routeContextProvider: RouteContextProvider,
        private _emitterService: EmitterService,
        private _sessionHandlerService: SessionHandlerService
    ) {
        this.CaptureLogData();
    }
    public Get(url: string, hideLoader?: boolean, options?: RequestOptionsArgs):
        Observable<ActivitiModel.MTResponse<any>> {
        const defaultOptions = this.tasksBeforeCall(options, hideLoader);
        return this._http.get<ActivitiModel.MTResponse<any>>(url, defaultOptions)
            .pipe(
                retry(0),
                tap(response => {
                    this.emitIsLoadingStatus(false);
                }),
                catchError((error, caught) => {
                    this.emitIsLoadingStatus(false);
                    this.handleError(error);
                    return of(error);
                })
            );
    }
    public Post(url: string, data: any, hideLoader?: boolean, options?: RequestOptionsArgs):
        Observable<ActivitiModel.MTResponse<any>> {
        const defaultOptions = this.tasksBeforeCall(options, hideLoader);
        return this._http.post<ActivitiModel.MTResponse<any>>(url, data, defaultOptions)
            .pipe(
                retry(0),
                tap(response => {
                    this.emitIsLoadingStatus(false);
                    if (response.progressInfo && response.progressInfo.payload
                        && response.progressInfo.payload.length > 0) {
                        this._emitterService
                            .Get(CommonConstants.EmitterEventTypes.ProgressStateEvent)
                            .emit(response.progressInfo.payload);
                    }
                }),
                catchError((error, caught) => {
                    this.emitIsLoadingStatus(false);
                    this.handleError(error);
                    return of(error);
                })
            );
    }
    public Put(url: string, data: any, hideLoader?: boolean, options?: RequestOptionsArgs):
        Observable<Response> {
        const defaultOptions = this.tasksBeforeCall(options, hideLoader);
        return this._http.put<Response>(url, data, defaultOptions)
            .pipe(
                tap((response) => {
                    this.emitIsLoadingStatus(false);
                }),
                catchError((error, caught) => {
                    this.emitIsLoadingStatus(false);
                    this.handleError(error);
                    return of(error);
                })
            );
    }
    // this captures the browser, time, location details, session if any, OS or  device details
    public CaptureLogData() {
        let OSName = 'Unknown OS';
        if (navigator.appVersion.indexOf('Win') !== -1) { OSName = 'Windows'; }
        if (navigator.appVersion.indexOf('Mac') !== -1) { OSName = 'MacOS'; }
        if (navigator.appVersion.indexOf('X11') !== -1) { OSName = 'UNIX'; }
        if (navigator.appVersion.indexOf('Linux') !== -1) { OSName = 'Linux'; }
        if (navigator.appVersion.indexOf('Android') !== -1) { OSName = 'Android'; }
        if (navigator.appVersion.indexOf('iPhone') !== -1) { OSName = 'iPhone'; }
        const deviceDetails: DeviceDetails = this._analyticsService.GetDeviceDetails();
        this._sessionHandlerService.SetSession('DeviceDetails', JSON.stringify(deviceDetails));
    }
    private createID() {
        return HttpInterceptor.UUID();
    }
    private getHeaders = (customOptions: RequestOptionsArgs): HttpHeaders => {
        if (this.createGuardTokenOnRequest()) {
            const headerObj: HttpHeaders = new HttpHeaders({
                'Content-Type': 'application/json',
                'cmptcorrid': this._constantID + '|' + this.createID(),
                'authtoken': this._sessionHandlerService.GetSession(CommonConstants.CookieKeys.JWToken),
                'guardtoken': this._sessionHandlerService.GetSession(CommonConstants.CookieKeys.GuardToken),
            });
            if (customOptions && customOptions.headers && customOptions.headers.keys()) {
                customOptions.headers.keys().forEach((key: string, index: number) => {
                    headerObj.set(key, customOptions.headers.get(key));
                });
            }
            return headerObj;
        }
    }
    private handleError(error: Response | any) {
        this.listId = '1';
        if (error.status === '400' ||
            error.status === '0' ||
            error.status === '504' ||
            error.status === '403' ||
            error.status === 400 ||
            error.status === 0 ||
            error.status === 504 ||
            error.status === 403) { }
        // tslint:disable-next-line:no-console
        console.debug('Service level failure Details-->' + error.status);
    }
    private emitIsLoadingStatus(loadingStatus: boolean) { }
    // genarate CookieKeys for GuardKey always on each
    // Request to make sure that token is not going to exprire
    private createGuardTokenOnRequest() {
        const newGuardToken = this._formatter.ConvertGuradKeyToGuardToken(
            this._sessionHandlerService.GetSession(CommonConstants.CookieKeys.GuardKey));
        this._sessionHandlerService.SetSession(CommonConstants.CookieKeys.GuardToken,
            newGuardToken);
        return true;
    }
    // this checks the time started after login.
    private TTLCheck() {
        const userDetails = this._cookieHandler.GetCookie(CommonConstants.CookieKeys.UserName);
        console.log('userDetails', userDetails);
        clearTimeout(this.timeoutId);
        console.log('TTL');
        this.timeoutId = setTimeout(() => {
            if (userDetails) {
                console.log('Logging out... with user logged in');
                this._routeContextProvider.NavigateToView([CommonConstants.Routes.Logout]);
            } else {
                window.location.reload(true);
                console.log('Logging out... without user logged in');
            }
        }, 1200000); // 1200000
    }
    private tasksBeforeCall(options: RequestOptionsArgs, hideLoader: boolean) {
        this.TTLCheck();
        // this is specific in case don't want to show loader with main app
        if (hideLoader) {
            this.emitIsLoadingStatus(false);
        } else {
            this.emitIsLoadingStatus(true);
        }
        return {
            withCredentials: true,
            headers: this.getHeaders(options)
        };
    }
}
