import { Component, EventEmitter, Input, Output, ViewChild, AfterViewInit, OnInit } from '@angular/core';
import { ModalModule } from 'ngx-bootstrap';
import { ModalDirective } from 'ngx-bootstrap/modal';
@Component({
  selector: 'custom-popup',
  templateUrl: 'popup.template.html',
  styleUrls: ['popup.style.css']
})
export class PopupComponent implements AfterViewInit, OnInit {
  @Input() public id: String = 'popupModal';
  @Input() public title: String = 'Default Header';
  @Input() public subtitle: String = 'Default Header';
  @Input() public config: CustomModalOptions;
  @Input() public showClose: Boolean = true;
  @Output() public onInit: EventEmitter<any> = new EventEmitter<any>();
  @Output() public onClose: EventEmitter<boolean> = new EventEmitter<boolean>();
  @ViewChild('modalControl') public modalControl: ModalDirective;
  public ngAfterViewInit() {
    if (this.config && this.config['show']) {
      this.modalControl.show();
    }
  }
  public ngOnInit(): void {
    this.config = this.config || {};
    // Manually setting backdrop as angular@2.X.X does not support the ComponentReference
    // Hence setting this flag as false lets you perform show()
    // and hide() operations on the ModalDirective
    // DO NOT REMOVE
    // this.config.backdrop = false;
  }
  public onHidden() {
    this.onClose.emit(true);
  }
  public HideModalDialog($event) {
    this.modalControl.hide();
  }
  public ShowModalDialog($event) {
    this.modalControl.show();
  }
}
