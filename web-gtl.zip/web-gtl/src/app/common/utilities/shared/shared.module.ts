import { ReloadDirective } from './../../directive/reload.directive';
import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
    AccordionModule, CollapseModule, DatepickerModule,
    TimepickerModule, ModalModule, TabsModule, CarouselModule
} from 'ngx-bootstrap';
import { EmitterService } from '../../services/emitter.service';
import { PopupComponent } from '../popup/popup.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HorizontalScrollDirective } from '../scrollBar/scrollBar.directive';
import { SelectionListComponent } from '../selectionList';
import { PaymentComponent } from '../../../payment/payment.component';
import { Ng2CompleterModule } from 'ng2-completer';
import { DoubleDigitPipe } from '../pipes/DoubleDigit.pipe';
// Application wide providers
const APP_PROVIDERS = [
    EmitterService
];
@NgModule({
    declarations: [
        PopupComponent,
        HorizontalScrollDirective,
        SelectionListComponent,
        PaymentComponent,
        DoubleDigitPipe,
        ReloadDirective
    ],
    imports: [
        CommonModule,
        ReactiveFormsModule,
        Ng2CompleterModule,
        ModalModule.forRoot(),
        TabsModule.forRoot(),
        AccordionModule.forRoot(),
        CarouselModule.forRoot()
    ],
    exports: [
        ModalModule,
        ReactiveFormsModule,
        TabsModule,
        PopupComponent,
        HorizontalScrollDirective,
        AccordionModule,
        SelectionListComponent,
        PaymentComponent,
        Ng2CompleterModule,
        CarouselModule,
        DoubleDigitPipe,
        ReloadDirective
    ]
})
export class SharedModule {
    public static forRoot(): ModuleWithProviders {
        return {
            ngModule: SharedModule,
            providers: [APP_PROVIDERS]
        };
    }
}
