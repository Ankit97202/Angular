export class CommonConstants {
    public static DEFAULT_EMPTY_STRING = '';
    public static ONLY_ALPHABETS_PATTERN_STRING: any = /^([a-zA-Z])$/;
    public static URL_SEPARATOR = '/';
    public static PIPE_SEPARATOR = '|';
    public static QUERY_PARAMETER_LITERAL = '?';
    public static EQUALS = '=';
    public static AMPERSAND = '&';
    public static PERCENTAGE_LITERAL = '%';
    public static EMAIL_PATTERN_STRING = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/;
    // Cookie Keys
    public static CookieKeys = {
        AuthId: 'authId',
        NTID: 'NTID',
        AuthType: 'authType',
        State: 'state',
        Code: 'code',
        AuthToken: 'authToken',
        ProcessInstanceDetails: 'processInstanceDetails',
        LoanApplicationId: 'loanApplicationId',
        LoanApplicationKey: 'loanApplicationKey',
        Error: 'error',
        UserName: 'uDetails',
        DeviceDetails: 'DeviceDetails',
        ClientId: 'SC_ID',
        SecretKey: 'SS_ID',
        UserAuthenticationToken: 'UserAuthenticationToken',
        GeoLocationDetails: 'GeoLocationDetails',
        JWToken: 'SS_1',
        GuardToken: 'SS_2',
        GuardKey: 'SS_4',
        EmployeeResume: 'SS_R_TYP',
        EmployeeResume_Value: 'emp',
        IsLaIsPh: 'IsLaIsPh',
        MobileState: 'mobileState',
        PaymentSuccess: 'paymentSuccess',
        JourneyType: 'journeytype'
    };
    public static LOAN_PRODUCT_CODES = {
        Secured_Personal_Loan: 'DHB',
        Secured_Loan: 'SSL',
        Travel_Insurance: 'TGI',
        Health_Insurance: 'HGI',
        Cyber_Insurance: 'CGI',
        Health_ExtraInsurance:'HTP',
        GTL_Insurance:'TERMLI'
        // li
    };
    public static LOAN_PRODUCT_CATEGORY_CODES = {
        Unsecured_Loan: 'UL',
        Secured_Loan: 'SL',
        Travel_Insurance: 'ins',
        Health_Insurance: 'ins',
        Cyber_Insurance: 'ins',
        Health_ExtraInsurance:'HGI',
        GTL_Insurance:'LI'
    };
    public static APPLICANT_PHONE_TYPES = {
        Mobile: 'MOBILE',
        Fax: 'FAX',
        General: 'GENERAL',
        HomeFax: 'HOMEFAX',
        HomePhone: 'HOMEPHN',
        Office: 'OFFICE',
        SmsMobile: 'SMSMOB',
        Work: 'WORK'
    };
    public static APPLICANT_EMAIL_TYPES = {
        CoApplicant_1: 'CO-BOR1',
        CoApplicant_2: 'CO-BOR2',
        Communication: 'COMM',
        Guardian: 'GUARDIAN',
        Husband: 'HUSBAND',
        Nominee: 'NOMINEE',
        Office: 'OFFICE',
        Other: 'OTHER',
        Parent: 'PARENT',
        Personal_1: 'PERSON1',
        Personal_2: 'PERSON2',
        Wife: 'WIFE',
        Work: 'WORK'
    };
    public static UploadType = {
        Aadhar: 'Aadhar',
        Passport: 'Passport',
        BankStatement: 'BankStatement',
        Pan: 'Pan',
        DL: 'DL'
    };
    public static encyKey = {
        keyToEncrypt: 'B1729a411698j58260a613355j556900'
    };
    public static QueryParamsKeys = {
        EmailToConfirmType: 'type',
        EmailTokenToConfirm: 'id',
        PaymentStatus_QueryParams: 'queryParams',
        appUtmRefCode: 'appUtmRefCode',
        appUtmSource: 'utm_source',
        appUtmMedium: 'utm_medium',
        appUtmCampaign: 'utm_campaign',
        appUtmTerm: 'utm_term',
        appUtmContent: 'utm_content',
        UTMData: 'UTMData',
        BFLBranch: 'BFLBranch',
        GCLID: 'gclid',
        Productcode: 'prdcode',
        Product: 'product',
        ApplicantId: 'apcantid',
        ApplicationId: 'aptionid',
        ApplicationApplicantId: 'apcaptid',
        InsuranceProductType: 'insProductType',
        IsMobile: 'isMobile'
    };
    public static SharedServiceDataKeys = {
        JourneySource: 'JourneySource',
        Applicant: 'Applicant',
        AadharNumber: 'AadharNumber',
        ProgressStateInfo: 'ProgressStateInfo',
        EsignDocmentList: 'esignDocmentList',
        IsNewApplication: 'IsNewApplication',
        ApplicationID: 'ApplicatonID'
    };
    // Routes
    public static Routes = {
        Home: '',
        MultitabFailed: 'multitabFailed',
        Application: {
            Home: 'applicationStage',
            EditDetails: 'editDetails',
            PremiumPayer: 'premiumPayer',
            childEducationDetail: 'childEducationDetail',
            nomineeDetails: 'nomineeDetails',
            AddressDetails: 'addressDetails',
            EducationDetails: 'educationDetails',
            ReviewApplication: 'reviewApplication',
            EmploymentDetails: 'employmentDetails',
            AdditionalDetails: 'additionalDetails',
            SetPortfolio: 'setPortfolio',
            MoreAboutDetails: 'moreAboutDetails',
            ApplicationStatus: 'applicationStatus',
            ProposerPersonalDetails: 'proposerPersonalDetails',
            MedicalDeclaration: 'medicalDeclaration',
            GetQuoteForm: 'getQuoteForm'
        },
        AdditionalApplication: {
            Home: 'additionalDetails',
            BankDetails: 'bankDetails',
            EAccountDetails: 'eAccountDetails',
            FatcaDeclaration: 'fatcaDeclaration',
            IfscFinder: 'ifscFinder',
            TravelDetails: 'travelDetails',
            FamilyChildInsurance: 'familyChildInsurance',
            LifestyleDetails: 'lifestyleDetails',
            HealthRecordDetails: 'healthRecordDetails'
        },
        Verification: {
            Home: 'verify',
            VerifyMobile: 'verifyMobile'
        },
        FinalModule: {
            Home: 'final',
            Congratulations: 'congratulations',
            PaymentFailed: 'paymentFailed',
            UploadDocument: 'uploadDocument',
            RejectApplication: 'rejectApplication',
            PaymentReview:'paymentReview'
        },
        Logout: 'logout',
        ResumeApplication: 'resumeApplication',
        ApplicationList: 'applicationList',
        CustomerLogin: 'customerLogin/:CustomerType',
        CustomerLoginBase: 'customerLogin',
    };
    // input type
    public static InputTypes = {
        ReadOnly: 'ReadOnly',
        Selection: 'Selection',
        Dynamic: 'Dynamic',
        Button: 'Button',
        Date: 'Date',
        Boolean: 'Boolean',
        InputBox: 'InputBox',
        CheckBox: 'boolean'
    };
    // APIURL
    public static APIURL = {
        ABTESTLAYOUT: 'l1',
        getGeoLocationBasedOnPin: '{DOMAIN01}/v1/referencedata/locatepin/{0}',
        startApplicationActiviti: '{DOMAIN01}/v1/insurances/workflow/gtl/process',
        completeActivitiTask: '{DOMAIN01}/v1/insurances/workflow/gtl/process',
        getActivitiTaskDetails: '{DOMAIN01}/v1/insurances/workflow/gtl/details',
        getSecretKey: '{DOMAIN01}/v1/logins/ui/keys/{0}',
        getTokenForUser: '{DOMAIN01}/v1/logins/ui',
        validatePan: '{DOMAIN01}/v1/insurances/validations/pan',
        getPaymentDetails: '{DOMAIN01}/v1/insurances/gtl/{applicationId}/payment/initiation',
        getMaritalStatusCodes: '{DOMAIN01}/v1/referencedata/maritalstatuscode',
        getCountry: '{DOMAIN01}/v1/referencedata/countries?countryName=',
        getRelationship: '{DOMAIN01}/v1/referencedata/applicants/relationshipscodes',
        getRepaymentPayload: '{DOMAIN01}/v1/nosqldata/audit?applicationId=',
        downloadPdf: '{DOMAIN01}/v1/documentmanagement/exportpdf',
        downloadReciept: '{DOMAIN01}/v1/insurances/gtl/{applicationId}/payments/receipts',
        getNomineeRelationshipLookupService: '{DOMAIN01}/v1/referencedata/relationshiptypes?groupcode=GTLNOMREL',
        getPlanSumAssured: '{DOMAIN01}/v1/bre/insurances/gtl/plans/sumassured',
        getPlanRiders: '{DOMAIN01}/v1/bre/insurances/gtl/plans/riders',
        resumeSendOtp: '{DOMAIN01}/v1/logins/forms/mobile',
        resumeGetOtp: '{DOMAIN01}/v1/logins/forms/mobile/otp',
        getAllStatesApi: '{DOMAIN01}/v1/referencedata/allstates',
        getCitiesApi: '{DOMAIN01}/v1/referencedata/cities?stateKey=',
        getDocAndAppStatus: '{DOMAIN01}/v1/insurances/gtl/{applicationId}/status',
        getPaymentStatus:'{DOMAIN01}/v1/insurances/policy/status',
        getHealthRequestId: '{DOMAIN01}/v1/insurances/booking/initiation',
        calculatePremium: '{DOMAIN01}/v1/insurances/gtl/selectedplans',
    };
    public static PageTitles = {
        proposerPersonalDetails: 'Personal Details',
        mailingAddress: 'Mailing Address',
        verifyMobile: 'Verify Mobile',
        appSummary: 'appSummary'
    };
    public static CurrencyCoversionUnits = {
        Lacs: 100000,
        Crore: 10000000
    };
    public static SourceTypes = {
        System: 'system',
        Journey: 'journey',
        CustomerPortal: 'customerportal',
        EmployeePortal: 'employeeportal'
    };
    public static footerText = [
        {
            title: 'Bajaj Finance Limited Regd. Office',
            desc: 'Mumbai-Pune Road,Akurdi,Pune-411035,Maharashtra,India'
        },
        {
            title: 'Corporate Office',
            desc: '4TH Floor, B2 Building, Cerebrum IT Park, Kumar City, Kalyani Nagar, Pune – 411014.'
        }
    ];
    public static EmitterEventTypes = {
        LoadingEvent: 'LoadingEvent',
        GlobalErrorEvent: 'GlobalErrorEvent',
        ProgressStateEvent: 'ProgressStateEvent',
        LoadingSmallLoaderEvent: 'SmallLoader',
        NavigationEvent: 'NavigationFlag',
        ProcessCallCompleteEvent: 'ProcessCallComplete',
        MobileAppCheck: 'MobileAppCheck',
        AadhaarOTPRequested: 'aadhaarOTPRequested'
    };
    public static errorCodes = [
        "OTP_801", "OTP_802", "OTP_803", "OTP_804", "OTP_805", "OTP_806", "OTP_807", "OTP_808", "OTP_809", "OTP_810",
        "OTP_811", "OTP_812", "OTP_813", "OTP_814", "OTP_815", "OTP_816", "OTP_817", "OTP_818", "OTP_819", "OTP_820"
    ];
    public static offerAdds = {
      // tslint:disable-next-line:max-line-length
      healthInsuranceAdd: 'https://www.bajajfinservmarkets.in/insurance/health-insurance/family-health-insurance.html?pid=motor-reject:spa:mc:get-quote:ins-health-family:crosssell',
      // tslint:disable-next-line:max-line-length
      UlipInsuranceAdd: 'https://www.bajajfinservmarkets.in/insurance/ulip/investment-plans.html?pid=motor-reject:spa:mc:show-plans:ins-ulip-invest:crosssell',
      travelInsuranceAdd : '',
      motorInsuranceAdd : '',
      cyberInsuranceAdd : ''
  };
}
