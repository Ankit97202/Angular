import { FormControl } from '@angular/forms';
export function shouldStartWith(...nums: string[]) {
    return (input: FormControl) => {
        return (nums.indexOf((input.value || '')[0]) !== -1) ? null : { shouldStartWith: nums };
    };
}
