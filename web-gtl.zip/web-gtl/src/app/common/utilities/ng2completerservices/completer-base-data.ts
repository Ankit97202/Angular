import { Subject } from 'rxjs/Subject';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { CompleterItem } from 'ng2-completer';
import { CtrCompleter } from 'ng2-completer/src//directives/ctr-completer';
import { CompleterData } from './completer-data';
export abstract class CompleterBaseData extends Subject<CompleterItem[]> implements CompleterData {
    protected _searchFields: string;
    protected _titleField: string;
    protected _descriptionField: string;
    protected _imageField: string;
    protected _headers: HttpHeaders;
    constructor() {
        super();
    }
    public abstract search(term: string): void;
    public cancel() {
        // blank
    }
    public searchFieldss(searchFields: string) {
        this._searchFields = searchFields;
        return this;
    }
    public titleField(titleField: string) {
        this._titleField = titleField;
        return this;
    }
    public descriptionField(descriptionField: string) {
        this._descriptionField = descriptionField;
        return this;
    }
    public imageField(imageField: string) {
        this._imageField = imageField;
        return this;
    }
    public headers(head: HttpHeaders) {
        this._headers = head;
        return this;
    }
    protected extractMatches(data: any[], term: string) {
        let matches: any[] = [];
        if (this._searchFields && this._searchFields !== '') {
            const searchFields = this._searchFields.split(',');
            for (let i = 0; i < data.length; i++) {
                let match = false;
                // tslint:disable-next-line:prefer-for-of
                for (let s = 0; s < searchFields.length; s++) {
                    const value = this.extractValue(data[i], searchFields[s]) || '';
                    match = match || (value.toString().toLowerCase().indexOf(
                        term.toString().toLowerCase()) >= 0);
                }
                if (match) {
                    matches[matches.length] = data[i];
                }
            }
        } else {
            matches = data;
        }
        return matches;
    }
    protected extractTitle(item: any) {
        // split title fields and run extractValue for each and join with ' '
        return this._titleField.split(',')
            .map((field) => {
                return this.extractValue(item, field);
            })
            .join(' ');
    }
    protected extractValue(obj: any, key: string) {
        let keys: string[];
        let result: any;
        if (key) {
            keys = key.split('.');
            result = obj;
            // tslint:disable-next-line:prefer-for-of
            for (let i = 0; i < keys.length; i++) {
                if (result) {
                    result = result[keys[i]];
                }
            }
        } else {
            result = obj;
        }
        return result;
    }
    protected processResults(matches: string[], term: string): CompleterItem[] {
        let i: number;
        let description: string;
        let images: string;
        let text: string;
        let formattedText: string;
        let formattedDesc: string;
        const results: CompleterItem[] = [];
        if (matches && matches.length > 0) {
            for (i = 0; i < matches.length; i++) {
                if (this.titleField && this._titleField !== '') {
                    text = formattedText = this.extractTitle(matches[i]);
                }
                description = '';
                if (this._descriptionField) {
                    description = formattedDesc = this.extractValue(matches[i],
                        this._descriptionField);
                }
                images = null;
                if (this._imageField) {
                    images = this.extractValue(matches[i], this._imageField);
                }
                results.push({
                    title: formattedText,
                    description: formattedDesc,
                    image: images,
                    originalObject: matches[i]
                });
            }
        }
        return results;
    }
}
