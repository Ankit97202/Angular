import { Observable } from 'rxjs/Observable';
import { CompleterItem } from 'ng2-completer';
export interface CompleterData extends Observable<CompleterItem[]> {
    search(term: string): void;
    cancel(): void;
}
