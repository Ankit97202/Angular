declare module Model {
    export interface PolicyDetails {
        policyNo: string;
        polDocUrl: string;
        paymentStatus: number;
        policyStatus: number;
        paymentId: string;
        orderId: string;
        receiptNo: string;
    }
}