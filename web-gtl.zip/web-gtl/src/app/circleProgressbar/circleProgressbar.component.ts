import { Component, OnInit, Input, ElementRef, Renderer } from '@angular/core';
@Component({
    selector: 'app-circle-progress-bar',
    templateUrl: './circleProgressbar.template.html',
    styleUrls: ['./circleProgressbar.style.css'],
})
export class CircleProgressbarComponent implements OnInit {
    public ProgessValueList: any;
    public isOver50: boolean;
    @Input() public progessValue;
    constructor(
        private el: ElementRef,
        private renderer: Renderer
    ) { }
    public ngOnInit() {
        this.getProgessbarValue();
        console.log('progessValue', this.progessValue);
    }
    private getProgessbarValue() {
        const progresBar = this.el.nativeElement.querySelectorAll('.progress-circle');
        if (this.progessValue >= 50) {
            progresBar[0].classList.add('over50');
        } else {
            progresBar[0].classList.remove('over50');
        }
    }
}
