import { Component, OnInit, Input } from '@angular/core';
import { CommonConstants } from '../common/utilities/commonConstants';
@Component({
    selector: 'offer-add',
    templateUrl: 'offerAdd.template.html',
    styleUrls: ['offerAdd.style.css']
})
export class OfferAddComponent implements OnInit {
    @Input() addLocation;
    public travelUrl = '';
    public cyberUrl = '';
    public healthUrl = '';
    public ulipUrl = '';
    constructor() {
    }
    ngOnInit() {
        this.travelUrl = CommonConstants.offerAdds.travelInsuranceAdd;
        this.cyberUrl = CommonConstants.offerAdds.cyberInsuranceAdd;
        this.healthUrl = CommonConstants.offerAdds.healthInsuranceAdd;
        this.ulipUrl = CommonConstants.offerAdds.UlipInsuranceAdd;
    }
}
